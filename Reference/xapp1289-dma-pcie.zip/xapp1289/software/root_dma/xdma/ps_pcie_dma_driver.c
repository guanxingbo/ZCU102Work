/****************************************************************************
 ****************************************************************************/
/** Copyright (C) 2014-2015 Xilinx, Inc.  All rights reserved.
 ** Permission is hereby granted, free of charge, to any person obtaining
 ** a copy of this software and associated documentation files (the
 ** "Software"), to deal in the Software without restriction, including
 ** without limitation the rights to use, copy, modify, merge, publish,
 ** distribute, sublicense, and/or sell copies of the Software, and to
 ** permit persons to whom the Software is furnished to do so, subject to
 ** the following conditions:
 ** The above copyright notice and this permission notice shall be included
 ** in all copies or substantial portions of the Software.Use of the Software 
 ** is limited solely to applications: (a) running on a Xilinx device, or 
 ** (b) that interact with a Xilinx device through a bus or interconnect.  
 ** THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 ** EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 ** MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 ** NONINFRINGEMENT. IN NO EVENT SHALL XILINX BE LIABLE FOR ANY
 ** CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 ** TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 ** SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 ** Except as contained in this notice, the name of the Xilinx shall
 ** not be used in advertising or otherwise to promote the sale, use or other
 ** dealings in this Software without prior written authorization from Xilinx
 **/
/*****************************************************************************
*****************************************************************************/
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/slab.h>
#include <linux/timer.h>
#include <linux/sched.h>
#include <linux/kthread.h>
#include <linux/cdev.h>
#include <asm/uaccess.h>
#include <linux/fs.h>
#include <linux/kdev_t.h>
#include <linux/version.h>
#include <linux/pci.h>
#include <linux/of.h>
#include <linux/device.h>
#include <linux/of_platform.h>
#include <linux/platform_device.h>

#include "ps_pcie_dma_driver.h"
#include "../include/xpmon_be.h"
#include "../include/xdebug.h"
#if defined(VIDEO_ACC_DESIGN)
#define NOBH 1
#else
#undef NOBH
#define WITHBH 1
#endif

#if defined (NOBH)
#define LOCK_DMA_CHANNEL(x) spin_lock(x)
#define UNLOCK_DMA_CHANNEL(x) spin_unlock(x)
#elif defined (WITHBH)
#define LOCK_DMA_CHANNEL(x) spin_lock_bh(x)
#define UNLOCK_DMA_CHANNEL(x) spin_unlock_bh(x)
#else
#define LOCK_DMA_CHANNEL(x) 
#define UNLOCK_DMA_CHANNEL(x) 
#endif

/*
 * Global Statastics 
 * Driver periodically polls statistics from Hw and preserves in below data structures
 * GUI Periodicaly polls these statstics from driver to show case it in GUI.
 */

TRNStatistics TStats[MAX_STATS];

int dstatsRead[PS_PCIE_NUM_DMA_CHANNELS], dstatsWrite[PS_PCIE_NUM_DMA_CHANNELS];
int dstatsNum[PS_PCIE_NUM_DMA_CHANNELS], sstatsRead[PS_PCIE_NUM_DMA_CHANNELS];
int sstatsWrite[PS_PCIE_NUM_DMA_CHANNELS], sstatsNum[PS_PCIE_NUM_DMA_CHANNELS];
int tstatsRead, tstatsWrite, tstatsNum;
unsigned long SWrate[PS_PCIE_NUM_DMA_CHANNELS];

struct timer_list stats_timer;
struct cdev * xdmaCdev=NULL;
static struct class *class;
static dev_t xdmaDev;
int UserOpen=0;
u32 DriverState = UNINITIALIZED;
PowerMonitorVal pmval;

const char ps_pcie_driver_name[] = "PS_PCIE_XILINX_DMA_DRIVER";

#define XIo_In32(addr)      (readl((unsigned int *)(addr)))
#define XIo_Out32(addr, data) (writel((data), (unsigned int *)(addr)))
/*
 * Global linked list head pointer for DMA descriptor list
 * maintained by host driver. Each descriptor correspinds to each 
 * card is system that employs the DMA we are interested in.
 * The actual job of detecting the card is done by the higher layer (application specific)
 * driver that is above this DMA driver.
 */
static ps_pcie_dma_desc_t g_host_dma_desc = {0}; 


static DEFINE_SPINLOCK(DmaStatsLock);

static irqreturn_t ps_pcie_intr_handler(int irq, void *data);

static phys_addr_t ps_ddr_apm_phy_addr;
static u8 __iomem * ps_ddr_apm_vaddr;

static int register_interrupt_handler(unsigned int irq_no, const char *hndlr_name,
		ps_pcie_dma_desc_t *ptr_dma_desc)
{

	int retval = XLNX_SUCCESS;


	/* Register interrupt handler if not already done */
	if(ptr_dma_desc->intr_hndlr_registered == false) 
	{
		int rc = request_irq(irq_no, ps_pcie_intr_handler, IRQF_SHARED,
				hndlr_name, ptr_dma_desc);
		if (rc) {
			printk(KERN_ERR"\nUnable to request IRQ %p, error %d\n",
					ptr_dma_desc->device, rc);
			retval = XLNX_INTERRUPT_REG_FAIL;
		}
		else
		{
			ptr_dma_desc->intr_hndlr_registered = true;
			printk(KERN_ERR"\nIRQ Handler register success\n");
		}
	}

	return retval;
}
/*
 * Function returns device structure of PCIe device
 *
 */
static inline struct device *nwl_pci_dev_to_dev(struct pci_dev *pdev)
{
	return &pdev->dev;
}

static int nwl_dma_is_chann_alloc_ep(ps_pcie_dma_desc_t * ptr_dma_desc, 
		unsigned int channel_id, direction_t dir)
{
	u8 __iomem *ptr_temp_chann_regs = ptr_dma_desc->dma_chann_reg_virt_base_addr + (channel_id * DMA_REG_TOT_BYTES);
	unsigned int offset = DMA_SRCQPTRLO_REG_OFFSET;
	unsigned int regval;
	int retval = XLNX_SUCCESS;

#ifdef HW_SGL_DESIGN
	return retval;
#endif

	if( dir == OUT) 
	{
		/* We want to send data to card, so ep will have configured destination Q for rhis channel */
		offset = DMA_DSTQPTRLO_REG_OFFSET;
	}

	printk(KERN_ERR"\nCheck if Channel is allocated in EP\n");

	regval = RD_DMA_REG(ptr_temp_chann_regs, offset);


	if(!(regval & DMA_QPTRLO_Q_ENABLE_BIT))
	{			
		retval = XLNX_UNALLOCATED_IN_EP;
		ptr_dma_desc->channels[channel_id].chann_state = XLNX_DMA_CHANN_NOT_READY_EP;
	}

	printk(KERN_ERR"\nCheck if Channel is allocated in EP read loc %p, read %x returning %d\n", ptr_temp_chann_regs + offset, regval, retval);

	return retval;
}

static void InitPSAPM(u64 ps_ddr_apm_va)
{
	/* Initialize APM on DDRC */
	XIo_Out32((ps_ddr_apm_va + APM_CTRL_REG), PS_APM_CNTR_RST);
	//- 533MHz Clock
	XIo_Out32((ps_ddr_apm_va + SAMPLE_INTERVAL), PS_APM_CLK_RATE);
	XIo_Out32((ps_ddr_apm_va + SAMPLE_INTERVAL_CTRL), PS_APM_MET_CNT_RST);
	XIo_Out32((ps_ddr_apm_va + SAMPLE_INTERVAL_CTRL), PS_APM_LOAD_SMPL_CNTR);
	XIo_Out32((ps_ddr_apm_va + SAMPLE_INTERVAL_CTRL), PS_APM_MET_CNT_RST);
	XIo_Out32((ps_ddr_apm_va + SAMPLE_INTERVAL_CTRL), PS_APM_EN_MET_CNTR_RST);
	//- Enable RdBC, WrBC for PS-DDRC slots-1 & 2
	XIo_Out32((ps_ddr_apm_va + METRIC_SEL_REG0), PS_APM_SET_MET);
	XIo_Out32((ps_ddr_apm_va + APM_CTRL_REG), PS_APM_ENBL_CNTR);
}

/* 
 * InitBridge Function does Endpoint specific functionality.
 * In this design KCU105 EP uses AXI-PCIe IP where BAR2 is mapped to MIG (DDR4) 
 * and BAR4 is mapped to APM connected on MIG AXI-MM interface.
 * This function initializes the APM in EP mapped to BAR4
 */
static void InitBridge(u64 bar0_addr, u64 bar0_addr_p, u64 bar2_addr, u64 bar2_addr_p, u64 bar4_addr, u64 bar4_addr_p) 
{

	/* MIG AXI User Clk is 300MHz */
	XIo_Out32((bar4_addr + AXI_PERF_MON_BASE + SAMPLE_INTERVAL), CLK_300MHZ_PERIOD);   //300MHz clock

	XIo_Out32((bar4_addr + AXI_PERF_MON_BASE + SAMPLE_INTERVAL_CTRL), EP_APM_LOAD_SMPL_CNTR); // Load inteval timer reg value
	XIo_Out32((bar4_addr + AXI_PERF_MON_BASE + SAMPLE_INTERVAL_CTRL), EP_APM_MET_CNT_RST); // clear load bit
	XIo_Out32((bar4_addr + AXI_PERF_MON_BASE + SAMPLE_INTERVAL_CTRL), EP_APM_EN_MET_CNTR_RST); // enable + reset metric counter after read

	XIo_Out32((bar4_addr +  AXI_PERF_MON_BASE + METRIC_SEL_REG0), EP_SLCT_CNTR);
	XIo_Out32((bar4_addr + AXI_PERF_MON_BASE + APM_CTRL_REG), EP_APM_ENBL_CNTR);
}


static void poll_stats(unsigned long __opaque)
{
	unsigned long t1;
	struct pci_dev *pdev = (struct pci_dev *)__opaque;
	ps_pcie_dma_desc_t *lp = pci_get_drvdata(pdev);
	int offset = 0;
	unsigned long t2;
	u8 __iomem *base = lp->ep_apm_virt_base_addr;
  
  /* PS-APM metrics from Root Port DDRC */
	//- RdBC
	t1 = (XIo_In32(ps_ddr_apm_vaddr + APM_METRIC_CNTR0) + XIo_In32(ps_ddr_apm_vaddr + APM_METRIC_CNTR2));
	//-WrBC
	t2 = (XIo_In32(ps_ddr_apm_vaddr + APM_METRIC_CNTR1) + XIo_In32(ps_ddr_apm_vaddr + APM_METRIC_CNTR3));
	TStats[tstatsWrite].LTX = (t1);

	TStats[tstatsWrite].LRX = (t2);

  /* APM metrics from KCU105 Endpoint */
	TStats[tstatsWrite].scaling_factor = 1; 

	TStats[tstatsWrite].RBC_APM0 = RD_DMA_REG(base,  AXI_PERF_MON_BASE + APM_METRIC_CNTR0);
	TStats[tstatsWrite].WBC_APM0 = RD_DMA_REG(base, AXI_PERF_MON_BASE + APM_METRIC_CNTR1 );
	tstatsWrite += 1;
	if(tstatsWrite >= MAX_STATS) tstatsWrite = 0;

	if(tstatsNum < MAX_STATS)
		tstatsNum += 1;
	/* else move the read pointer forward */
	else
	{
		tstatsRead += 1;
		if(tstatsRead >= MAX_STATS) tstatsRead = 0;
	}

	/* Reschedule poll routine */
	offset = -3;
	stats_timer.expires = jiffies + HZ + offset;
	add_timer(&stats_timer);
}

/* Character device file operations */
static int xdma_dev_open(struct inode * in, struct file * filp)
{
	/* Will restrict more than one file open 
	*/
	if(UserOpen)
	{
		printk("Device already in use\n");
		return -EBUSY;
	}


	spin_lock_bh(&DmaStatsLock);
	UserOpen++;                 /* To prevent more than one GUI */
	spin_unlock_bh(&DmaStatsLock);

	return 0;
}

static int xdma_dev_release(struct inode * in, struct file * filp)
{
	if(!UserOpen)
	{
		/* Should not come here */
		printk("Device not in use\n");
		return -EFAULT;
	}

	spin_lock_bh(&DmaStatsLock);
	UserOpen-- ;
	spin_unlock_bh(&DmaStatsLock);

	return 0;
}

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,36)
static int xdma_dev_ioctl(struct inode * in, struct file * filp,
		unsigned int cmd, unsigned long arg)
#else
static long xdma_dev_ioctl(struct file * filp,
		unsigned int cmd, unsigned long arg)
#endif
{
	int retval=0;
	TRNStatsArray tsa;
	TRNStatistics * ts;
	ps_pcie_dma_chann_desc_t *chann_temp;

	ps_pcie_dma_desc_t *ptr_dma_desc_temp = &g_host_dma_desc;

	int len, i;
	
	/* Check cmd type and value */
	if(_IOC_TYPE(cmd) != XPMON_MAGIC) return -ENOTTY;
	if(_IOC_NR(cmd) > XPMON_MAX_CMD) return -ENOTTY;

	/* Check read/write and corresponding argument */
	if(_IOC_DIR(cmd) & _IOC_READ)
		if(!access_ok(VERIFY_WRITE, (void *)arg, _IOC_SIZE(cmd)))
			return -EFAULT;
	if(_IOC_DIR(cmd) & _IOC_WRITE)
		if(!access_ok(VERIFY_READ, (void *)arg, _IOC_SIZE(cmd)))
			return -EFAULT;
	/* Looks ok, let us continue */
	switch(cmd)
	{
		case IGET_TRN_STATISTICS:
			if(copy_from_user(&tsa, (TRNStatsArray *)arg, sizeof(TRNStatsArray)))
			{
				printk("copy_from_user failed\n");
				retval = -1;
				break;
			}

			ts = tsa.trnptr;
			len = 0;
			for(i=0; i<tsa.Count; i++)
			{
				TRNStatistics from;

				if(!tstatsNum) break;

				spin_lock_bh(&DmaStatsLock);
				from = TStats[tstatsRead];
				tstatsNum -= 1;
				tstatsRead += 1;
				if(tstatsRead == MAX_STATS)
					tstatsRead = 0;
				spin_unlock_bh(&DmaStatsLock);

				if(copy_to_user(ts, &from, sizeof(TRNStatistics)))
				{
					printk("copy_to_user failed\n");
					retval = -EFAULT;
					break;
				}

				len++;
				ts++;
			}
			tsa.Count = len;
			if(copy_to_user((TRNStatsArray *)arg, &tsa, sizeof(TRNStatsArray)))
			{
				printk("copy_to_user failed\n");
				retval = -EFAULT;
				break;
			}
			break;


		default:
			printk("Invalid command %d\n", cmd);
			retval = -1;
			break;
	}

	return retval;
}

unsigned long xlnx_get_ep_bar_addr(void *arg)
{
	return g_host_dma_desc.cntrl_func_phy_base_addr;
}
EXPORT_SYMBOL(xlnx_get_ep_bar_addr);

static int /*__devinit*/ nwl_dma_probe(struct pci_dev *pdev,
		const struct pci_device_id *ent)
{
	int err, pci_using_dac,i;
	ps_pcie_dma_desc_t *ptr_dma_desc_temp = NULL;
	int chrRet;
	static struct file_operations xdmaDevFileOps;	
	struct device *dv;


	err = pci_enable_device(pdev);
	if (err)
		return err;

	printk(KERN_ERR"\nPCIe device enabled\n");

	err = pci_request_regions(pdev, ps_pcie_driver_name);
	if (err) {
		dev_err(nwl_pci_dev_to_dev(pdev),
				"pci_request_regions failed 0x%x\n", err);
		printk(KERN_ERR"\nERROR!!!! PCIe request regions failed\n");
		goto err_pci_reg;
	}
	printk(KERN_ERR"\nPCIe request regions \n");

	/*
	 * Allocate a descriptor corresponding to discovered 
	 */
	ptr_dma_desc_temp = &g_host_dma_desc;
	if (pdev->device == NWL_DMA_RP_DEVID)
	{
		if (!dma_set_mask(nwl_pci_dev_to_dev(pdev), DMA_BIT_MASK(64)) &&
				!dma_set_coherent_mask(nwl_pci_dev_to_dev(pdev), DMA_BIT_MASK(64))) {
			pci_using_dac = 1;
			printk(KERN_ERR"\nPCIe 64bit access capable\n");

		} else {
			err = dma_set_mask(nwl_pci_dev_to_dev(pdev), DMA_BIT_MASK(32));
			if (err) {
				err = dma_set_coherent_mask(nwl_pci_dev_to_dev(pdev),
						DMA_BIT_MASK(32));
				printk(KERN_ERR"\nPCIe 32bit access capable\n");
				if (err) {
					dev_err(nwl_pci_dev_to_dev(pdev), "No usable DMA "
							"configuration, aborting\n");
					printk(KERN_ERR"\nError!!! No usable DMA configuration ..........\n");
					goto err_dma;
				}
			}
			pci_using_dac = 0;
		}
		printk(KERN_ERR"\nPCIe set master\n");
		pci_set_master(pdev);


		/* Initialize fields of the dma descriptor */
		ptr_dma_desc_temp->device = (void*)pdev;	
		ptr_dma_desc_temp->num_channels = PS_PCIE_NUM_DMA_CHANNELS;
		ptr_dma_desc_temp->num_channels_active = PS_PCIE_NUM_DMA_CHANNELS; 
		ptr_dma_desc_temp->pform = HOST; //We are the host
		ptr_dma_desc_temp->num_channels_alloc = 0;
		spin_lock_init(&ptr_dma_desc_temp->dma_lock);

		spin_lock_init(&DmaStatsLock);

		ptr_dma_desc_temp->dma_reg_virt_base_addr = ioremap_nocache(ptr_dma_desc_temp->dma_reg_phy_base_addr, REG_BASE_LEN);
		if (!ptr_dma_desc_temp->dma_reg_virt_base_addr) 
		{

			printk(KERN_ERR"\nPCIe ioremap failed ERROR!!!!\n");
			err = -EIO;
			goto err_ioremap;
		}
		printk(KERN_ERR"\n DMA and Bridge Register Base Physical addr: %x, Virt address %p\n",(unsigned int)ptr_dma_desc_temp->dma_reg_phy_base_addr, 
			ptr_dma_desc_temp->dma_reg_virt_base_addr);
		/* Assign the channel register base address */
		ptr_dma_desc_temp->dma_chann_reg_virt_base_addr = ptr_dma_desc_temp->dma_reg_virt_base_addr /*+ 0x1000*/;
		
		err = register_interrupt_handler(ptr_dma_desc_temp->irq_no, "PS PCIe DMA Device", ptr_dma_desc_temp);	
		if(err != XLNX_SUCCESS) 
		{
			iounmap(ptr_dma_desc_temp->dma_reg_virt_base_addr);
			free_irq(ptr_dma_desc_temp->irq_no, ptr_dma_desc_temp);
			goto interrupt_registration_failed;
		}
		
		chrRet = alloc_chrdev_region(&xdmaDev, 0, 1, "xdma_stats");
		if(chrRet < 0)
			printk(KERN_ERR "Error allocating char device region\n");
		else
		{
			/* Register our character device */
			xdmaCdev = cdev_alloc();
			if(IS_ERR(xdmaCdev))
			{
				printk(KERN_ERR "Alloc error registering device driver\n");
				iounmap(ptr_dma_desc_temp->dma_reg_virt_base_addr);
				free_irq(ptr_dma_desc_temp->irq_no, ptr_dma_desc_temp);
				unregister_chrdev_region(xdmaDev, 1);
				chrRet = -1;
				goto error;
			}
			else
			{
				xdmaDevFileOps.owner = THIS_MODULE;
				xdmaDevFileOps.open = xdma_dev_open;
				xdmaDevFileOps.release = xdma_dev_release;
				#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,36)
				xdmaDevFileOps.ioctl = xdma_dev_ioctl;
				#else
				xdmaDevFileOps.unlocked_ioctl = xdma_dev_ioctl;
				#endif
				xdmaCdev->owner = THIS_MODULE;
				xdmaCdev->ops = &xdmaDevFileOps;
				xdmaCdev->dev = xdmaDev;
				chrRet = cdev_add(xdmaCdev, xdmaDev, 1);
				if(chrRet < 0)
				{
					printk(KERN_ERR "Add error registering device driver\n");
					iounmap(ptr_dma_desc_temp->dma_reg_virt_base_addr);
					free_irq(ptr_dma_desc_temp->irq_no, ptr_dma_desc_temp);
					unregister_chrdev_region(xdmaDev, 1);
					goto error;
				}
			}
		}
		class = class_create(THIS_MODULE, "ps_pcie_dma");
		if (IS_ERR(class)) {
			pr_err("Failed to create class\n");
			iounmap(ptr_dma_desc_temp->dma_reg_virt_base_addr);
			free_irq(ptr_dma_desc_temp->irq_no, ptr_dma_desc_temp);
			unregister_chrdev_region(xdmaDev, 1);
			err = -EFAULT;
			goto error;
		}   

		dv = device_create(class, NULL, xdmaDev, NULL,
				   "xdma_stats");
		if (IS_ERR(dv)) {
			pr_err("Unable to create device\n");
			iounmap(ptr_dma_desc_temp->dma_reg_virt_base_addr);
			free_irq(ptr_dma_desc_temp->irq_no, ptr_dma_desc_temp);
			unregister_chrdev_region(xdmaDev, 1);
			class_destroy(class);
			err = -EFAULT;
			goto error;
		}   
		/* Initialise all stats pointers */
		for(i=0; i<PS_PCIE_NUM_DMA_CHANNELS; i++)
		{
			dstatsRead[i] = dstatsWrite[i] = dstatsNum[i] = 0;
			sstatsRead[i] = sstatsWrite[i] = sstatsNum[i] = 0;
			SWrate[i] = 0;
		}
		tstatsRead = tstatsWrite = tstatsNum = 0;
	}
	
	if (pdev->device == NWL_DMA_EP_DEVID)
	{
		ptr_dma_desc_temp->ep_dma_phy_base_addr = pci_resource_start(pdev, PS_PCIE_BRDG_DMA_CHANN_BAR);
		ptr_dma_desc_temp->ep_dma_virt_base_addr = ioremap_nocache(ptr_dma_desc_temp->ep_dma_phy_base_addr, pci_resource_len(pdev, PS_PCIE_BRDG_DMA_CHANN_BAR));
		if (!ptr_dma_desc_temp->ep_dma_virt_base_addr)
		{
			printk(KERN_ERR"\nPCIe EP DMA ioremap failed ERROR!!!!\n");
			err = -EIO;
			goto err_ioremap_ingress_bar;
		}
		ptr_dma_desc_temp->ep_apm_phy_base_addr = pci_resource_start(pdev, PS_PCIE_BRDG_AXI_PERF_BAR);
		ptr_dma_desc_temp->ep_apm_virt_base_addr = ioremap_nocache(ptr_dma_desc_temp->ep_apm_phy_base_addr, pci_resource_len(pdev, PS_PCIE_BRDG_AXI_PERF_BAR));
		if (!ptr_dma_desc_temp->ep_apm_virt_base_addr)
		{
			printk(KERN_ERR"\nPCIe EP APM ioremap failed ERROR!!!!\n");
			iounmap(ptr_dma_desc_temp->ep_dma_virt_base_addr);
			err = -EIO;
			goto err_ioremap_ingress_bar;
		}
		ptr_dma_desc_temp->cntrl_func_phy_base_addr = pci_resource_start(pdev, PS_PCIE_CNTRL_FUNCT_INGRESS_TRANS_BAR);

		ps_ddr_apm_vaddr = ioremap_nocache(ps_ddr_apm_phy_addr, REG_BASE_LEN);
		if (!ps_ddr_apm_vaddr)
		{
			printk(KERN_ERR"\nPS-DDR APM ioremap failed!!!\n");
			iounmap(ptr_dma_desc_temp->ep_dma_virt_base_addr);
			iounmap(ptr_dma_desc_temp->ep_apm_virt_base_addr);
			err = -EIO;
		}
		InitPSAPM((u64)ps_ddr_apm_vaddr);

		/* Initialize the bridge */
		InitBridge((u64) ptr_dma_desc_temp->ep_dma_virt_base_addr, 
				(u64) ptr_dma_desc_temp->ep_dma_phy_base_addr, 
				0, 
				ptr_dma_desc_temp->cntrl_func_phy_base_addr,
				(u64) ptr_dma_desc_temp->ep_apm_virt_base_addr,
				(u64) ptr_dma_desc_temp->ep_apm_phy_base_addr);
		
		/* Start stats polling routine */
		printk(KERN_INFO "probe: Starting stats poll routine \n");
		/* Now start timer */
		init_timer(&stats_timer);
		stats_timer.expires=jiffies + HZ;
		stats_timer.data=(unsigned long) pdev;
		stats_timer.function = poll_stats;
		add_timer(&stats_timer);
		printk(KERN_ERR"\nInitialized HOST side diver logic\n");
	}
	
	pci_set_drvdata(pdev, ptr_dma_desc_temp);

interrupt_registration_failed:
err_dma:
err_pci_reg:
err_ioremap:
error:
err_ioremap_ingress_bar:
	return err;

}

static void /*__devexit*/ nwl_dma_remove(struct pci_dev *pdev)
{
	if (pdev->device == NWL_DMA_RP_DEVID)
	{
		spin_lock_bh(&DmaStatsLock);
		del_timer_sync(&stats_timer);
		spin_unlock_bh(&DmaStatsLock);

		if (xdmaCdev != NULL)
		{
			cdev_del(xdmaCdev);
			unregister_chrdev_region(xdmaCdev->dev,1);
		}

		if (class != NULL)
		{
			device_destroy(class, xdmaDev);
			class_destroy(class);
		}
		if(g_host_dma_desc.intr_hndlr_registered == true) 
		{
			printk(KERN_ERR"\nUnregister interrupt handler\n");
			free_irq(g_host_dma_desc.irq_no, &g_host_dma_desc); 
			g_host_dma_desc.intr_hndlr_registered = false;
		}

		if (g_host_dma_desc.dma_reg_virt_base_addr != NULL)
			iounmap(g_host_dma_desc.dma_reg_virt_base_addr); 
		pci_clear_master(pdev);
	}

	if (pdev->device == NWL_DMA_EP_DEVID)
	{
		ps_pcie_dma_desc_t *ptr_dma_desc_temp = pci_get_drvdata(pdev);
		if (ptr_dma_desc_temp->ep_dma_virt_base_addr != NULL)
			iounmap(ptr_dma_desc_temp->ep_dma_virt_base_addr);
		if (ptr_dma_desc_temp->ep_apm_virt_base_addr  != NULL)
			iounmap(ptr_dma_desc_temp->ep_apm_virt_base_addr);
		iounmap(ps_ddr_apm_vaddr);
	}
	pci_release_regions(pdev);
	pci_disable_device(pdev);
}

static struct pci_device_id nwl_dma_pci_tbl[] = {
	{PCI_DEVICE(PCI_VENDOR_XILINX, NWL_DMA_RP_DEVID)},
	{PCI_DEVICE(PCI_VENDOR_XILINX, NWL_DMA_EP_DEVID)},
	/* required last entry */
	{0, }
};

static struct pci_driver nwl_dma_driver = {
	.name     = ps_pcie_driver_name,
	.id_table = nwl_dma_pci_tbl,
	.probe    = nwl_dma_probe,
	.remove   = /*__devexit_p*/(nwl_dma_remove),
};

/*
 * AXI DMA centric functions
 * These functions abstract the inner register & BD format of NWL DMA
 */
static /*inline*/ void ps_pcie_post_process_rx_qs(/*ps_pcie_dma_chann_desc_t*/struct work_struct *work/*ptr_chann_desc, enum dma_data_direction dr*/)

{
	ps_pcie_dma_chann_desc_t *ptr_chann_desc = (ps_pcie_dma_chann_desc_t *)container_of(work, ps_pcie_dma_chann_desc_t, intrh_work);
	ps_pcie_sta_desc_t *ptr_sta_desc = NULL;
	unsigned int dbg_flag = 1;
	unsigned short cntxt_hndl;
	unsigned short uid;
	unsigned int compl_bytes = 0;
	enum dma_data_direction dr;
	unsigned int regval;
	unsigned int offset;

	u8 __iomem *ptr_chan_dma_reg_vbaddr = ptr_chann_desc->chan_dma_reg_vbaddr;

	if(ptr_chann_desc->dir == IN) 
	{
		dr = DMA_FROM_DEVICE;
	}
	else
	{
		dr = DMA_TO_DEVICE;
	}

	/* Go through the status q BD elements */
	ptr_sta_desc = &ptr_chann_desc->ptr_sta_q[ptr_chann_desc->idx_sta_q];

	while(ptr_sta_desc->completed ) 
	{
		data_q_cntxt_t *ptr_ctx = NULL;
		data_q_cntxt_t *ptr_postps_start_ctx = NULL;
		unsigned int tmp_bd_idx;
		unsigned int eop_bd_idx;
		unsigned int num_frags = 0;
		unsigned int offset = 0;
		void *data = NULL;
		func_ptr_dma_chann_cbk_noblock cbk;
#ifdef DBG_PRNT
		printk(KERN_ERR"\nStatus Q BD element index %d\n",ptr_chann_desc->idx_sta_q);
#endif

		/* Check for errors */
		if(ptr_sta_desc->dst_err == 1) 
		{
			printk(KERN_ERR"\nDestination error detected\n");
			ptr_chann_desc->chann_state = XLNX_DMA_DST_ERROR;
			ptr_chann_desc->src_sgl_err++;
			break;
		}

		if(ptr_sta_desc->src_err == 1) 
		{
			printk(KERN_ERR"\nSource error detected\n");
			ptr_chann_desc->chann_state = XLNX_DMA_SRC_ERROR;
			ptr_chann_desc->dst_sgl_err++;
			break;
		}

		if(ptr_sta_desc->intrnl_error == 1) 
		{
			printk(KERN_ERR"\nInternal error detected\n");
			ptr_chann_desc->chann_state = XLNX_DMA_INTRNL_ERROR;
			ptr_chann_desc->internal_err++;
			break;
		}

		if(ptr_sta_desc->upper_sta_nz == 0) 
		{
			printk(KERN_ERR"\nERROR Upper fields have no data!!\n");
			ptr_chann_desc->chann_state = XLNX_DMA_USRDATA_ERROR;
			break;
		}
		else
		{
			cntxt_hndl = ptr_sta_desc->usr_handle;
			uid = ptr_sta_desc->usr_id;
			compl_bytes = ptr_sta_desc->compl_bytes;
		}

		ptr_ctx = &ptr_chann_desc->ptr_ctx[cntxt_hndl];
		ptr_postps_start_ctx = &ptr_chann_desc->ptr_ctx[ptr_chann_desc->idx_rxpostps_cntxt_q];
		tmp_bd_idx = /*ptr_ctx*/ptr_postps_start_ctx->sop_bd_idx;
		eop_bd_idx = ptr_ctx->eop_bd_idx;
#ifdef DBG_PRNT
		printk(KERN_ERR"\nUser handle %d, Uid %x, SOP BD-%d, EOP BD-%d Context Pointer %p",cntxt_hndl, uid, tmp_bd_idx, eop_bd_idx, ptr_ctx);
#endif
		do
		{
			if(dr == DMA_TO_DEVICE) 
			{
				ps_pcie_src_bd_t *ptr_src_bd = &ptr_chann_desc->ptr_data_q.ptr_src_q[tmp_bd_idx];
				dma_addr_t paddr_buf = (dma_addr_t)ptr_src_bd->phy_src_addr;
				size_t sz = (size_t)ptr_src_bd->byte_count;
#ifdef DBG_PRNT	
				printk(KERN_ERR"\nBD %d Unmapping buffer PA %p Size %d\n", tmp_bd_idx,(void*)paddr_buf, sz);
#endif


				if(ptr_ctx->at == VIRT_ADDR) 
				{
					/* Unmap buffer */
					dma_unmap_single(ptr_chann_desc->ptr_dma_desc->dev, paddr_buf, sz, dr);
				}

				/* Zero out src bd element */
				memset(ptr_src_bd, 0, sizeof(ps_pcie_src_bd_t));
			}
			else
				if(dr == DMA_FROM_DEVICE) 
				{
					ps_pcie_dst_bd_t *ptr_dst_bd = &ptr_chann_desc->ptr_data_q.ptr_dst_q[tmp_bd_idx];
					dma_addr_t paddr_buf = (dma_addr_t)ptr_dst_bd->phy_dst_addr;
					size_t sz = (size_t)ptr_dst_bd->byte_count;
#ifdef DBG_PRNT	
					printk(KERN_ERR"\nBD %d Unmapping buffer PA %p Size %d\n", tmp_bd_idx,(void*)paddr_buf, sz);
#endif
					if(ptr_ctx->at == VIRT_ADDR)
					{
						/* Unmap buffer */
						dma_unmap_single(ptr_chann_desc->ptr_dma_desc->dev, paddr_buf, sz, dr);
					}

					/* Zero out dst bd element */
					memset(ptr_dst_bd, 0, sizeof(ps_pcie_dst_bd_t));
				}

			num_frags++; //Increment numbr of frags for this packet
#ifdef DBG_PRNT
			printk(KERN_ERR"\nFor this packet start BD %d end BD %d Num frags %d\n", tmp_bd_idx,eop_bd_idx, num_frags);
#endif
			if(tmp_bd_idx == eop_bd_idx) 
			{
				break; //We have post processed each fragment
			}

			/* Increment sop bd index */
			tmp_bd_idx++;
			if(tmp_bd_idx == ptr_chann_desc->data_q_sz) 
			{
				tmp_bd_idx = 0;
			}

		}while(1);

		/* Increment number of packet io done by channel */
		ptr_chann_desc->num_pkts_io++;
		/* Increment the number of BDs available for use */
		//ptr_chann_desc->num_free_bds += num_frags;
#if 1
		/* Fire callback if registered */
		if(ptr_postps_start_ctx->cbk) 
		{
#ifdef DBG_PRNT
			printk(KERN_ERR"\nCBK registered %d\n",ptr_chann_desc->num_pkts_io);
#endif
			cbk = ptr_postps_start_ctx->cbk;
			data = ptr_postps_start_ctx->data;
		}
		else
		{
#ifdef DBG_PRNT
			printk(KERN_ERR"\nCBK not registered\n");
#endif
		}
#endif

		/*
		 * Release the context element that correspond to the BD(s) that conatin the packet that was received
		 */
		do
		{
			bool done = false;
			data_q_cntxt_t *tmp_ptr_ctx = &ptr_chann_desc->ptr_ctx[ptr_chann_desc->idx_rxpostps_cntxt_q];
#ifdef DBG_PRNT	
			printk(KERN_ERR"\nZero context Q element data %x Q element frag src q index %d\n",tmp_ptr_ctx->data, tmp_ptr_ctx->sop_bd_idx);
#endif
			/* Zero out context element */
			memset(tmp_ptr_ctx, 0, sizeof(data_q_cntxt_t));
#ifdef DBG_PRNT
			printk(KERN_ERR"\nZero done\n");
#endif

			if(ptr_chann_desc->idx_rxpostps_cntxt_q == cntxt_hndl) 
			{
				done = true;
			}

			/* 
			 * Increment post processing context q index.
			 * This index should always give the next context elemnt at which post processing should start
			 */
			ptr_chann_desc->idx_rxpostps_cntxt_q++;
			if(ptr_chann_desc->idx_rxpostps_cntxt_q == ptr_chann_desc->sta_q_sz) 
			{
				ptr_chann_desc->idx_rxpostps_cntxt_q = 0;
			}

			if(done == true) 
			{
				break;
			}
		}while(1);


		/* Increment status q index */
		ptr_chann_desc->idx_sta_q++;
		if(ptr_chann_desc->idx_sta_q == ptr_chann_desc->sta_q_sz) 
		{
			ptr_chann_desc->idx_sta_q = 0;
		}

		/* Increment hardware status q index */
		ptr_chann_desc->idx_sta_q_hw++;
		if(ptr_chann_desc->idx_sta_q_hw == ptr_chann_desc->sta_q_sz) 
		{
			ptr_chann_desc->idx_sta_q_hw = 0;
		}

		dbg_flag = 0;

		/* Zero out the status descriptor element */
		memset(ptr_sta_desc, 0, sizeof(ps_pcie_sta_desc_t));

		/* Get pointer to next status descriptor */
		ptr_sta_desc = &ptr_chann_desc->ptr_sta_q[ptr_chann_desc->idx_sta_q];
#ifdef DBG_PRNT
		printk(KERN_ERR"\nStatus Q next BD to check index %d\n",ptr_chann_desc->idx_sta_q);
#endif

		wmb();

		if(ptr_chann_desc->dir == OUT) 
		{
			offset = DMA_SSTAQLMT_REG_OFFSET;
		}
		else
		{
			offset = DMA_DSTAQLMT_REG_OFFSET;
		}
		/* Increment status Q limit to index next status Q BD to use */
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, offset, ptr_chann_desc->idx_sta_q_hw);
		wmb();
		/*
		 * We now have some BDs & context free
		 */
		if( ptr_chann_desc->chann_state == XLNX_DMA_CNTXTQ_SATURATED ||
				ptr_chann_desc->chann_state == XLNX_DMA_CHANN_SATURATED ) 
		{
			ptr_chann_desc->chann_state = XLNX_DMA_CHANN_NO_ERR;
		}


		LOCK_DMA_CHANNEL(&ptr_chann_desc->channel_lock);
		if(cbk != NULL /*&& ptr_chann_desc->chann_state != XLNX_DMA_CHANN_IO_QUIESCED*/) 
		{
			/* Fire callback */
			cbk(ptr_chann_desc, data, compl_bytes, uid, num_frags);
		}
		UNLOCK_DMA_CHANNEL(&ptr_chann_desc->channel_lock);

	}

	if(ptr_chann_desc->ptr_dma_desc->pform == EP) 
	{
		offset = DMA_AXI_INTR_CNTRL_REG_OFFSET;
	}
	else
	{
		offset = DMA_AXI_INTR_CNTRL_REG_OFFSET;
	}

	rmb();
	/* Enable interrupts for this channel */
	regval = RD_DMA_REG(ptr_chan_dma_reg_vbaddr, offset);
	regval |= DMA_INTCNTRL_ENABLINTR_BIT;
	WR_DMA_REG(ptr_chan_dma_reg_vbaddr, offset,regval);

}

static /*inline*/ void ps_pcie_post_process_tx_qs(/*ps_pcie_dma_chann_desc_t*/struct work_struct *work/*ptr_chann_desc, enum dma_data_direction dr*/)
{
	ps_pcie_dma_chann_desc_t *ptr_chann_desc = (ps_pcie_dma_chann_desc_t *)container_of(work, ps_pcie_dma_chann_desc_t, intrh_work);
	ps_pcie_sta_desc_t *ptr_sta_desc = NULL;
	unsigned int dbg_flag = 1;
	unsigned short cntxt_hndl;
	unsigned short uid;
	unsigned int compl_bytes = 0;
	enum dma_data_direction dr;
	func_ptr_dma_chann_cbk_noblock cbk_all=NULL;
	unsigned int num_frags_all = 0;
	void *data_all = NULL;
	//unsigned long flags;
	unsigned int regval;
	unsigned int offset;
	u8 __iomem *ptr_chan_dma_reg_vbaddr = ptr_chann_desc->chan_dma_reg_vbaddr;

	if(ptr_chann_desc->dir == IN) 
	{
		dr = DMA_FROM_DEVICE;
	}
	else
	{
		dr = DMA_TO_DEVICE;
	}

	/* Go through the status q BD elements */
	ptr_sta_desc = &ptr_chann_desc->ptr_sta_q[ptr_chann_desc->idx_sta_q];

	while(ptr_sta_desc->completed ) 
	{
		data_q_cntxt_t *ptr_ctx = NULL;
		unsigned int tmp_bd_idx;
		unsigned int eop_bd_idx;
		unsigned int num_frags = 0;
		unsigned int offset = 0;
		void *data = NULL;
		func_ptr_dma_chann_cbk_noblock cbk;

	//	LOCK_DMA_CHANNEL(&ptr_chann_desc->channel_lock);
#ifdef DBG_PRNT
		printk(KERN_ERR"\nStatus Q BD element index %d\n",ptr_chann_desc->idx_sta_q);
#endif

		/* Check for errors */
		if(ptr_sta_desc->dst_err == 1) 
		{
			printk(KERN_ERR"\nDestination error detected\n");
			ptr_chann_desc->chann_state = XLNX_DMA_DST_ERROR;
			ptr_chann_desc->src_sgl_err++;
			break;
		}

		if(ptr_sta_desc->src_err == 1) 
		{
			printk(KERN_ERR"\nSource error detected\n");
			ptr_chann_desc->chann_state = XLNX_DMA_SRC_ERROR;
			ptr_chann_desc->dst_sgl_err++;
			break;
		}

		if(ptr_sta_desc->intrnl_error == 1) 
		{
			printk(KERN_ERR"\nInternal error detected\n");
			ptr_chann_desc->chann_state = XLNX_DMA_INTRNL_ERROR;
			ptr_chann_desc->internal_err++;
			break;
		}

		if(ptr_sta_desc->upper_sta_nz == 0) 
		{
			printk(KERN_ERR"\nERROR Upper fields have no data!!\n");
			ptr_chann_desc->chann_state = XLNX_DMA_USRDATA_ERROR;
			break;
		}
		else
		{
			cntxt_hndl = ptr_sta_desc->usr_handle;
			uid = ptr_sta_desc->usr_id;
			compl_bytes = ptr_sta_desc->compl_bytes;
		}

		ptr_ctx = &ptr_chann_desc->ptr_ctx[cntxt_hndl];
		tmp_bd_idx = ptr_ctx->sop_bd_idx;
		eop_bd_idx = ptr_ctx->eop_bd_idx;
#ifdef DBG_PRNT
		printk(KERN_ERR"\nUser handle %d, Uid %x, SOP BD-%d, EOP BD-%d Context Pointer %p",cntxt_hndl, uid, tmp_bd_idx, eop_bd_idx, ptr_ctx);
#endif

		//while(tmp_bd_idx != eop_bd_idx) 
		do
		{
			if(dr == DMA_TO_DEVICE) 
			{
				ps_pcie_src_bd_t *ptr_src_bd = &ptr_chann_desc->ptr_data_q.ptr_src_q[tmp_bd_idx];
				dma_addr_t paddr_buf = (dma_addr_t)ptr_src_bd->phy_src_addr;
				size_t sz = (size_t)ptr_src_bd->byte_count;
#ifdef DBG_PRNT	
				printk(KERN_ERR"\nBD %d Unmapping buffer PA %p Size %d\n", tmp_bd_idx,(void*)paddr_buf, sz);
#endif


				if(ptr_ctx->at == VIRT_ADDR) 
				{
					/* Unmap buffer */
					dma_unmap_single(ptr_chann_desc->ptr_dma_desc->dev, paddr_buf, sz, dr);
				}

				/* Zero out src bd element */
				memset(ptr_src_bd, 0, sizeof(ps_pcie_src_bd_t));
			}
			else
				if(dr == DMA_FROM_DEVICE) 
				{
					ps_pcie_dst_bd_t *ptr_dst_bd = &ptr_chann_desc->ptr_data_q.ptr_dst_q[tmp_bd_idx];
					dma_addr_t paddr_buf = (dma_addr_t)ptr_dst_bd->phy_dst_addr;
					size_t sz = (size_t)ptr_dst_bd->byte_count;
#ifdef DBG_PRNT	
					printk(KERN_ERR"\nBD %d Unmapping buffer PA %p Size %d\n", tmp_bd_idx,(void*)paddr_buf, sz);
#endif

					if(ptr_ctx->at == VIRT_ADDR)
					{
						/* Unmap buffer */
						dma_unmap_single(ptr_chann_desc->ptr_dma_desc->dev, paddr_buf, sz, dr);
					}

					/* Zero out dst bd element */
					memset(ptr_dst_bd, 0, sizeof(ps_pcie_dst_bd_t));
				}

			num_frags++; //Increment numbr of frags for this packet
#ifdef DBG_PRNT
			printk(KERN_ERR"\nFor this packet start BD %d end BD %d Num frags %d\n", tmp_bd_idx,eop_bd_idx, num_frags);
#endif

			if(tmp_bd_idx == eop_bd_idx) 
			{
				break; //We have post processed each fragment
			}

			/* Increment sop bd index */
			tmp_bd_idx++;
			if(tmp_bd_idx == ptr_chann_desc->data_q_sz) 
			{
				tmp_bd_idx = 0;
			}

		}while(1);

		/* Increment number of packet io done by channel */
		ptr_chann_desc->num_pkts_io++;
		/* Increment the number of BDs available for use */
		//ptr_chann_desc->num_free_bds += num_frags;
		
		/* Fire callback if registered */
		if(ptr_ctx->cbk) 
		{
#ifdef DBG_PRNT
			printk(KERN_ERR"\nCBK registered\n");
#endif
			cbk = ptr_ctx->cbk;
			data = ptr_ctx->data;
			cbk_all = ptr_ctx->cbk;
			data_all = ptr_ctx->data;

		}
		else
		{
			printk(KERN_ERR"\nCBK not registered\n");
		}
#ifdef DBG_PRNT
		//intk(KERN_ERR"\nZero out context data\n");
		printk(KERN_ERR"\nZero context Q element data %x Q element frag src q index %d\n",ptr_ctx->data, ptr_ctx->sop_bd_idx);
#endif
		/* Zero out context element */
		memset(ptr_ctx, 0, sizeof(data_q_cntxt_t));
#ifdef DBG_PRNT
		printk(KERN_ERR"\nZero done\n");
#endif


		/* Increment status q index */
		ptr_chann_desc->idx_sta_q++;
		if(ptr_chann_desc->idx_sta_q == ptr_chann_desc->sta_q_sz) 
		{
			ptr_chann_desc->idx_sta_q = 0;
		}

		/* Increment hardware status q index */
		ptr_chann_desc->idx_sta_q_hw++;
		if(ptr_chann_desc->idx_sta_q_hw == ptr_chann_desc->sta_q_sz) 
		{
			ptr_chann_desc->idx_sta_q_hw = 0;
		}

		dbg_flag = 0;

		//printk(KERN_ERR"\nPremature break, change check condition of this loop");
		//break;
		// 
		/* Zero out the status descriptor element */
		memset(ptr_sta_desc, 0, sizeof(ps_pcie_sta_desc_t));

		/* Get pointer to next status descriptor */
		ptr_sta_desc = &ptr_chann_desc->ptr_sta_q[ptr_chann_desc->idx_sta_q];
#ifdef DBG_PRNT
		printk(KERN_ERR"\nStatus Q next BD to check index %d\n",ptr_chann_desc->idx_sta_q);
#endif

		wmb();

		if(ptr_chann_desc->dir == OUT) 
		{
			offset = DMA_SSTAQLMT_REG_OFFSET;
		}
		else
		{
			offset = DMA_DSTAQLMT_REG_OFFSET;
		}

		/* Increment status Q limit to index next status Q BD to use */
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, offset, ptr_chann_desc->idx_sta_q_hw);

		wmb();

		/*
		 * We now have some BDs & context free
		 */
		if( ptr_chann_desc->chann_state == XLNX_DMA_CNTXTQ_SATURATED ||
				ptr_chann_desc->chann_state == XLNX_DMA_CHANN_SATURATED ) 
		{
			ptr_chann_desc->chann_state = XLNX_DMA_CHANN_NO_ERR;
		}

		LOCK_DMA_CHANNEL(&ptr_chann_desc->channel_lock);
		if(cbk != NULL /*&& ptr_chann_desc->chann_state != XLNX_DMA_CHANN_IO_QUIESCED*/) 
		{
			/* Fire callback */
			cbk(ptr_chann_desc, data, compl_bytes, uid, num_frags);
		}

		num_frags_all += num_frags;
		ptr_chann_desc->yield_weight--;
		UNLOCK_DMA_CHANNEL(&ptr_chann_desc->channel_lock);	
	}
#ifdef USE_LATER
	if(cbk_all != NULL /*&& ptr_chann_desc->chann_state != XLNX_DMA_CHANN_IO_QUIESCED*/) 
	{
		/* Fire callback */
		cbk_all(ptr_chann_desc, data_all, compl_bytes, uid, num_frags_all);
	}
#endif
	//LOCK_DMA_CHANNEL(&ptr_chann_desc->channel_lock);


	if(ptr_chann_desc->ptr_dma_desc->pform == EP) 
	{
		offset = DMA_AXI_INTR_CNTRL_REG_OFFSET;
	}
	else
	{
		offset = DMA_AXI_INTR_CNTRL_REG_OFFSET;
	}



	rmb();
	/* Enable interrupts for this channel */
	regval = RD_DMA_REG(ptr_chan_dma_reg_vbaddr, offset);
	regval |= DMA_INTCNTRL_ENABLINTR_BIT;
	WR_DMA_REG(ptr_chan_dma_reg_vbaddr, offset,regval);

}


/* Interrupt handler routines common to both EP & Host*/
static inline void ps_pcie_chann_intr_handlr(ps_pcie_dma_chann_desc_t *ptr_chann_desc, unsigned int intval, unsigned int offset)
{
	volatile unsigned int regval = intval;
	unsigned int val;

	/* Disable all the interrupts and move to polled context 
	*/	
	val= RD_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_AXI_INTR_CNTRL_REG_OFFSET);
	val &= 0xfffffffe;
	WR_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_AXI_INTR_CNTRL_REG_OFFSET,val);

	do
	{

		/* Clear the interrupt as we have cached the interrupt status */
		WR_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, offset, regval);

		wmb();

		if(regval & DMA_INTSTATUS_DMAERR_BIT) 
		{
			/* DMA error occured */
			printk(KERN_ERR"\nDMA error occured \n");
		}

		if(regval & DMA_INTSTATUS_SGLINTR_BIT) 
		{
#ifdef GENCHECK_MODE 
			if(ptr_chann_desc->chann_id == 0) 
			{
				queue_work_on(1,ptr_chann_desc->intr_handlr_wq, &ptr_chann_desc->intrh_work);
				queue_work_on(2,ptr_chann_desc->ptr_dma_desc->aux_channels[ptr_chann_desc->chann_id].intr_handlr_wq, 
						&(ptr_chann_desc->ptr_dma_desc->aux_channels[ptr_chann_desc->chann_id].intrh_work));
			}
			else
			{
				queue_work_on(3,ptr_chann_desc->intr_handlr_wq, &ptr_chann_desc->intrh_work);
				queue_work_on(4,ptr_chann_desc->ptr_dma_desc->aux_channels[ptr_chann_desc->chann_id].intr_handlr_wq, 
						&(ptr_chann_desc->ptr_dma_desc->aux_channels[ptr_chann_desc->chann_id].intrh_work));
			}
#else
			queue_work/*_on*/(/*1,*/ptr_chann_desc->intr_handlr_wq, &ptr_chann_desc->intrh_work);
#ifdef PFORM_USCALE_NO_EP_PROCESSOR
			queue_work/*_on*/(/*2,*/ptr_chann_desc->ptr_dma_desc->aux_channels[ptr_chann_desc->chann_id].intr_handlr_wq, 
					&(ptr_chann_desc->ptr_dma_desc->aux_channels[ptr_chann_desc->chann_id].intrh_work));
#endif
#endif
		}

		if(regval & DMA_INTSTATUS_SWINTR_BIT) 
		{
			/* SW interrupt occured */
#ifdef DBG_PRNT
			printk(KERN_ERR"\nSW interrupt occurred \n");
#endif
			if(ptr_chann_desc->scrtch_pad_io_in_progress == true) 
			{
				/* We are blocking to receive a scratch pad command response */
				up(&ptr_chann_desc->scratch_sem);
				ptr_chann_desc->scrtch_pad_io_in_progress = false;
			}
#if defined(VIDEO_ACC_DESIGN)
			/* Received a user application command */
			if(ptr_chann_desc->dbell_cbk) {
				unsigned int command = *((unsigned int*)(ptr_chann_desc->chan_dma_reg_vbaddr + DMA_SCRATCH0_REG_OFFSET));
				log_normal(KERN_ERR"\nFor channel %d Scratch pad Pointer %p Command %x Rx\n",
						ptr_chann_desc->chann_id,((unsigned int*)(ptr_chann_desc->chan_dma_reg_vbaddr + DMA_SCRATCH0_REG_OFFSET)),
						command);
				ptr_chann_desc->dbell_cbk(ptr_chann_desc,(unsigned int*)(ptr_chann_desc->chan_dma_reg_vbaddr + DMA_SCRATCH0_REG_OFFSET),DMA_NUM_SCRPAD_REGS);
			}
			else
			{
				ps_pcie_dma_chann_desc_t *ptr_aux_chann = &(ptr_chann_desc->ptr_dma_desc->aux_channels[ptr_chann_desc->chann_id]);

				if(ptr_aux_chann->dbell_cbk) {
					//printk(KERN_ERR "Triggering AUX Callback !!!!!\n");
					//ptr_aux_chann->dbell_cbk(ptr_chann_desc,(unsigned int*)(ptr_chann_desc->chan_dma_reg_vbaddr + DMA_SCRATCH0_REG_OFFSET),DMA_NUM_SCRPAD_REGS);

				}

			}
			val= RD_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_PCIE_INTR_CNTRL_REG_OFFSET);
                	val |= DMA_INTCNTRL_ENABLINTR_BIT;
		 	WR_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_PCIE_INTR_CNTRL_REG_OFFSET,val);
#endif
		}

		rmb();

		regval = RD_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, offset);
	}while(regval);

	/* Enable coalesce count timer */
	if(ptr_chann_desc->coalse_cnt_set == true /*&& timer_pending(&ptr_chann_desc->coal_cnt_timer) == false*/) 
	{
		ptr_chann_desc->coal_cnt_timer.expires = jiffies + COALESCE_TIMER_MAGNITUDE;
		add_timer(&ptr_chann_desc->coal_cnt_timer);
	}
}

void coalesce_cnt_bd_process_tmr(unsigned long arg)
{
	ps_pcie_dma_chann_desc_t *ptr_chann_desc = (ps_pcie_dma_chann_desc_t *)arg;

	printk(KERN_ERR"\nCoalesce count triggered for channel %d\n",ptr_chann_desc->chann_id);

	queue_work_on(1,ptr_chann_desc->intr_handlr_wq, &ptr_chann_desc->intrh_work);
#ifdef PFORM_USCALE_NO_EP_PROCESSOR
	queue_work_on(2,ptr_chann_desc->ptr_dma_desc->aux_channels[ptr_chann_desc->chann_id].intr_handlr_wq, 
			&(ptr_chann_desc->ptr_dma_desc->aux_channels[ptr_chann_desc->chann_id].intrh_work));
#endif

	//add_timer(&ptr_chann_desc->coal_cnt_timer);
}

static irqreturn_t ps_pcie_intr_handler(int irq, void *data)
{
	irqreturn_t retval = IRQ_HANDLED;
	unsigned int i;
	unsigned int offset, offset1;
	ps_pcie_dma_chann_desc_t *ptr_temp_chann_desc = NULL;
	ps_pcie_dma_desc_t *ptr_dma_desc = (ps_pcie_dma_desc_t *)data;

#ifdef PFORM_USCALE_NO_EP_PROCESSOR
	ps_pcie_dma_chann_desc_t *ptr_temp_aux_chann_desc = NULL;
#endif
#ifdef DBG_PRNT
	printk(KERN_ERR"\nInterrupt %d handler invoked %p\n", irq, ptr_dma_desc);
#endif

	if(ptr_dma_desc->pform == EP) 
	{
		offset = DMA_AXI_INTR_STATUS_REG_OFFSET;
		offset1 = DMA_AXI_INTR_CNTRL_REG_OFFSET;
	}
	else
	{
		offset = DMA_AXI_INTR_STATUS_REG_OFFSET;
	}

	/* Chech interrupt register of each channel */
	for(i = 0; i < 	PS_PCIE_NUM_DMA_CHANNELS; i++) 
	{
		volatile unsigned int regval;
		ptr_temp_chann_desc = &ptr_dma_desc->channels[i];
#ifdef PFORM_USCALE_NO_EP_PROCESSOR
		ptr_temp_aux_chann_desc = &ptr_dma_desc->aux_channels[i];
#endif


		if(ptr_temp_chann_desc->channel_is_active == false
#ifdef PFORM_USCALE_NO_EP_PROCESSOR
				|| ptr_temp_aux_chann_desc->channel_is_active == false
#endif
		  ) 
		{
			continue;
		}


		/* Check interrupt status register of each channel */
		regval = RD_DMA_REG(ptr_temp_chann_desc->chan_dma_reg_vbaddr, offset);
		if(regval) 
		{
			//	unsigned int intr_cntrl_reg = 0;
#ifdef DBG_PRNT
			printk(KERN_ERR"\nInterrupt status %x Channel %d\n", regval, ptr_temp_chann_desc->chann_id);
#endif
#ifdef TEST_DBG_ON
			ptr_temp_chann_desc->interrupted = 1;	
#endif


			ps_pcie_chann_intr_handlr(ptr_temp_chann_desc, regval, offset);

		}
	}


#ifdef DBG_PRNT
	printk(KERN_ERR"\nInterrupt handled\n");
#endif

	return retval;
}

/*
 * Interfaces exported
 */
ps_pcie_dma_desc_t* xlnx_get_pform_dma_desc(void *prev_desc, unsigned short vendid, unsigned short devid)
{
	return &g_host_dma_desc; 

}
EXPORT_SYMBOL(xlnx_get_pform_dma_desc);

int xlnx_get_dma(void *dev, platform_t pform, ps_pcie_dma_desc_t **pptr_dma_desc)
{
	ps_pcie_dma_desc_t *ptr_temp_dma_desc = NULL;
	int retval = XLNX_SUCCESS;

	struct pci_dev *pdev = (struct pci_dev *)dev;

	printk(KERN_ERR"\nDMA get handle Host, device %p\n",pdev);

	*pptr_dma_desc = &g_host_dma_desc; 
	g_host_dma_desc.dev = &pdev->dev;

	ptr_temp_dma_desc = *pptr_dma_desc;

	return retval;
}
EXPORT_SYMBOL(xlnx_get_dma);

int xlnx_release_dma(ps_pcie_dma_desc_t *ptr_dma_desc)
{
	return XLNX_SUCCESS;
}
EXPORT_SYMBOL(xlnx_release_dma);


int xlnx_get_dma_channel(ps_pcie_dma_desc_t *ptr_dma_desc, u32 channel_id, 
		direction_t dir, ps_pcie_dma_chann_desc_t **pptr_chann_desc,
		func_ptr_chann_health_cbk_no_block ptr_chann_health)
{
	int retval = XLNX_SUCCESS;
	unsigned long flags;
	ps_pcie_dma_chann_desc_t *p_temp_chan = NULL;


	printk(KERN_ERR"\nDMA get channel\n");

	spin_lock_irqsave(&ptr_dma_desc->dma_lock, flags);

	/* Perform sanity checks on parameters */
	if(ptr_dma_desc->num_channels_active == 0 || ptr_dma_desc->num_channels_alloc == ptr_dma_desc->num_channels_active) 
	{
		/* All channels allocated */
		retval = XLNX_NO_FREE_CHANNELS;
		goto error;
	}

	if(channel_id >= PS_PCIE_NUM_DMA_CHANNELS) 
	{
		/* Illegal channel number */
		retval = XLNX_ILLEGAL_CHANN_NO;
		goto error;
	}

	/* Get pointer to channel descriptor */
	p_temp_chan = &(ptr_dma_desc->channels[channel_id]);


	/* Check if channel already allocated. */
	if(p_temp_chan->channel_is_active == true) 
	{
#ifndef PFORM_USCALE_NO_EP_PROCESSOR
		/* Channel already allocated */
		retval = XLNX_CHANN_IN_USE;
		goto error;
#else
		/* Channel is allocated, allocate from auxillary channel array */
		p_temp_chan = &(ptr_dma_desc->aux_channels[channel_id]);
		p_temp_chan->is_aux_chann = true;
#endif
	}


#ifndef PFORM_USCALE_NO_EP_PROCESSOR
	/* Checks done only if platform is host and we have software logic running on EP
	 * The EP software logic is expected to initialize one end of the channel before the HOST side logic 
	 * completed initialization of other end
	 */
	if(ptr_dma_desc->pform == HOST) 
	{
		p_temp_chan->ptr_func_health = ptr_chann_health;

		/* check if this channel is allocated in EP and direction is consistent */
		retval = nwl_dma_is_chann_alloc_ep(ptr_dma_desc, channel_id, dir);
		if(retval < XLNX_SUCCESS)
		{
			printk(KERN_ERR"\nChannel not allocated in EP as neded %d\n", retval);
			goto error;
		}

		/* Latch channel */
		p_temp_chan->latched = true;
	}
#endif

	/* Assign the DMA register base address for this channel */
	p_temp_chan->chan_dma_reg_vbaddr = ptr_dma_desc->dma_chann_reg_virt_base_addr + 
		(channel_id * DMA_REG_TOT_BYTES);
	printk(KERN_ERR"\nDMA channel %d base addr:: %p\n", channel_id, p_temp_chan->chan_dma_reg_vbaddr);

	/* All checks done, we can allocate this channel */
	p_temp_chan->dir = dir; //Set direction
	p_temp_chan->chann_id = channel_id; //Id of channel
	p_temp_chan->ptr_dma_desc = ptr_dma_desc; //Cache the associated DMA descriptor
	printk(KERN_ERR"\nDMA desc for channel %p\n",p_temp_chan->ptr_dma_desc);
	*pptr_chann_desc = p_temp_chan;

	/* Set channel as active */
	p_temp_chan->channel_is_active = true;
	p_temp_chan->chk_hbeat = true;
	/* Increment number of channel allocated */
	ptr_dma_desc->num_channels_alloc++;
	if (ptr_dma_desc->num_channels_alloc == 4)
		ptr_dma_desc->num_channels_alloc = ptr_dma_desc->num_channels_alloc - 2;
		

error:
	spin_unlock_irqrestore(&ptr_dma_desc->dma_lock,flags);
	printk(KERN_ERR"\nDMA get channel done %d\n",retval);

	return retval;

}
EXPORT_SYMBOL(xlnx_get_dma_channel);

int xlnx_alloc_queues(ps_pcie_dma_chann_desc_t *ptr_chann_desc,
		unsigned int *ptr_data_q_addr_hi, //Physical address
		unsigned int *ptr_data_q_addr_lo,//Physical address
		unsigned int *ptr_sta_q_addr_hi,//Physical address
		unsigned int *ptr_sta_q_addr_lo,//Physical address
		unsigned int q_num_elements)
{
	int retval = XLNX_SUCCESS;
	unsigned int data_q_elem_sz = sizeof(ps_pcie_dst_bd_t); //Src & Dst BD element have same size
	unsigned int sta_q_elem_sz = sizeof(ps_pcie_sta_desc_t);
	dma_addr_t data_q_paddr;
	dma_addr_t sta_q_paddr;
	u64 temp_u64 = 0;
	struct device *dev = ptr_chann_desc->ptr_dma_desc->dev;

	printk(KERN_ERR"\n allocate Qs DMA Channel %d %p %p %p %d %d\n",ptr_chann_desc->chann_id, ptr_chann_desc, dev, ptr_chann_desc->ptr_dma_desc,
			data_q_elem_sz,sta_q_elem_sz);

	// spin_lock_irqsave(&ptr_chann_desc->ptr_dma_desc->dma_lock, flags);

	if(ptr_chann_desc->ptr_data_q.ptr_q || ptr_chann_desc->ptr_sta_q) 
	{
		retval = XLNX_Q_ALREADY_ALLOC;
		goto error_q_already_allocated;
	}

	/* Allocate data Q */
	ptr_chann_desc->ptr_data_q.ptr_q = dma_zalloc_coherent(dev, data_q_elem_sz * q_num_elements,
			&data_q_paddr, GFP_KERNEL );	
	if(ptr_chann_desc->ptr_data_q.ptr_q == NULL) 
	{
		retval = XLNX_DATA_Q_ALLOC_FAIL;
		printk(KERN_ERR"\n Data Q allocation failed !!!!!!!!! ERROR \n");
		goto error_dataq_alloc_fail;
	}
	else
	{
		ptr_chann_desc->data_q_paddr = data_q_paddr;
		ptr_chann_desc->dat_q_sz = data_q_elem_sz * q_num_elements;
	}

	/* Allocate status Q */
	ptr_chann_desc->ptr_sta_q = dma_zalloc_coherent(dev, sta_q_elem_sz * q_num_elements,
			&sta_q_paddr, GFP_KERNEL );
	if(ptr_chann_desc->ptr_sta_q == NULL) 
	{
		retval = XLNX_STA_Q_ALLOC_FAIL;
		printk(KERN_ERR"\n Sta Q allocation failed !!!!!!!!! ERROR \n");
		goto error_staq_alloc_fail;
	}
	else
	{
		ptr_chann_desc->stat_q_paddr = sta_q_paddr;
		ptr_chann_desc->stat_q_sz = sta_q_elem_sz * q_num_elements;
	}

	printk(KERN_ERR"\n Channel %d Status Q %p\n",ptr_chann_desc->chann_id,ptr_chann_desc->ptr_sta_q);

#ifdef CONFIG_ARCH_DMA_ADDR_T_64BIT
	printk(KERN_ERR"\n System has 64 bit DMA address %p %p\n", (void*)data_q_paddr, (void*)sta_q_paddr);
	temp_u64 = (u64)data_q_paddr;
	temp_u64 &= (0xffffffff00000000);
	temp_u64 = temp_u64 >> 32;
	*ptr_data_q_addr_hi = (u32)temp_u64;
	temp_u64 = (u64)sta_q_paddr;
	temp_u64 &= (0xffffffff00000000);
	temp_u64 = temp_u64 >> 32;
	*ptr_sta_q_addr_hi = (u32)temp_u64;
#else
	printk(KERN_ERR"\n System has 32 bit DMA address %p %p\n", (void*)data_q_paddr, (void*)sta_q_paddr);
	*ptr_data_q_addr_hi = 0;
	*ptr_sta_q_addr_hi = 0;
#endif

	*ptr_data_q_addr_lo = (u32)data_q_paddr;
	*ptr_sta_q_addr_lo = (u32)sta_q_paddr;

	/* Allocate the context array */
	ptr_chann_desc->ptr_ctx = kzalloc(sizeof(data_q_cntxt_t) * q_num_elements, GFP_KERNEL);
	if(ptr_chann_desc->ptr_ctx == NULL) 
	{
		retval = XLNX_CNTX_ARR_ALLOC_FAIL;
		goto error_cntxq_alloc_fail;
	}
	//	ptr_chann_desc->cntxt_q_sz = sizeof(data_q_cntxt_t) * q_num_elements;

#ifdef USE_LATER 
	/* Initialize number of BDs that can be used */
	if(ptr_chann_desc->dir == IN) 
	{
		/*
		 * In case of rx, at start of day we will not preallocate all BDs as this will cause
		 * both next & limit pointers to be 0. This will cause IOs to not start at all.
		 * We will leave last BD empty. Next == 0 & limit == 3 (in cas there are say 4BDs) is what we should look like
		 * at start of day
		 */
		ptr_chann_desc->num_free_bds = q_num_elements - 1;
	}
	else
	{
		ptr_chann_desc->num_free_bds = q_num_elements;
	}
#endif

	printk(KERN_ERR"\n Allocated DataQ Hi: %x DataQ Lo: %x StaQ Hi: %x StaQ Lo %x\n",*ptr_data_q_addr_hi,
			*ptr_data_q_addr_lo, *ptr_sta_q_addr_hi, *ptr_sta_q_addr_lo );


	printk(KERN_ERR"\n DMA allocate queues done %d\n",retval);

	return retval;

	//Deallocate appropriately in case of errors
error_cntxq_alloc_fail:
	dma_free_coherent(dev, sta_q_elem_sz * q_num_elements, ptr_chann_desc->ptr_sta_q, sta_q_paddr);	
error_staq_alloc_fail:
error_dataq_alloc_fail:
	dma_free_coherent(dev, data_q_elem_sz * q_num_elements, ptr_chann_desc->ptr_data_q.ptr_q, data_q_paddr);	
error_q_already_allocated:
	//spin_unlock_irqrestore(&ptr_chann_desc->ptr_dma_desc->dma_lock,flags);

	printk(KERN_ERR"\n DMA allocate queues done %d\n",retval);

	return retval;
}
EXPORT_SYMBOL(xlnx_alloc_queues);

int xlnx_dealloc_queues(ps_pcie_dma_chann_desc_t *ptr_chann_desc)
{
	int ret = XLNX_SUCCESS;
	printk(KERN_ERR"\n Deallocate Qs DMA Channel %d %p\n",ptr_chann_desc->chann_id, ptr_chann_desc);

	/* Free the context array */
	kfree(ptr_chann_desc->ptr_ctx);

	/* Free Data Descriptor Q */
	dma_free_coherent(ptr_chann_desc->ptr_dma_desc->dev,
			ptr_chann_desc->dat_q_sz, ptr_chann_desc->ptr_data_q.ptr_q, ptr_chann_desc->data_q_paddr);

	/* Free Status Descriptor Q */
	dma_free_coherent(ptr_chann_desc->ptr_dma_desc->dev,
			ptr_chann_desc->stat_q_sz, ptr_chann_desc->ptr_sta_q, ptr_chann_desc->stat_q_paddr);

	ptr_chann_desc->ptr_data_q.ptr_q = ptr_chann_desc->ptr_sta_q = NULL;

	printk(KERN_ERR"\n DMA deallocate queues done %d\n",ret);

	return ret;

}
EXPORT_SYMBOL(xlnx_dealloc_queues);


/* 
 * NOTE: API does not take any lock. It is imperative that 'channel_lock' be taken before calling this API.
 * In case 'xlnx_data_frag_io' needs to be called on this channel post calling this function, it is highly reccomended that 'xlnx_data_frag_io' 
 * be called without relinquishing the channel_lock' that was taken for invoking this API
 */
inline unsigned int xlnx_get_chann_num_free_bds(ps_pcie_dma_chann_desc_t *ptr_chan_desc)
{
	return 0;//ptr_chan_desc->num_free_bds;
}
EXPORT_SYMBOL(xlnx_get_chann_num_free_bds);

/* 
 * NOTE: This API assumes that the caller has taken the channel lock across succesive calls to the API to transmit
 * data distributed across multiple fragments
 */
inline int xlnx_data_frag_io(ps_pcie_dma_chann_desc_t *ptr_chan_desc, 
		unsigned char *addr_buf, 
		addr_type_t at,
		size_t sz,
		func_ptr_dma_chann_cbk_noblock cbk,
		unsigned short uid, 
		bool last_frag, /*direction_t dir,*/
		void *ptr_user_data)
{
	int ret = XLNX_SUCCESS;
	dataq_ptr_t ptr_dq =ptr_chan_desc->ptr_data_q;
	data_q_cntxt_t *ptr_ctx = NULL;
	dma_addr_t paddr_buf;
	enum dma_data_direction dr;
	unsigned int offset = 0;

	if(ptr_chan_desc->chann_state == XLNX_DMA_CHANN_IO_QUIESCED) 
	{
		return XLNX_DMA_CHANN_SW_ERR;
	}

	/* determine direction of DMA transfer */
	if(ptr_chan_desc->dir == OUT) 
	{
		dr = DMA_TO_DEVICE;
	}
	else
	{
		dr = DMA_FROM_DEVICE;

		/*
		 * We will have a context for each BD allocated. Hence we will mark each fragment in receive direction
		 * as 'last fragment'
		 */
		last_frag = true;
	}


	if(at == VIRT_ADDR) 
	{
		/* Map the buffer */
		paddr_buf = dma_map_single(ptr_chan_desc->ptr_dma_desc->dev, addr_buf, sz, dr);
#ifdef DBG_PRNT
		printk(KERN_ERR"\n Mapped buffer %p size %d", (void*)paddr_buf, sz);
#endif
	}
	else
	{
		paddr_buf = (dma_addr_t)addr_buf;
	}

	if(ptr_chan_desc->chann_state != XLNX_DMA_CHANN_NO_ERR) 
	{
		log_normal(KERN_ERR"\nDMA channel %d in error state %d\n",ptr_chan_desc->chann_id, ptr_chan_desc->chann_state);
		ret = XLNX_DMA_CHANN_SW_ERR;
		goto error_channel;
	}
#ifdef USE_LATER 
	/* Check if we have BDs free */
	if(ptr_chan_desc->num_free_bds == 0) 
	{
		/* We do not have BDs free */
		printk(KERN_ERR"\n BD list saturated\n");
		ret = XLNX_DMA_CHANN_SW_ERR;
		ptr_chan_desc->chann_state = XLNX_DMA_CHANN_SATURATED;
		goto error_channel;
	}
	else
	{
		printk(KERN_ERR"\nNum BDs %d\n",ptr_chan_desc->num_free_bds);
	}
#endif

	if(last_frag == true) 
	{
		/* This is last fragment, we need to find a context */
		ptr_ctx = &ptr_chan_desc->ptr_ctx[ptr_chan_desc->idx_cntxt_q];

		/* Check if the context is free */
		if(ptr_ctx->under_use == true)
		{
			//printk(KERN_ERR"\nPump next rx frag chann %d\n",ptr_chann->chann_id);
			ptr_chan_desc->chann_state = XLNX_DMA_CNTXTQ_SATURATED;
			ptr_chan_desc->saturate_flag = true;
#ifdef DBG_PRNT
			printk(KERN_ERR"\nDMA channel %d in error state %d\n",ptr_chan_desc->chann_id, ptr_chan_desc->chann_state);
			printk(KERN_ERR"\nContext Q %p Saturated Q element index %d Q element data %x Q element frag src q index %d\n",ptr_ctx, ptr_chan_desc->idx_cntxt_q,
					ptr_ctx->data, ptr_ctx->sop_bd_idx);
#endif

			{
#ifdef DBG_PRNT
				unsigned int i;
				unsigned char *p = (unsigned char*)ptr_ctx;
				printk(KERN_ERR"\nContext Q contents\n");

				for(i = 0; i < sizeof(data_q_cntxt_t); i++) 
				{
					printk(KERN_ERR"Data Byte-%d %x ",i,p[i]);

					if(i == 8) 
					{
						printk("\n");
					}
				}
#endif
			}
			ret = XLNX_DMA_CHANN_SW_ERR;
			goto error_channel;
		}
		else
		{
			ptr_ctx->under_use = true;
#ifdef DBG_PRNT
			printk(KERN_ERR"\nGot a context %p", ptr_ctx);
#endif
		}
	}

	/* Get ourselves an unused BD element */
	if( ptr_chan_desc->dir == OUT) 
	{
		ps_pcie_src_bd_t *ptr_src_bd = &ptr_dq.ptr_src_q[ptr_chan_desc->unusd_bd_idx_data_q];

		/* Check if BD is indeed unused */
		if(ptr_src_bd->phy_src_addr) 
		{
			printk(KERN_ERR"\nDMA channel %d saturated, no free BD element. Unused index %d\n",ptr_chan_desc->chann_id, ptr_chan_desc->unusd_bd_idx_data_q);
			ptr_chan_desc->chann_state = XLNX_DMA_CHANN_SATURATED;
			ret = XLNX_DMA_CHANN_SW_ERR;
			goto error_channel;
		}
#ifdef DBG_PRNT
		printk(KERN_ERR"\nDMA channel %d , found BD element. Unused index %d\n",ptr_chan_desc->chann_id, ptr_chan_desc->unusd_bd_idx_data_q);
#endif

		/* BD is free we will use it */
		ptr_src_bd->phy_src_addr = (unsigned long long)paddr_buf;
		ptr_src_bd->byte_count = sz;
    		/* Drives the AxCACHE attribute to enable upsizing only */
		ptr_src_bd->dma_data_rd_attr = 0x2;
		if(ptr_chan_desc->ptr_dma_desc->pform == EP) 
		{
			ptr_src_bd->loc_axi = 1;
		}
#ifdef PFORM_USCALE_NO_EP_PROCESSOR
#ifdef ROOT_PORT_PFORM_NO_EP_PROCESSOR
		ptr_src_bd->loc_axi = 1;
		if(at == EP_PHYS_ADDR)
		{
			ptr_src_bd->loc_axi = 0;
     		 // Keep it to default 0x3 for KCU105 EP design
			ptr_src_bd->dma_data_rd_attr = 0x3;
		}								                
#else										
		else
		{
			if(at == EP_PHYS_ADDR) 
			{
				/* Buffer is on AXI memory */
				ptr_src_bd->loc_axi = 1;
			}
		}
#endif
#endif

		if(last_frag == true) 
		{
			ptr_src_bd->eop = 1;
			ptr_src_bd->intr = 1; //We want interrupt after status Q is written
			ptr_src_bd->usr_handle = ptr_chan_desc->idx_cntxt_q;
			ptr_src_bd->usr_id = uid;
		}
	}
	else
	{
		ps_pcie_dst_bd_t *ptr_dst_bd = &ptr_dq.ptr_dst_q[ptr_chan_desc->unusd_bd_idx_data_q];

		/* Check if BD is indeed unused */
		if(ptr_dst_bd->phy_dst_addr) 
		{
			printk(KERN_ERR"\n DMA channel %d saturated, no free BD element. Unused index %d\n",ptr_chan_desc->chann_id, ptr_chan_desc->unusd_bd_idx_data_q);
			ptr_chan_desc->chann_state = XLNX_DMA_CHANN_SATURATED;
			ret = XLNX_DMA_CHANN_SW_ERR;
			goto error_channel;
		}
#ifdef DBG_PRNT
		printk(KERN_ERR"\n DMA channel %d , found BD element. Unused index %d\n",ptr_chan_desc->chann_id, ptr_chan_desc->unusd_bd_idx_data_q);
#endif

		/* BD is free we will use it */
		ptr_dst_bd->phy_dst_addr = (unsigned long long)paddr_buf;
		ptr_dst_bd->byte_count = sz;

		if(ptr_chan_desc->ptr_dma_desc->pform == EP) 
		{
			ptr_dst_bd->loc_axi = 1;
		}
		/* Drives the AxCACHE attribute to enable upsizing only */
		ptr_dst_bd->dma_data_rd_attr = 0x2;
#ifdef PFORM_USCALE_NO_EP_PROCESSOR
#ifdef ROOT_PORT_PFORM_NO_EP_PROCESSOR
	    ptr_dst_bd->loc_axi = 1;
		if(at == EP_PHYS_ADDR) 
		{
			ptr_dst_bd->loc_axi = 0;
      		// Keep it to default 0x3 for KCU105 EP design
			ptr_dst_bd->dma_data_rd_attr = 0x3;
		}
#else
		else
		{
			if(at == EP_PHYS_ADDR) 
			{
				/* Buffer is on AXI memory */

				ptr_dst_bd->loc_axi = 1;
			}
		}
#endif
#endif
		ptr_dst_bd->use_nxt_bd_on_eop = 1;
		ptr_dst_bd->usr_handle = ptr_chan_desc->idx_cntxt_q;
	}

	if(ptr_ctx) 
	{
		/* Populate the context element */
		ptr_ctx->cbk = cbk;
		ptr_ctx->eop_bd_idx = ptr_chan_desc->unusd_bd_idx_data_q;
		ptr_ctx->sop_bd_idx = ptr_chan_desc->sop_bd_idx_data_q;
		ptr_ctx->data = ptr_user_data;
		ptr_ctx->at = at;
		/* Increment context index */
		ptr_chan_desc->idx_cntxt_q++;
		if(ptr_chan_desc->idx_cntxt_q == ptr_chan_desc->data_q_sz) 
		{
			ptr_chan_desc->idx_cntxt_q = 0;
		}
	}

	/* Update the data q indexes */
	ptr_chan_desc->unusd_bd_idx_data_q++;
	if(ptr_chan_desc->unusd_bd_idx_data_q == ptr_chan_desc->data_q_sz /*- 1*/) 
	{
		ptr_chan_desc->unusd_bd_idx_data_q = 0;
	}

	if(last_frag == true) 
	{
		/* This was the last frag. Next BD element will be start of packet (sop) */
		ptr_chan_desc->sop_bd_idx_data_q = ptr_chan_desc->unusd_bd_idx_data_q;
	}

	if(ptr_chan_desc->dir == OUT) 
	{
		offset = DMA_SRCQLMT_REG_OFFSET;
	}
	else
	{
		offset = DMA_DSTQLMT_REG_OFFSET;
	}

	/* Decrement number of BDs avaliable */
	//ptr_chan_desc->num_free_bds--;

	wmb();

	/* Program the hardware with new Q limit value */
	WR_DMA_REG(ptr_chan_desc->chan_dma_reg_vbaddr, offset, ptr_chan_desc->unusd_bd_idx_data_q);

	//	printk(KERN_ERR"\n New Q limit value %d\n",ptr_chan_desc->unusd_bd_idx_data_q);
	return XLNX_SUCCESS;
error_channel:

	if(at == VIRT_ADDR) 
	{
		/* Unmap buffer */
		dma_unmap_single(ptr_chan_desc->ptr_dma_desc->dev, paddr_buf, sz, dr);
	}

	return ret;
}
EXPORT_SYMBOL(xlnx_data_frag_io);

int xlnx_activate_dma_channel(ps_pcie_dma_desc_t *ptr_dma_desc, 
		ps_pcie_dma_chann_desc_t *ptr_chann_desc,
		unsigned int data_q_addr_hi, //Physical address
		unsigned int data_q_addr_lo,//Physical address
		unsigned int data_q_sz,
		unsigned int sta_q_addr_hi,//Physical address
		unsigned int sta_q_addr_lo,//Physical address
		unsigned int sta_q_sz,
		unsigned char coalesce_cnt //Coalesce count for SGL interrupt resporting
		)
{
	int ret = XLNX_SUCCESS;
	//unsigned long flags;
	unsigned int regval = 0;
	u8 __iomem *ptr_chan_dma_reg_vbaddr = ptr_chann_desc->chan_dma_reg_vbaddr;
	unsigned int intr_msk = 0;
	unsigned int offset = 0;
	char buffer[50];

	printk(KERN_ERR"\n Activate DMA Channel %d %p %p\n",ptr_chann_desc->chann_id, ptr_chan_dma_reg_vbaddr,ptr_dma_desc);

	/* Ceate workqueue if not created */
	if(ptr_chann_desc->intr_handlr_wq == NULL) 
	{
		sprintf(buffer, "PS PCIe DMA Channel %d Intr handler WQ",ptr_chann_desc->chann_id);
		ptr_chann_desc->intr_handlr_wq = create_singlethread_workqueue((const char*)buffer);
		if(ptr_chann_desc->intr_handlr_wq == NULL) 
		{
			printk(KERN_ERR"\n WQ creation failed %d\n", ptr_chann_desc->chann_id);
			goto error_wq_creat_failed;
		}
		else
		{
			if(ptr_chann_desc->dir == IN) 
			{
				INIT_WORK(&(ptr_chann_desc->intrh_work), ps_pcie_post_process_rx_qs/*, (void *)ptr_chann_desc*/);
			}
			else
			{
				INIT_WORK(&(ptr_chann_desc->intrh_work), ps_pcie_post_process_tx_qs/*, (void *)ptr_chann_desc*/);
			}
		}
	}

	/* If coalesce_cnt is set create timer to handle packets in a coalesce count scenario */
	if(coalesce_cnt && &ptr_chann_desc->coal_cnt_timer == NULL) 
	{
		/* Create timer */
		init_timer(&ptr_chann_desc->coal_cnt_timer);
		ptr_chann_desc->coal_cnt_timer.function = coalesce_cnt_bd_process_tmr;
		ptr_chann_desc->coal_cnt_timer.data = (void*)ptr_chann_desc;
		ptr_chann_desc->coal_cnt_timer.expires = jiffies + COALESCE_TIMER_MAGNITUDE;
		printk(KERN_ERR"\n Invoke BD processing timer %p\n", &ptr_chann_desc->coal_cnt_timer);
		add_timer(&ptr_chann_desc->coal_cnt_timer);

		/* Set coalesce count flag */
		ptr_chann_desc->coalse_cnt_set = true;
	}

	/* Initialize scratch pad communication blocking semaphore & serialization MUTEX */
	sema_init(&(ptr_chann_desc->scratch_sem), 0);
	sema_init(&(ptr_chann_desc->scratch_mutx), 1);

	//spin_lock_irqsave(&ptr_dma_desc->dma_lock, flags);

	if(data_q_addr_lo & 0x3f || sta_q_addr_lo & 0x3f) 
	{
		/* Unaligned Q base address */
		ret = XLNX_Q_UNALIGNED_64BYT;
		goto error_unaligned_q;
	}

	/* Check if channel is active */
	regval = RD_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_STATUS_REG_OFFSET);
	if(regval & DMA_STATUS_DMA_RUNNING_BIT) {
		ret = XLNX_CHANN_ACTIVE;
		goto error;
	}

#ifdef PFORM_USCALE_NO_EP_PROCESSOR
	if(ptr_chann_desc->is_aux_chann == true)
#else
		if(ptr_dma_desc->pform == EP)
#endif
		{
			/* Reset the DMA channel */
			regval = RD_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_CNTRL_REG_OFFSET);
			regval |= (DMA_CNTRL_RST_BIT);
			WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_CNTRL_REG_OFFSET, regval);

			/* Give 10ms delay for reset to complete */
			mdelay(10);

			regval = RD_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_CNTRL_REG_OFFSET);
			regval &= (~(DMA_CNTRL_RST_BIT));
			WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_CNTRL_REG_OFFSET, regval);
		}


	/* Pogram Q addresses */
	ptr_chann_desc->data_q_sz = data_q_sz;
	ptr_chann_desc->sta_q_sz = sta_q_sz;

	data_q_addr_lo &= ~(0x3f); //Mask 6lsbs
	sta_q_addr_lo &= ~(0x3f); //Mask 6lsbs

	data_q_addr_lo |= DMA_QPTRLO_Q_ENABLE_BIT;
	sta_q_addr_lo |= DMA_QPTRLO_Q_ENABLE_BIT;

	if(ptr_chann_desc->ptr_dma_desc->pform == EP)
	{
		/* Tell hardwrae that Q is resident on AXI memory */
		data_q_addr_lo |= DMA_QPTRLO_QLOCAXI_BIT;
		sta_q_addr_lo |= DMA_QPTRLO_QLOCAXI_BIT;
	}
	
	data_q_addr_lo |= DMA_QPTRLO_QLOCAXI_BIT;	
	sta_q_addr_lo |= DMA_QPTRLO_QLOCAXI_BIT;


  	// Enabling read attribute to drive AxCACHE[1] bit for upsizing
	data_q_addr_lo |= DMA_QPTRLO_Q_READ_ATTR;	
	sta_q_addr_lo |= DMA_QPTRLO_Q_READ_ATTR;

	if(data_q_sz < PS_PCIE_MIN_Q_SZ) 
	{
		ret = XLNX_ILLEGAL_Q_SZ;
		goto error;
	}

	/* Set the hardware status Q sliding index */
	ptr_chann_desc->idx_sta_q_hw = sta_q_sz - 1;

	if(ptr_chann_desc->dir == OUT) 
	{
		/* SRC Q */
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_SRCQNXT_REG_OFFSET, 0);
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_SRCQPTRLO_REG_OFFSET, data_q_addr_lo);
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_SRCQPTRHI_REG_OFFSET, data_q_addr_hi);
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_SRCQSZ_REG_OFFSET, data_q_sz);
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_SRCQLMT_REG_OFFSET, 0);

		/* SRC STA Q */
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_SSTAQNXT_REG_OFFSET, 0);
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_SSTAQPTRLO_REG_OFFSET, sta_q_addr_lo);
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_SSTAQPTRHI_REG_OFFSET, sta_q_addr_hi);
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_SSTAQSZ_REG_OFFSET, sta_q_sz);
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_SSTAQLMT_REG_OFFSET, ptr_chann_desc->idx_sta_q_hw);
	}
	else
	{
		/* DST Q */
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_DSTQNXT_REG_OFFSET, 0);
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_DSTQPTRLO_REG_OFFSET, data_q_addr_lo);
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_DSTQPTRHI_REG_OFFSET, data_q_addr_hi);
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_DSTQSZ_REG_OFFSET, data_q_sz);
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_DSTQLMT_REG_OFFSET, 0);

		/* DST STA Q */
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_DSTAQNXT_REG_OFFSET, 0);
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_DSTAQPTRLO_REG_OFFSET, sta_q_addr_lo);
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_DSTAQPTRHI_REG_OFFSET, sta_q_addr_hi);
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_DSTAQSZ_REG_OFFSET, sta_q_sz);
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_DSTAQLMT_REG_OFFSET, ptr_chann_desc->idx_sta_q_hw);
	}

	wmb();

	/* Enable interrupts */
	intr_msk |= (DMA_INTCNTRL_ENABLINTR_BIT | DMA_INTCNTRL_DMAERRINTR_BIT | DMA_INTSTATUS_DMASGINTR_BIT);
	intr_msk |= (coalesce_cnt  << DMA_INTSTATUS_SGCOLSCCNT_BIT_SHIFT);
	if(ptr_dma_desc->pform == HOST) 
	{
		offset = DMA_AXI_INTR_CNTRL_REG_OFFSET;		
	}
	else
	{
		offset = DMA_AXI_INTR_CNTRL_REG_OFFSET;
	}
	WR_DMA_REG(ptr_chan_dma_reg_vbaddr, offset, intr_msk);

	ptr_chann_desc->chann_state = XLNX_DMA_CHANN_NO_ERR; //Channel is doing good



	if(ptr_dma_desc->pform == HOST 
#ifdef PFORM_USCALE_NO_EP_PROCESSOR
			&& ptr_chann_desc->is_aux_chann == true
#endif
	  ) 
	{
		/* We are Host, we will now enable the channel */
		regval = RD_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_CNTRL_REG_OFFSET);
		regval |= ((DMA_CNTRL_64BIT_STAQ_ELEMSZ_BIT) | (DMA_CNTRL_ENABL_BIT));
		WR_DMA_REG(ptr_chan_dma_reg_vbaddr, DMA_CNTRL_REG_OFFSET, regval);
	}

	/* Channel is activated for ios */
	//ptr_chann_desc->channel_active_for_ios = true;

#ifdef POLL_MODE
	init_timer(&ptr_dma_desc->intr_poll_tmr);
	ptr_dma_desc->intr_poll_tmr.function = poll_intr_hndlr_fn;
	ptr_dma_desc->intr_poll_tmr.data = (void*)ptr_dma_desc;
	ptr_dma_desc->intr_poll_tmr.expires = jiffies + 1; /* parameter */
	printk(KERN_ERR"\n Invoke poll mode %p\n", &ptr_dma_desc->intr_poll_tmr);
	add_timer(&ptr_dma_desc->intr_poll_tmr);
#endif


error:
error_unaligned_q:
error_wq_creat_failed:
	//spin_unlock_irqrestore(&ptr_dma_desc->dma_lock,flags);

	printk(KERN_ERR"\n DMA activate channel done %d\n",ret);

	return ret;

}
EXPORT_SYMBOL(xlnx_activate_dma_channel);

int xlnx_deactivate_dma_channel(ps_pcie_dma_chann_desc_t *ptr_chann_desc)
{
	unsigned int intr_msk = 0;
	unsigned int offset = 0;
	ptr_chann_desc->chann_state = XLNX_DMA_CHANN_IO_QUIESCED;

	/* Disable interrupt from DMA channel */
	wmb();

	/* Disable interrupts */
	if(ptr_chann_desc->ptr_dma_desc->pform == HOST) 
	{
		offset = DMA_PCIE_INTR_CNTRL_REG_OFFSET;
	}
	else
	{
		offset = DMA_AXI_INTR_CNTRL_REG_OFFSET;
	}
	intr_msk |= (DMA_INTCNTRL_ENABLINTR_BIT);
	WR_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, offset, intr_msk);

	wmb();

	if(!in_atomic()) 
	{
		/* Flush workqueue */

		flush_workqueue(ptr_chann_desc->intr_handlr_wq);
		printk("Flushing Worker Queque\n");

		mdelay(10);

		destroy_workqueue(ptr_chann_desc->intr_handlr_wq);

		mdelay(10);
		ptr_chann_desc->intr_handlr_wq = NULL;
		if(ptr_chann_desc->coalse_cnt_set == true) 
		{
			del_timer_sync(&ptr_chann_desc->coal_cnt_timer);
		}
	}
	else
	{
		if(ptr_chann_desc->coalse_cnt_set == true) 
		{
			del_timer(&ptr_chann_desc->coal_cnt_timer);
		}
	}

	mdelay(1000);
	LOCK_DMA_CHANNEL(&ptr_chann_desc->channel_lock);

	/* Make DMA enable == 0 */
	{
		unsigned int regval = RD_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_CNTRL_REG_OFFSET);
		regval &= 0xfffffffe;
		WR_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_CNTRL_REG_OFFSET, regval);
	}

	mdelay(10);

	/* Check if the DMA is still running */
	{
		unsigned int regval = RD_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_STATUS_REG_OFFSET);
		if(regval & DMA_STATUS_DMA_RUNNING_BIT) 
		{
			printk(KERN_ERR"\n DMA still running, will reset!!");
		}
		else
		{
			printk(KERN_ERR"\n DMA quiet reset now\n");
		}
	}

	/* Reset DMA */
	{
		unsigned int regval = RD_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_CNTRL_REG_OFFSET);
		regval |= DMA_CNTRL_RST_BIT;
		WR_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_CNTRL_REG_OFFSET, regval);

		/* Give 10ms delay for reset to complete */
		mdelay(10);

		regval = RD_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_CNTRL_REG_OFFSET);
		regval &= (~(DMA_CNTRL_RST_BIT));
		WR_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_CNTRL_REG_OFFSET, regval);
	}

	/* Memset all Qs to 0*/
	memset(ptr_chann_desc->ptr_ctx, 0, sizeof(data_q_cntxt_t) * ptr_chann_desc->data_q_sz);
	memset(ptr_chann_desc->ptr_data_q.ptr_q, 0, sizeof(ps_pcie_src_bd_t) * ptr_chann_desc->data_q_sz);
	memset(ptr_chann_desc->ptr_sta_q, 0, sizeof(ps_pcie_sta_desc_t) * ptr_chann_desc->sta_q_sz);
	ptr_chann_desc->unusd_bd_idx_data_q = 0; //Index to slide on Data Q. Gives next unused BD
	ptr_chann_desc->sop_bd_idx_data_q = 0; //Index to slide on Data Q. Gives BD which has first fragment of packet data
	ptr_chann_desc->idx_cntxt_q = 0; //Index to slide on Context Q. Gives next unused context
	ptr_chann_desc->idx_rxpostps_cntxt_q = 0; //Index to slide on Context Q. Gives start context from where post processing begins
	ptr_chann_desc->idx_sta_q = 0; //Index to slide on status Q.
	ptr_chann_desc->idx_sta_q_hw = 0;

	ptr_chann_desc->ptr_dma_desc->num_channels_alloc--;
	UNLOCK_DMA_CHANNEL(&ptr_chann_desc->channel_lock);


	/* Disable the channel */
	return XLNX_SUCCESS;
}
EXPORT_SYMBOL(xlnx_deactivate_dma_channel);

int xlnx_stop_channel_IO(ps_pcie_dma_chann_desc_t *ptr_chann_desc, bool do_rst)
{
	int ret_val = XLNX_SUCCESS;
	//spin_lock_bh(&ptr_chann_desc->channel_lock);
	ptr_chann_desc->chann_state = XLNX_DMA_CHANN_IO_QUIESCED;
	//spin_unlock_bh(&ptr_chann_desc->channel_lock);

#ifndef PFORM_USCALE_NO_EP_PROCESSOR
	if(do_rst == true) 
	{
		int ret;
		unsigned int host_2_card_data[DMA_NUM_SCRPAD_REGS] = {0};
		unsigned int card_2_host_data[DMA_NUM_SCRPAD_REGS] = {0}; 

		/* Wait for outstanding IOs to get over */
		msleep(10);

		/* 
		 * We need to do a reset. We will make the EP side do the
		 * reset
		 */
		host_2_card_data[0] = XLNX_CMD_RESET_CHANN;

		ret = xlnx_do_scrtchpd_txn_from_host(ptr_chann_desc,
				host_2_card_data,
				DMA_NUM_SCRPAD_REGS,
				card_2_host_data,
				DMA_NUM_SCRPAD_REGS);
		if(ret == XLNX_SUCCESS && card_2_host_data[0] == XLNX_RSP_RESET_CHANN) 
		{
			printk(KERN_ERR"\n Received reset response channel %d", ptr_chann_desc->chann_id );
		}
	}
#else
	if(ptr_chann_desc->is_aux_chann == true) 
	{
		ptr_chann_desc->ptr_dma_desc->channels[ptr_chann_desc->chann_id].chann_state = XLNX_DMA_CHANN_IO_QUIESCED;
	}
	else
	{
		ptr_chann_desc->ptr_dma_desc->aux_channels[ptr_chann_desc->chann_id].chann_state = XLNX_DMA_CHANN_IO_QUIESCED;
	}
	/* Make DMA enable == 0 */
	{
		unsigned int regval = RD_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_CNTRL_REG_OFFSET);
		regval &= 0xfffffffe;
		WR_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_CNTRL_REG_OFFSET, regval);
	}

	mdelay(10);

	/* Check if the DMA is still running */
	{
		unsigned int regval = RD_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_STATUS_REG_OFFSET);
		if(regval & DMA_STATUS_DMA_RUNNING_BIT) 
		{
			printk(KERN_ERR"\n DMA still running, will reset!!");
		}
		else
		{
			printk(KERN_ERR"\n DMA quiet reset now\n");
		}
	}

	/* Reset DMA */
	{
		unsigned int regval = RD_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_CNTRL_REG_OFFSET);
		regval |= DMA_CNTRL_RST_BIT;
		WR_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_CNTRL_REG_OFFSET, regval);

		/* Give 10ms delay for reset to complete */
		mdelay(10);

		regval = RD_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_CNTRL_REG_OFFSET);
		regval &= (~(DMA_CNTRL_RST_BIT));
		WR_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_CNTRL_REG_OFFSET, regval);
	}

	rmb();

	/* Check if the DMA is still running */
	{
		unsigned int regval = RD_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_STATUS_REG_OFFSET);
		if(regval & DMA_STATUS_DMA_RUNNING_BIT) 
		{
			printk(KERN_ERR"\n DMA still running, after reset!!");
		}
	}

#endif

	return ret_val;
}
EXPORT_SYMBOL(xlnx_stop_channel_IO);


/*
 * Invoked by DMA driver when there is doorbell data from HOST
 */
void xlnx_register_doorbell_cbk(ps_pcie_dma_chann_desc_t *ptr_chann_desc,
		func_doorbell_cbk_no_block ptr_fn_drbell_cbk)
{
	unsigned long flags;

	spin_lock_irqsave(&ptr_chann_desc->channel_lock, flags);
	ptr_chann_desc->dbell_cbk = ptr_fn_drbell_cbk;
	spin_unlock_irqrestore(&ptr_chann_desc->channel_lock, flags);
}
EXPORT_SYMBOL(xlnx_register_doorbell_cbk);

/*
 * Send scratchpad response data to HOST 
 */
void xlnx_give_scrtchpd_rsp_to_host(ps_pcie_dma_chann_desc_t *ptr_chann_desc,
		unsigned int *ptr_card_2_host_data,
		unsigned int num_dwords_card_2_host
		)
{
	int i;
	unsigned int intr_assrt = 0;

	//spin_lock_bh(&ptr_chann_desc->channel_lock);

	/* Populate data into scratchpad */
	for(i = 0; i < num_dwords_card_2_host; i++) 
	{
		WR_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, (DMA_SCRATCH0_REG_OFFSET + (i*4)),*ptr_card_2_host_data);
		ptr_card_2_host_data++;
	}

	wmb();

	printk(KERN_ERR"\nRespond to HOST\n");

	/* Ring doorbell */
	intr_assrt |= DMA_SW_INTR_ASSRT_BIT;
	WR_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_PCIE_INTR_ASSRT_REG_OFFSET, intr_assrt);

}
EXPORT_SYMBOL(xlnx_give_scrtchpd_rsp_to_host);

/*
 * Send scratchpad command to EP & block till response arrives
 * Note this function cannot be called from non interrupt context
 */
int xlnx_do_scrtchpd_txn_from_host(ps_pcie_dma_chann_desc_t *ptr_chann_desc,
		unsigned int *ptr_host_2_card_data,
		unsigned int num_dwords_host_2_card,
		unsigned int *ptr_card_2_host_data,
		unsigned int num_dwords_card_2_host
		)
{
	int retval = XLNX_SUCCESS;
	int i;
	unsigned int intr_assrt = 0;

	/* Acquire mutex lock */
	if(down_trylock(&ptr_chann_desc->scratch_mutx))
	{
		retval = XLNX_SCRATCH_PAD_IO_IN_PROGRESS;
		printk(KERN_ERR"\n Scratch pad IO in progress for channel %d\n",ptr_chann_desc->chann_id);
		goto scratchpad_io_in_progress;
	}

	ptr_chann_desc->scrtch_pad_io_in_progress = true;

	/* Populate data into scratchpad */
	for(i = 0; i < num_dwords_host_2_card; i++) 
	{
		WR_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, (DMA_SCRATCH0_REG_OFFSET + (i*4)),*ptr_host_2_card_data);
		ptr_host_2_card_data++;
	}

	wmb();

	/* Ring doorbell */
	intr_assrt |= DMA_SW_INTR_ASSRT_BIT;
	WR_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, DMA_AXI_INTR_ASSRT_REG_OFFSET, intr_assrt);

	/* Wait for response from endpoint */
	down_timeout(&ptr_chann_desc->scratch_sem,jiffies+(HZ*2));
	printk(KERN_ERR"\n Response arrived from EP OR Timeout occured\n");

	rmb();

	/* Populate scratchpad data into buffer */
	for(i = 0; i < num_dwords_card_2_host; i++) 
	{
		*ptr_card_2_host_data = RD_DMA_REG(ptr_chann_desc->chan_dma_reg_vbaddr, (DMA_SCRATCH0_REG_OFFSET + (i*4)));
		printk(KERN_ERR"\n Scratchpad data received %x \n",*ptr_card_2_host_data);
		ptr_card_2_host_data++;
	}

	up(&ptr_chann_desc->scratch_mutx);

scratchpad_io_in_progress:
	return retval;
}
EXPORT_SYMBOL(xlnx_do_scrtchpd_txn_from_host);

/*
 * Interfaces exported End
 */
static int rp_pcie_dma_of_probe(struct platform_device *plt_dev)
{
	struct resource *res;
	g_host_dma_desc.irq_no = platform_get_irq_byname(plt_dev, "pcie_dma");
	if (g_host_dma_desc.irq_no < 0)
	{
		printk(KERN_ERR"Failed to parse Interrup number\n");
		return -EINVAL;
	}
	res = platform_get_resource_byname(plt_dev, IORESOURCE_MEM, "dma_reg");
	g_host_dma_desc.dma_reg_phy_base_addr = res->start;
	if (g_host_dma_desc.dma_reg_phy_base_addr == NULL)
	{
		printk(KERN_ERR"Device tree parsing failed dma reg property missing\n");
		return -EINVAL;
	}
	res = platform_get_resource_byname(plt_dev, IORESOURCE_MEM, "apm_reg");
	ps_ddr_apm_phy_addr = res->start;
	if (ps_ddr_apm_phy_addr == NULL)
	{
		printk(KERN_ERR"Device tree parsing failed apm reg property missing\n");
		return -EINVAL;
	}
	pci_register_driver(&nwl_dma_driver);	

	return 0;
}

static int rp_pcie_dma_of_remove(struct platform_device *plt_dev) 
{
	pci_unregister_driver(&nwl_dma_driver);
	return 0;
}

/* Match table for of_platform binding */
static struct of_device_id rp_pcie_dma_of_match[] = {
{ .compatible = "xlnx,pcie_dma-1.00.a", },
    {},  
};
MODULE_DEVICE_TABLE(of, rp_pcie_dma_of_match);  

static struct platform_driver pcie_dma_of_driver = {
	.probe = rp_pcie_dma_of_probe,
	.remove = rp_pcie_dma_of_remove,
	.driver = {
		.owner = THIS_MODULE,
	      	.name = "xilinx_pcie_dma",
	      	.of_match_table = rp_pcie_dma_of_match,
	       },   
};
module_platform_driver(pcie_dma_of_driver);											       

MODULE_DESCRIPTION("Xilinx PS PCIe DMA driver");
MODULE_AUTHOR("Xilinx");
MODULE_LICENSE("GPL");
