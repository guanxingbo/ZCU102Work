*************************************************************************
   ____  ____ 
  /   /\/   / 
 /___/  \  /   
 \   \   \/    � Copyright 2016 Xilinx, Inc. All rights reserved.
  \   \        This file contains confidential and proprietary 
  /   /        information of Xilinx, Inc. and is protected under U.S. 
 /___/   /\    and international copyright and other intellectual 
 \   \  /  \   property laws. 
  \___\/\___\ 
 
*************************************************************************

Vendor: Xilinx 
Current readme.txt Version: 1.0.0 
Date Last Modified:  19MAY2016
Date Created: 19MAY2016

Associated Filename: xapp1289.zip 
Associated Document: XAPP1289
Supported Device(s): ZYNQ UltraScale+ MPSoC device (xczu9eg-ffvb1156-1-e-es1) 
   
*************************************************************************

Disclaimer: 

      This disclaimer is not a license and does not grant any rights to 
      the materials distributed herewith. Except as otherwise provided in 
      a valid license issued to you by Xilinx, and to the maximum extent 
      permitted by applicable law: (1) THESE MATERIALS ARE MADE AVAILABLE 
      "AS IS" AND WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL 
      WARRANTIES AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, 
      INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
      NON-INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and 
      (2) Xilinx shall not be liable (whether in contract or tort, 
      including negligence, or under any other theory of liability) for 
      any loss or damage of any kind or nature related to, arising under 
      or in connection with these materials, including for any direct, or 
      any indirect, special, incidental, or consequential loss or damage 
      (including loss of data, profits, goodwill, or any type of loss or 
      damage suffered as a result of any action brought by a third party) 
      even if such damage or loss was reasonably foreseeable or Xilinx 
      had been advised of the possibility of the same.

Critical Applications:

      Xilinx products are not designed or intended to be fail-safe, or 
      for use in any application requiring fail-safe performance, such as 
      life-support or safety devices or systems, Class III medical 
      devices, nuclear facilities, applications related to the deployment 
      of airbags, or any other applications that could lead to death, 
      personal injury, or severe property or environmental damage 
      (individually and collectively, "Critical Applications"). Customer 
      assumes the sole risk and liability of any use of Xilinx products 
      in Critical Applications, subject only to applicable laws and 
      regulations governing limitations on product liability.

THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS PART OF THIS 
FILE AT ALL TIMES.

*************************************************************************

This readme file contains these sections:

1. REVISION HISTORY
2. OVERVIEW
3. SOFTWARE TOOLS AND SYSTEM REQUIREMENTS
4. DESIGN FILE HIERARCHY
5. INSTALLATION AND OPERATING INSTRUCTIONS
6. OTHER INFORMATION (OPTIONAL)
7. SUPPORT


1. REVISION HISTORY 

            Readme  
Date        Version      Revision Description
=========================================================================
19MAY2016   1.0          Initial Xilinx release.
=========================================================================

2. OVERVIEW
 The Zynq UltraScale+ Controller for PCI Express has a built-in DMA engine
 that can be used in Endpoint as well as Root Port mode.
 This application note provides an example that demonstrates how to configure
 and use the DMA in the Controller for PCI Express when configured as a Root
 Port. 

  Designs related architectural details and performance observations are
  available in XAPP1289.pdf and rebuild and test instructions are available on
  the wiki: http://www.wiki.xilinx.com/XAPP1289+PCIe+Root+DMA

3. SOFTWARE TOOLS AND SYSTEM REQUIREMENTS

Hardware requirements

* ZCU102 Evaluation kit with the Zynq UltraScale+ xczu9eg-ffvb1156-1-e-es1 FPGA   
* Power Supply: 100 VAC 240V VAC input, 12 VDC 5.0A output
* An USB Type-A to USB Micro-B cable (for UART communication) and a Tera Term Pro (or similar) UART terminal program.
* USB-UART drivers from Silicon Labs
* A SD-MMC flash card containing XAPP1289 binaries formatted with FAT32. 

Software requirements
* Xilinx Vivado 2016.1
* Xilinx SDK 2016.1
* PetaLinux v2016.1 


4. DESIGN FILE HIERARCHY

The directory structure underneath the top-level folder is described 
below:

    xapp1289: Reference Design folder
    |
    +-- ready_to_test : Prebuilt binaries
    |   +-- zcu102_sd 
    |       +-- boot.bin 
    |       +-- image.ub
    |       +-- root_dma (folder containing kernel modules and application) 
    |   
    |   +-- ep_bit (kcu105_axi_pcie_ep.bit to be used as Endpoint)   
    |   
    +-- software : Patch file, source code for drivers required
    |   +-- patch
    |   +-- hw_export 
    |   +-- root_dma (source files for driver and application) 
    |   +-- util (provides bif file as reference to build boot.bin)
    |   
    +--README.txt : the file you are currently reading  


5. INSTALLATION AND OPERATING INSTRUCTIONS 

  Please refer http://www.wiki.xilinx.com/XAPP1289+PCIe+Root+DMA for detailed
  instructions on rebuilding and testing.

6. OTHER INFORMATION (OPTIONAL) 

1) Warnings
   NONE

2) Design Notes
   The ZCU102 board support template should be obtained from Zynq UltraScale+
   MPSoC lounge in order to re-customize the PCW configuration in Vivado.

3) Fixes
   NONE

4) Known Issues


7. SUPPORT

To obtain technical support for this reference design, go to 
www.xilinx.com/support to locate answers to known issues in the Xilinx
Answers Database.  
