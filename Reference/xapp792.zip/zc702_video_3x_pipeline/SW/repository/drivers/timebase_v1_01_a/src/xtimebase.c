/* $Id: */
/******************************************************************************
* (c) Copyright 2009 Xilinx, Inc. All rights reserved.
*
* This file contains confidential and proprietary information
* of Xilinx, Inc. and is protected under U.S. and
* international copyright and other intellectual property
* laws.
*
* DISCLAIMER
* This disclaimer is not a license and does not grant any
* rights to the materials distributed herewith. Except as
* otherwise provided in a valid license issued to you by
* Xilinx, and to the maximum extent permitted by applicable
* law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
* WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
* AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
* BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
* INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
* (2) Xilinx shall not be liable (whether in contract or tort,
* including negligence, or under any other theory of
* liability) for any loss or damage of any kind or nature
* related to, arising under or in connection with these
* materials, including for any direct, or any indirect,
* special, incidental, or consequential loss or damage
* (including loss of data, profits, goodwill, or any type of
* loss or damage suffered as a result of any action brought
* by a third party) even if such damage or loss was
* reasonably foreseeable or Xilinx had been advised of the
* possibility of the same.
*
* CRITICAL APPLICATIONS
* Xilinx products are not designed or intended to be fail-
* safe, or for use in any application requiring fail-safe
* performance, such as life-support or safety devices or
* systems, Class III medical devices, nuclear facilities,
* applications related to the deployment of airbags, or any
* other applications that could lead to death, personal
* injury, or severe property or environmental damage
* (individually and collectively, "Critical
* Applications"). Customer assumes the sole risk and
* liability of any use of Xilinx products in Critical
* Applications, subject only to applicable laws and
* regulations governing limitations on product liability.
*
* THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
* PART OF THIS FILE AT ALL TIMES.
*
* All rights reserved.
*
******************************************************************************/
/*****************************************************************************/
/**
*
* @file xtimebase.c
*
* This is main code of Xilinx MVI Video TimeBase device driver. The TimeBase
* device detects and generates video sync signals to Video IP cores like
* MVI Scaler. Please see xtimebase.h for more details of the driver.
*
* <pre>
* MODIFICATION HISTORY:
*
* Ver	Who	Date		Changes
* -----	----	--------	-----------------------------------------------
* 1.00a	xd	08/05/08	First release
* 1.01a	xd	07/23/10	Added GIER; Added more h/w generic info into
*				xparameters.h; Feed callbacks with pending
*				interrupt info. Added Doxygen & Version support
* </pre>
*
******************************************************************************/

/***************************** Include Files *********************************/

#include "xtimebase.h"
#include "xil_assert.h"
#include "xil_types.h"
#include "string.h"

/************************** Constant Definitions *****************************/


/**************************** Type Definitions *******************************/


/***************** Macros (Inline Functions) Definitions *********************/


/************************** Function Prototypes ******************************/

static void StubCallBack(void *CallBackRef);
static void StubErrCallBack(void *CallBackRef, u32 ErrorMask);

/************************** Function Definition ******************************/

/*****************************************************************************/
/**
 * This function initializes a TimeBase device.	 This function must be called
 * prior to using a TimeBase device. Initialization of a TimeBase includes
 * setting up the instance data, and ensuring the hardware is in a quiescent
 * state.
 *
 * @param  InstancePtr is a pointer to the TimeBase device instance to be
 *	   worked on.
 * @param  CfgPtr points to the configuration structure associated with the
 *	   TimeBase device.
 * @param  EffectiveAddr is the base address of the device. If address
 *	   translation is being used, then this parameter must
 *	   reflect the virtual base address. Otherwise, the physical address
 *	   should be used.
 * @return XST_SUCCESS
 *
 *****************************************************************************/
int XTimeBase_CfgInitialize(XTimeBase *InstancePtr, XTimeBase_Config *CfgPtr,
				u32 EffectiveAddr)
{
	/* Verify arguments */
	Xil_AssertNonvoid(InstancePtr != NULL);
	Xil_AssertNonvoid(CfgPtr != NULL);
	Xil_AssertNonvoid((u32 *)EffectiveAddr != NULL);
	/* Setup the instance */
	memset((void *)InstancePtr, 0, sizeof(XTimeBase));

	memcpy((void *)&(InstancePtr->Config), (const void *)CfgPtr,
			   sizeof(XTimeBase_Config));
	InstancePtr->Config.BaseAddress = EffectiveAddr;


	/* Set all handlers to stub values, let user configure this data later
	 */
	InstancePtr->FrameSyncCallBack = (XTimeBase_CallBack) StubCallBack;
	InstancePtr->LockCallBack = (XTimeBase_CallBack) StubCallBack;
	InstancePtr->DetectorCallBack = (XTimeBase_CallBack) StubCallBack;
	InstancePtr->GeneratorCallBack = (XTimeBase_CallBack) StubCallBack;
	InstancePtr->ErrCallBack = (XTimeBase_ErrorCallBack) StubErrCallBack;

	/* Reset the hardware and set the flag to indicate the driver is
	  ready */
	InstancePtr->IsReady = XIL_COMPONENT_IS_READY;
	//XTimeBase_Reset(InstancePtr);

	return XST_SUCCESS;
}

/*****************************************************************************/
/**
 * This function enables a TimeBase device.
 *
 * @param  InstancePtr is a pointer to the TimeBase device instance to be
 *	   worked on.
 * @param  Type indicates which module (Detector and/or Generator) to enable.
 *	   Valid values could be obtained by bit ORing of XTB_EN_DETECTOR and
 *	   XTB_EN_GENERATOR.
 * @return NONE.
 *
 *****************************************************************************/
void XTimeBase_Enable(XTimeBase *InstancePtr, u32 Type)
{
	u32 CtrlRegValue;

	/* Assert bad arguments and conditions */
	Xil_AssertVoid(InstancePtr != NULL);
	Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

	/* Read Control register value back */
	CtrlRegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress,
						XTB_CTL);

	/* Change the value according to the enabling type and write it back */
	if (Type & XTB_EN_DETECTOR)
		CtrlRegValue |= XTB_CTL_DE_MASK;

	if (Type & XTB_EN_GENERATOR)
		CtrlRegValue |= XTB_CTL_GE_MASK;

	XTimeBase_WriteReg(InstancePtr->Config.BaseAddress, XTB_CTL,
				CtrlRegValue);
}

/*****************************************************************************/
/**
 * This function disables a TimeBase device.
 *
 * @param  InstancePtr is a pointer to the TimeBase device instance to be
 *	   worked on.
 * @param  Type indicates which module (Detector and/or Generator) to disable.
 *	   Valid values could be obtained by bit ORing of XTB_EN_DETECTOR and
 *	   XTB_EN_GENERATOR
 * @return NONE.
 *
 *****************************************************************************/
void XTimeBase_Disable(XTimeBase *InstancePtr, u32 Type)
{
	u32 CtrlRegValue;

	/* Assert bad arguments and conditions */
	Xil_AssertVoid(InstancePtr != NULL);
	Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

	/* Read Control register value back */
	CtrlRegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress,
						XTB_CTL);

	/* Change the value according to the disabling type and write it back*/
	if (Type & XTB_EN_DETECTOR)
		CtrlRegValue &= ~XTB_CTL_DE_MASK;

	if (Type & XTB_EN_GENERATOR)
		CtrlRegValue &= ~XTB_CTL_GE_MASK;

	XTimeBase_WriteReg(InstancePtr->Config.BaseAddress, XTB_CTL,
				CtrlRegValue);
}

/*****************************************************************************/
/**
 * This function sets up the output polarity of a TimeBase device.
 *
 * @param  InstancePtr is a pointer to the TimeBase device instance to be
 *	   worked on.
 * @param  PolarityPtr points to a Polarity configuration structure w/ the
 *	   setting to use on the TimeBase device.
 * @return NONE.
 *
 *****************************************************************************/
void XTimeBase_SetPolarity(XTimeBase *InstancePtr,
				XTimeBase_Polarity *PolarityPtr)
{
	u32 CtrlRegValue;

	/* Assert bad arguments and conditions */
	Xil_AssertVoid(InstancePtr != NULL);
	Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);
	Xil_AssertVoid(PolarityPtr != NULL);

	/* Read Control register value back and clear all polarity bits first*/
	CtrlRegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress,
						XTB_CTL);
	CtrlRegValue &= ~XTB_CTL_ALLP_MASK;

	/* Change the register value according to the setting in the Polarity
	 * configuration structure
	 */
	if (PolarityPtr->ActiveChromaPol)
		CtrlRegValue |= XTB_CTL_ACP_MASK;

	if (PolarityPtr->ActiveVideoPol)
		CtrlRegValue |= XTB_CTL_AVP_MASK;

	if (PolarityPtr->FieldIdPol)
		CtrlRegValue |= XTB_CTL_FIP_MASK;

	if (PolarityPtr->VBlankPol)
		CtrlRegValue |= XTB_CTL_VBP_MASK;

	if (PolarityPtr->VSyncPol)
		CtrlRegValue |= XTB_CTL_VSP_MASK;

	if (PolarityPtr->HBlankPol)
		CtrlRegValue |= XTB_CTL_HBP_MASK;

	if (PolarityPtr->HSyncPol)
		CtrlRegValue |= XTB_CTL_HSP_MASK;

	XTimeBase_WriteReg(InstancePtr->Config.BaseAddress, XTB_CTL,
				CtrlRegValue);
}

/*****************************************************************************/
/**
 * This function gets the output polarity setting used by a TimeBase device.
 *
 * @param  InstancePtr is a pointer to the TimeBase device instance to be
 *	   worked on.
 * @param  PolarityPtr points to a Polarity configuration structure that will
 *	   be populated with the setting used on the TimeBase device after
 *	   this function returns.
 * @return NONE.
 *
 *****************************************************************************/
void XTimeBase_GetPolarity(XTimeBase *InstancePtr,
				XTimeBase_Polarity *PolarityPtr)
{
	u32 CtrlRegValue;

	/* Assert bad arguments and conditions */
	Xil_AssertVoid(InstancePtr != NULL);
	Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);
	Xil_AssertVoid(PolarityPtr != NULL);

	/* Clear the Polarity configuration structure */
	memset((void *)PolarityPtr, 0, sizeof(XTimeBase_Polarity));

	/* Read Control register value back */
	CtrlRegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress,
						XTB_CTL);

	/* Populate the Polarity configuration structure w/ the current setting
	 * used in the device
	 */
	if (CtrlRegValue & XTB_CTL_ACP_MASK)
		PolarityPtr->ActiveChromaPol = 1;

	if (CtrlRegValue & XTB_CTL_AVP_MASK)
		PolarityPtr->ActiveVideoPol = 1;

	if (CtrlRegValue & XTB_CTL_FIP_MASK)
		PolarityPtr->FieldIdPol = 1;

	if (CtrlRegValue & XTB_CTL_VBP_MASK)
		PolarityPtr->VBlankPol = 1;

	if (CtrlRegValue & XTB_CTL_VSP_MASK)
		PolarityPtr->VSyncPol = 1;

	if (CtrlRegValue & XTB_CTL_HBP_MASK)
		PolarityPtr->HBlankPol = 1;

	if (CtrlRegValue & XTB_CTL_HSP_MASK)
		PolarityPtr->HSyncPol = 1;
}

/*****************************************************************************/
/**
 * This function sets up the source selecting of a TimeBase device.
 *
 * @param  InstancePtr is a pointer to the TimeBase device instance to be
 *	   worked on.
 * @param  SourcePtr points to a Source Selecting configuration structure w/
 *	   the setting to use on the TimeBase device.
 * @return NONE.
 *
 *****************************************************************************/
void XTimeBase_SetSource(XTimeBase *InstancePtr,
				XTimeBase_SourceSelect *SourcePtr)
{
	u32 CtrlRegValue;

	/* Assert bad arguments and conditions */
	Xil_AssertVoid(InstancePtr != NULL);
	Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);
	Xil_AssertVoid(SourcePtr != NULL);

	/* Read Control register value back and clear all source selection bits
	 * first
	 */
	CtrlRegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress,
						XTB_CTL);
	CtrlRegValue &= ~XTB_CTL_ALLSS_MASK;

	/* Change the register value according to the setting in the source
	 * selection configuration structure
	 */
	if (SourcePtr->VChromaSrc)
		CtrlRegValue |= XTB_CTL_VCSS_MASK;

	if (SourcePtr->VActiveSrc)
		CtrlRegValue |= XTB_CTL_VASS_MASK;

	if (SourcePtr->VBackPorchSrc)
		CtrlRegValue |= XTB_CTL_VBSS_MASK;

	if (SourcePtr->VSyncSrc)
		CtrlRegValue |= XTB_CTL_VSSS_MASK;

	if (SourcePtr->VFrontPorchSrc)
		CtrlRegValue |= XTB_CTL_VFSS_MASK;

	if (SourcePtr->VTotalSrc)
		CtrlRegValue |= XTB_CTL_VTSS_MASK;

	if (SourcePtr->HActiveSrc)
		CtrlRegValue |= XTB_CTL_HASS_MASK;

	if (SourcePtr->HBackPorchSrc)
		CtrlRegValue |= XTB_CTL_HBSS_MASK;

	if (SourcePtr->HSyncSrc)
		CtrlRegValue |= XTB_CTL_HSSS_MASK;

	if (SourcePtr->HFrontPorchSrc)
		CtrlRegValue |= XTB_CTL_HFSS_MASK;

	if (SourcePtr->HTotalSrc)
		CtrlRegValue |= XTB_CTL_HTSS_MASK;

	XTimeBase_WriteReg(InstancePtr->Config.BaseAddress, XTB_CTL,
				CtrlRegValue);
}

/*****************************************************************************/
/**
 * This function gets the source select setting used by a TimeBase device.
 *
 * @param  InstancePtr is a pointer to the TimeBase device instance to be
 *	   worked on.
 * @param  SourcePtr points to a source select configuration structure that
 *	   will be populated with the setting used on the TimeBase device after
 *	   this function returns.
 * @return NONE.
 *
 *****************************************************************************/
void XTimeBase_GetSource(XTimeBase *InstancePtr,
				XTimeBase_SourceSelect *SourcePtr)
{
	u32 CtrlRegValue;

	/* Assert bad arguments and conditions */
	Xil_AssertVoid(InstancePtr != NULL);
	Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);
	Xil_AssertVoid(SourcePtr != NULL);

	/* Clear the source selection configuration structure */
	memset((void *)SourcePtr, 0, sizeof(XTimeBase_SourceSelect));

	/* Read Control register value back */
	CtrlRegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress,
						XTB_CTL);

	/* Populate the source select configuration structure with the current
	 * setting used in the device
	 */
	if (CtrlRegValue & XTB_CTL_VCSS_MASK)
		SourcePtr->VChromaSrc = 1;
	if (CtrlRegValue & XTB_CTL_VASS_MASK)
		SourcePtr->VActiveSrc = 1;
	if (CtrlRegValue & XTB_CTL_VBSS_MASK)
		SourcePtr->VBackPorchSrc = 1;
	if (CtrlRegValue & XTB_CTL_VSSS_MASK)
		SourcePtr->VSyncSrc = 1;
	if (CtrlRegValue & XTB_CTL_VFSS_MASK)
		SourcePtr->VFrontPorchSrc = 1;
	if (CtrlRegValue & XTB_CTL_VTSS_MASK)
		SourcePtr->VTotalSrc = 1;
	if (CtrlRegValue & XTB_CTL_HASS_MASK)
		SourcePtr->HActiveSrc = 1;
	if (CtrlRegValue & XTB_CTL_HBSS_MASK)
		SourcePtr->HBackPorchSrc = 1;
	if (CtrlRegValue & XTB_CTL_HSSS_MASK)
		SourcePtr->HSyncSrc = 1;
	if (CtrlRegValue & XTB_CTL_HFSS_MASK)
		SourcePtr->HFrontPorchSrc = 1;
	if (CtrlRegValue & XTB_CTL_HTSS_MASK)
		SourcePtr->HTotalSrc = 1;
}

/*****************************************************************************/
/**
 * This function sets up the skip setting of the Generator in a TimeBase
 * device.
 *
 * @param  InstancePtr is a pointer to the TimeBase device instance to be
 *	   worked on.
 * @param  GeneratorChromaSkip indicates whether to skip 1 line between
 *	   active chroma for the Generator module. Use Non-0 value for this
 *	   parameter to skip 1 line, and 0 to not skip lines
 * @return NONE.
 *
 *****************************************************************************/
void XTimeBase_SetSkip(XTimeBase *InstancePtr, int GeneratorChromaSkip)
{
	u32 CtrlRegValue;

	/* Assert bad arguments and conditions */
	Xil_AssertVoid(InstancePtr != NULL);
	Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

	/* Read Control register value back and clear all skip bits first */
	CtrlRegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress,
						XTB_CTL);
	CtrlRegValue &= ~XTB_CTL_GACS_MASK;

	/* Change the register value according to the skip setting passed
	 * into this function.
	 */
	if (GeneratorChromaSkip)
		CtrlRegValue |= XTB_CTL_GACS_MASK;

	XTimeBase_WriteReg(InstancePtr->Config.BaseAddress, XTB_CTL,
				CtrlRegValue);
}

/*****************************************************************************/
/**
 * This function gets the skip setting used by the Generator in a TimeBase
 * device.
 *
 * @param  InstancePtr is a pointer to the TimeBase device instance to be
 *	   worked on.
 * @param  GeneratorChromaSkipPtr will point to the value indicating whether
 *	   1 line is skipped between active chroma for the Generator module
 *	   after this function returns. value 1 means that 1 line is skipped,
 *	   and 0 means that no lines are skipped
 * @return NONE.
 *
 *****************************************************************************/
void XTimeBase_GetSkip(XTimeBase *InstancePtr, int *GeneratorChromaSkipPtr)
{
	u32 CtrlRegValue;

	/* Assert bad arguments and conditions */
	Xil_AssertVoid(InstancePtr != NULL);
	Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);
	Xil_AssertVoid(GeneratorChromaSkipPtr != NULL);

	/* Read Control register value back */
	CtrlRegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress,
						XTB_CTL);

	/* Populate the skip variable values according to the skip setting
	 * used by the device.
	 */
	if (CtrlRegValue & XTB_CTL_GACS_MASK)
		*GeneratorChromaSkipPtr = 1;
	else
		*GeneratorChromaSkipPtr = 0;
}

/*****************************************************************************/
/**
 * This function sets up the Generator delay setting of a TimeBase device.
 *
 * @param  InstancePtr is a pointer to the TimeBase device instance to be
 *	   worked on.
 * @param  VertDelay indicates the number of total lines per frame to delay
 *	   the generator output. The valid range is from 0 to 4095.
 * @param  HoriDelay indicates the number of total clock cycles per line to
 *	   delay the generator output. The valid range is from 0 to 4095.
 * @return NONE.
 *
 *****************************************************************************/
void XTimeBase_SetDelay(XTimeBase *InstancePtr, int VertDelay, int HoriDelay)
{
	u32 RegValue;

	/* Assert bad arguments and conditions */
	Xil_AssertVoid(InstancePtr != NULL);
	Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);
	Xil_AssertVoid(VertDelay >= 0);
	Xil_AssertVoid(HoriDelay >= 0);
	Xil_AssertVoid(VertDelay <= 4095);
	Xil_AssertVoid(HoriDelay <= 4095);

	/* Calculate the delay value */
	RegValue = HoriDelay & XTB_GGD_HDELAY_MASK;
	RegValue |= (VertDelay << XTB_GGD_VDELAY_SHIFT) & XTB_GGD_VDELAY_MASK;

	/* Update the Generator Global Delay register w/ the value */
	XTimeBase_WriteReg(InstancePtr->Config.BaseAddress, XTB_GGD, RegValue);
}

/*****************************************************************************/
/**
 * This function gets the Generator delay setting used by a TimeBase device.
 *
 * @param  InstancePtr is a pointer to the TimeBase device instance to be
 *	   worked on.
 * @param  VertDelayPtr will point to a value indicating the number of total
 *	   lines per frame to delay the generator output after this function
 *	   returns.
 * @param  HoriDelayPtr will point to a value indicating the number of total
 *	   clock cycles per line to delay the generator output after this
 *	   function returns.
 * @return NONE.
 *
 *****************************************************************************/
void XTimeBase_GetDelay(XTimeBase *InstancePtr, int *VertDelayPtr,
			int *HoriDelayPtr)
{
	u32 RegValue;

	/* Assert bad arguments and conditions */
	Xil_AssertVoid(InstancePtr != NULL);
	Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);
	Xil_AssertVoid(VertDelayPtr != NULL);
	Xil_AssertVoid(HoriDelayPtr != NULL);

	/* Read the Generator Global Delay register value */
	RegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress, XTB_GGD);

	/* Calculate the delay values */
	*HoriDelayPtr = RegValue & XTB_GGD_HDELAY_MASK;
	*VertDelayPtr = (RegValue & XTB_GGD_VDELAY_MASK) >>
				XTB_GGD_VDELAY_SHIFT;
}

/*****************************************************************************/
/**
 * This function sets up the SYNC setting of a Frame Sync used by TimeBase
 * device.
 *
 * @param  InstancePtr is a pointer to the TimeBase device instance to be
 *	   worked on.
 * @param  FrameSyncIndex indicates the index number of the frame sync.	 The
 *	   valid range is from 0 to 15.
 * @param  VertStart indicates the vertical line count during which the Frame
 *	   Sync is active. The valid range is from 0 to 4095.
 * @param  HoriStart indicates the horizontal cycle count during which the
 *	   Frame Sync is active. The valid range is from 0 to 4095.
 * @return NONE.
 *
 *****************************************************************************/
void XTimeBase_SetSync(XTimeBase *InstancePtr, u16 FrameSyncIndex,
					   u16 VertStart, u16 HoriStart)
{
	u32 RegValue;
	u32 RegAddress;

	/* Assert bad arguments and conditions */
	Xil_AssertVoid(InstancePtr != NULL);
	Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);
	Xil_AssertVoid(FrameSyncIndex <= 15);
	Xil_AssertVoid(VertStart <= 4095);
	Xil_AssertVoid(HoriStart <= 4095);

	/* Calculate the sync value */
	RegValue = HoriStart & XTB_FSXX_HSTART_MASK;
	RegValue |= (VertStart << XTB_FSXX_VSTART_SHIFT) &
			XTB_FSXX_VSTART_MASK;

	/* Calculate the frame sync register address to write to */
	RegAddress = XTB_FS00 + FrameSyncIndex * XTB_REG_ADDRGAP;

	/* Update the Generator Global Delay register w/ the value */
	XTimeBase_WriteReg(InstancePtr->Config.BaseAddress, RegAddress,
				RegValue);

}

/*****************************************************************************/
/**
 * This function gets the SYNC setting of a Frame Sync used by TimeBase
 * device.
 *
 * @param  InstancePtr is a pointer to the TimeBase device instance to be
 *	   worked on.
 * @param  FrameSyncIndex indicates the index number of the frame sync. The
 *	   valid range is from 0 to 15.
 * @param  VertStartPtr will point to the value that indicates the vertical
 *	   line count during which the Frame Sync is active once this function
 *	   returns.
 * @param  HoriStartPtr will point to the value that indicates the horizontal
 *	   cycle count during which the Frame Sync is active once this function
 *	   returns.
 * @return NONE.
 *
 *****************************************************************************/
void XTimeBase_GetSync(XTimeBase *InstancePtr, u16 FrameSyncIndex,
				u16 *VertStartPtr, u16 *HoriStartPtr)
{
	u32 RegValue;
	u32 RegAddress;

	/* Assert bad arguments and conditions */
	Xil_AssertVoid(InstancePtr != NULL);
	Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);
	Xil_AssertVoid(FrameSyncIndex <= 15);
	Xil_AssertVoid(VertStartPtr != NULL);
	Xil_AssertVoid(VertStartPtr != NULL);

	/* Calculate the frame sync register address to read from */
	RegAddress = XTB_FS00 + FrameSyncIndex * XTB_REG_ADDRGAP;

	/* Read the frame sync register value */
	RegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress,
					RegAddress);

	/* Calculate the frame sync values */
	*HoriStartPtr = RegValue & XTB_FSXX_HSTART_MASK;
	*VertStartPtr = (RegValue & XTB_FSXX_VSTART_MASK) >>
				XTB_FSXX_VSTART_SHIFT;
}

/*****************************************************************************/
/**
 * This function sets up TimeBase signal to be used by the Generator module
 * in a TimeBase device.
 *
 * @param  InstancePtr is a pointer to the TimeBase device instance to be
 *	   worked on.
 * @param  SignalCfgPtr is a pointer to the TimeBase signal configuration
 *	   to be used by the Generator module in the TimeBase device.
 * @return NONE.
 *
 *****************************************************************************/
void XTimeBase_SetGenerator(XTimeBase *InstancePtr,
			   XTimeBase_TimeBaseSignal *SignalCfgPtr)
{
	u32 RegValue;
	XTimeBase_TimeBaseSignal *SCPtr;

	/* Assert bad arguments and conditions */
	Xil_AssertVoid(InstancePtr != NULL);
	Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);
	Xil_AssertVoid(SignalCfgPtr != NULL);

	SCPtr = SignalCfgPtr;

	/* Update the Generator Horizontal 0 Register */
	RegValue = SCPtr->HTotal & XTB_GH0_TOTAL_MASK;
	RegValue |= (SCPtr->HFrontPorchStart << XTB_GH0_FPSTART_SHIFT) &
					XTB_GH0_FPSTART_MASK;
	XTimeBase_WriteReg(InstancePtr->Config.BaseAddress, XTB_GH0, RegValue);

	/* Update the Generator Horizontal 1 Register */
	RegValue = SCPtr->HSyncStart & XTB_GH1_SYNCSTART_MASK;
	RegValue |= (SCPtr->HBackPorchStart << XTB_GH1_BPSTART_SHIFT) &
					XTB_GH1_BPSTART_MASK;
	XTimeBase_WriteReg(InstancePtr->Config.BaseAddress, XTB_GH1, RegValue);

	/* Update the Generator Horizontal 2 Register */
	RegValue = SCPtr->HActiveStart & XTB_GH2_ACTIVESTART_MASK;
	XTimeBase_WriteReg(InstancePtr->Config.BaseAddress, XTB_GH2, RegValue);

	/* Update the Generator Vertical 0 Register (field 0) */
	RegValue = SCPtr->V0Total & XTB_GV0_TOTAL_MASK;
	RegValue |= (SCPtr->V0FrontPorchStart << XTB_GV0_FPSTART_SHIFT) &
					XTB_GV0_FPSTART_MASK;
	XTimeBase_WriteReg(InstancePtr->Config.BaseAddress, XTB_GV0, RegValue);

	/* Update the Generator Vertical 1 Register (field 0) */
	RegValue = SCPtr->V0SyncStart & XTB_GV1_SYNCSTART_MASK;
	RegValue |= (SCPtr->V0BackPorchStart << XTB_GV1_BPSTART_SHIFT) &
					XTB_GV1_BPSTART_MASK;
	XTimeBase_WriteReg(InstancePtr->Config.BaseAddress, XTB_GV1, RegValue);

	/* Update the Generator Vertical 2 Register (field 0) */
	RegValue = SCPtr->V0ActiveStart & XTB_GV2_ACTIVESTART_MASK;
	RegValue |= (SCPtr->V0ChromaStart << XTB_GV2_CHROMASTART_SHIFT) &
					XTB_GV2_CHROMASTART_MASK;
	XTimeBase_WriteReg(InstancePtr->Config.BaseAddress, XTB_GV2, RegValue);

	/* Update the Generator Vertical 3 Register (field 1) */
	RegValue = SCPtr->V1Total & XTB_GV3_TOTAL_MASK;
	RegValue |= (SCPtr->V1FrontPorchStart << XTB_GV3_FPSTART_SHIFT) &
					XTB_GV3_FPSTART_MASK;
	XTimeBase_WriteReg(InstancePtr->Config.BaseAddress, XTB_GV3, RegValue);

	/* Update the Generator Vertical 4 Register (field 1) */
	RegValue = SCPtr->V1SyncStart & XTB_GV4_SYNCSTART_MASK;
	RegValue |= (SCPtr->V1BackPorchStart << XTB_GV4_BPSTART_SHIFT) &
					XTB_GV4_BPSTART_MASK;
	XTimeBase_WriteReg(InstancePtr->Config.BaseAddress, XTB_GV4, RegValue);

	/* Update the Generator Vertical 5 Register (field 1) */
	RegValue = SCPtr->V1ActiveStart & XTB_GV5_ACTIVESTART_MASK;
	RegValue |= (SCPtr->V1ChromaStart << XTB_GV5_CHROMASTART_SHIFT) &
					XTB_GV5_CHROMASTART_MASK;
	XTimeBase_WriteReg(InstancePtr->Config.BaseAddress, XTB_GV5, RegValue);

}

/*****************************************************************************/
/**
 * This function gets the TimeBase signal setting used by the Generator module
 * in a TimeBase device.
 *
 * @param  InstancePtr is a pointer to the TimeBase device instance to be
 *	   worked on.
 * @param  SignalCfgPtr is a pointer to a TimeBase signal configuration
 *	   which will be populated with the setting used by the Generator
 *	   module in the TimeBase device once this function returns.
 * @return NONE.
 *
 *****************************************************************************/
void XTimeBase_GetGenerator(XTimeBase *InstancePtr,
				XTimeBase_TimeBaseSignal *SignalCfgPtr)
{
	u32 RegValue;
	XTimeBase_TimeBaseSignal *SCPtr;

	/* Assert bad arguments and conditions */
	Xil_AssertVoid(InstancePtr != NULL);
	Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);
	Xil_AssertVoid(SignalCfgPtr != NULL);

	SCPtr = SignalCfgPtr;

	/* Get signal values from the Generator Horizontal 0 Register */
	RegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress, XTB_GH0);
	SCPtr->HTotal = RegValue & XTB_GH0_TOTAL_MASK;
	SCPtr->HFrontPorchStart = (RegValue & XTB_GH0_FPSTART_MASK) >>
					  XTB_GH0_FPSTART_SHIFT;

	/* Get signal values from the Generator Horizontal 1 Register */
	RegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress, XTB_GH1);
	SCPtr->HSyncStart = RegValue & XTB_GH1_SYNCSTART_MASK;
	SCPtr->HBackPorchStart = (RegValue & XTB_GH1_BPSTART_MASK) >>
					 XTB_GH1_BPSTART_SHIFT;

	/* Get signal values from the Generator Horizontal 2 Register */
	RegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress, XTB_GH2);
	SCPtr->HActiveStart = RegValue & XTB_GH2_ACTIVESTART_MASK;

	/* Get signal values from the Generator Vertical 0 Register (field 0)*/
	RegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress, XTB_GV0);
	SCPtr->V0Total = RegValue & XTB_GV0_TOTAL_MASK;
	SCPtr->V0FrontPorchStart = (RegValue & XTB_GV0_FPSTART_MASK) >>
					XTB_GV0_FPSTART_SHIFT;

	/* Get signal values from the Generator Vertical 1 Register (field 0)*/
	RegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress, XTB_GV1);
	SCPtr->V0SyncStart = RegValue & XTB_GV1_SYNCSTART_MASK;
	SCPtr->V0BackPorchStart = (RegValue & XTB_GV1_BPSTART_MASK) >>
					XTB_GV1_BPSTART_SHIFT;

	/* Get signal values from the Generator Vertical 2 Register (field 0)*/
	RegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress, XTB_GV2);
	SCPtr->V0ActiveStart = RegValue & XTB_GV2_ACTIVESTART_MASK;
	SCPtr->V0ChromaStart = (RegValue & XTB_GV2_CHROMASTART_MASK) >>
					XTB_GV2_CHROMASTART_SHIFT;

	/* Get signal values from the Generator Vertical 3 Register (field 1)*/
	RegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress, XTB_GV3);
	SCPtr->V1Total = RegValue & XTB_GV3_TOTAL_MASK;
	SCPtr->V1FrontPorchStart = (RegValue & XTB_GV3_FPSTART_MASK) >>
					XTB_GV3_FPSTART_SHIFT;

	/* Get signal values from the Generator Vertical 4 Register (field 1)*/
	RegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress, XTB_GV4);
	SCPtr->V1SyncStart = RegValue & XTB_GV4_SYNCSTART_MASK;
	SCPtr->V1BackPorchStart = (RegValue & XTB_GV4_BPSTART_MASK) >>
					XTB_GV4_BPSTART_SHIFT;

	/* Get signal values from the Generator Vertical 5 Register (field 1)*/
	RegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress, XTB_GV5);
	SCPtr->V1ActiveStart = RegValue & XTB_GV5_ACTIVESTART_MASK;
	SCPtr->V1ChromaStart = (RegValue & XTB_GV5_CHROMASTART_MASK) >>
					XTB_GV5_CHROMASTART_SHIFT;

}

/*****************************************************************************/
/**
 * This function gets the TimeBase signal setting used by the Detector module
 * in a TimeBase device.
 *
 * @param  InstancePtr is a pointer to the TimeBase device instance to be
 *	   worked on.
 * @param  SignalCfgPtr is a pointer to a TimeBase signal configuration
 *	   which will be populated with the setting used by the Detector
 *	   module in the TimeBase device once this function returns.
 * @return NONE.
 *
 *****************************************************************************/
void XTimeBase_GetDetector(XTimeBase *InstancePtr,
				XTimeBase_TimeBaseSignal *SignalCfgPtr)
{
	u32 RegValue;
	XTimeBase_TimeBaseSignal *SCPtr;

	/* Assert bad arguments and conditions */
	Xil_AssertVoid(InstancePtr != NULL);
	Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);
	Xil_AssertVoid(SignalCfgPtr != NULL);

	SCPtr = SignalCfgPtr;

	/* Get signal values from the Detector Horizontal 0 Register */
	RegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress, XTB_DH0);
	SCPtr->HTotal = RegValue & XTB_DH0_TOTAL_MASK;
	SCPtr->HFrontPorchStart = (RegValue & XTB_DH0_FPSTART_MASK) >>
					  XTB_DH0_FPSTART_SHIFT;

	/* Get signal values from the Detector Horizontal 1 Register */
	RegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress, XTB_DH1);
	SCPtr->HSyncStart = RegValue & XTB_DH1_SYNCSTART_MASK;
	SCPtr->HBackPorchStart = (RegValue & XTB_DH1_BPSTART_MASK) >>
					 XTB_DH1_BPSTART_SHIFT;

	/* Get signal values from the Detector Horizontal 2 Register */
	RegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress, XTB_DH2);
	SCPtr->HActiveStart = RegValue & XTB_DH2_ACTIVESTART_MASK;

	/* Get signal values from the Detector Vertical 0 Register (field 0) */
	RegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress, XTB_DV0);
	SCPtr->V0Total = RegValue & XTB_DV0_TOTAL_MASK;
	SCPtr->V0FrontPorchStart = (RegValue & XTB_DV0_FPSTART_MASK) >>
					   XTB_DV0_FPSTART_SHIFT;

	/* Get signal values from the Detector Vertical 1 Register (field 0) */
	RegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress, XTB_DV1);
	SCPtr->V0SyncStart = RegValue & XTB_DV1_SYNCSTART_MASK;
	SCPtr->V0BackPorchStart = (RegValue & XTB_DV1_BPSTART_MASK) >>
					  XTB_DV1_BPSTART_SHIFT;

	/* Get signal values from the Detector Vertical 2 Register (field 0) */
	RegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress, XTB_DV2);
	SCPtr->V0ActiveStart = RegValue & XTB_DV2_ACTIVESTART_MASK;
	SCPtr->V0ChromaStart = (RegValue & XTB_DV2_CHROMASTART_MASK) >>
					   XTB_DV2_CHROMASTART_SHIFT;

	/* Get signal values from the Detector Vertical 3 Register (field 1) */
	RegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress, XTB_DV3);
	SCPtr->V1Total = RegValue & XTB_DV3_TOTAL_MASK;
	SCPtr->V1FrontPorchStart = (RegValue & XTB_DV3_FPSTART_MASK) >>
					   XTB_DV3_FPSTART_SHIFT;

	/* Get signal values from the Detector Vertical 4 Register (field 1) */
	RegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress, XTB_DV4);
	SCPtr->V1SyncStart = RegValue & XTB_DV4_SYNCSTART_MASK;
	SCPtr->V1BackPorchStart = (RegValue & XTB_DV4_BPSTART_MASK) >>
					  XTB_DV4_BPSTART_SHIFT;

	/* Get signal values from the Detector Vertical 5 Register (field 1) */
	RegValue = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress, XTB_DV5);
	SCPtr->V1ActiveStart = RegValue & XTB_DV5_ACTIVESTART_MASK;
	SCPtr->V1ChromaStart = (RegValue & XTB_DV5_CHROMASTART_MASK) >>
					   XTB_DV5_CHROMASTART_SHIFT;

}

/*****************************************************************************/
/**
*
* This function returns the version of a TimeBase device.
*
* @param  InstancePtr is a pointer to the TimeBase device instance to be
*	  worked on.
* @param  Major points to an unsigned 16-bit variable that will be assigned
*	  with the major version number after this function returns. Value
*	  range is from 0x0 to 0xF.
* @param  Minor points to an unsigned 16-bit variable that will be assigned
*	  with the minor version number after this function returns. Value
*	  range is from 0x00 to 0xFF.
* @param  Revision points to an unsigned 16-bit variable that will be assigned
*	  with the revision version number after this function returns. Value
*	  range is from 0xA to 0xF.
* @return None.
* @note	  Example: Device version should read v2.01.c if major version number
*	  is 0x2, minor version number is 0x1, and revision version number is
*	  0xC.
*
******************************************************************************/
void XTimeBase_GetVersion(XTimeBase *InstancePtr, u16 *Major, u16 *Minor,
				u16 *Revision)
{
	u32 Version;

	/* Verify arguments */
	Xil_AssertVoid(InstancePtr != NULL);
	Xil_AssertVoid(Major != NULL);
	Xil_AssertVoid(Minor != NULL);
	Xil_AssertVoid(Revision != NULL);

	/* Read device version */
	Version = XTimeBase_ReadReg(InstancePtr->Config.BaseAddress, XTB_VER);

	/* Parse the version and pass the info to the caller via output
	 * parameter
	 */
	*Major = (u16)
		((Version & XTB_VER_MAJOR_MASK) >> XTB_VER_MAJOR_SHIFT);

	*Minor = (u16)
		((Version & XTB_VER_MINOR_MASK) >> XTB_VER_MINOR_SHIFT);

	*Revision = (u16)
		((Version & XTB_VER_REV_MASK) >> XTB_VER_REV_SHIFT);

	return;
}

/*****************************************************************************/
/*
 * This routine is a stub for the asynchronous callbacks. The stub is here in
 * case the upper layer forgot to set the handlers. On initialization, All
 * handlers except error handler are set to this callback. It is considered an
 * error for this handler to be invoked.
 *
 *****************************************************************************/
static void StubCallBack(void *CallBackRef)
{
	Xil_AssertVoidAlways();
}

/*****************************************************************************/
/*
 * This routine is a stub for the asynchronous error interrupt callback. The
 * stub is here in case the upper layer forgot to set the error interrupt
 * handler. On initialization, Error interrupt handler is set to this
 * callback. It is considered an error for this handler to be invoked.
 *
 *****************************************************************************/
static void StubErrCallBack(void *CallBackRef, u32 ErrorMask)
{
	Xil_AssertVoidAlways();
}
