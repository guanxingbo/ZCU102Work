/* $Id: */
/******************************************************************************
* (c) Copyright 2009 Xilinx, Inc. All rights reserved.
*
* This file contains confidential and proprietary information
* of Xilinx, Inc. and is protected under U.S. and
* international copyright and other intellectual property
* laws.
*
* DISCLAIMER
* This disclaimer is not a license and does not grant any
* rights to the materials distributed herewith. Except as
* otherwise provided in a valid license issued to you by
* Xilinx, and to the maximum extent permitted by applicable
* law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
* WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
* AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
* BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
* INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
* (2) Xilinx shall not be liable (whether in contract or tort,
* including negligence, or under any other theory of
* liability) for any loss or damage of any kind or nature
* related to, arising under or in connection with these
* materials, including for any direct, or any indirect,
* special, incidental, or consequential loss or damage
* (including loss of data, profits, goodwill, or any type of
* loss or damage suffered as a result of any action brought
* by a third party) even if such damage or loss was
* reasonably foreseeable or Xilinx had been advised of the
* possibility of the same.
*
* CRITICAL APPLICATIONS
* Xilinx products are not designed or intended to be fail-
* safe, or for use in any application requiring fail-safe
* performance, such as life-support or safety devices or
* systems, Class III medical devices, nuclear facilities,
* applications related to the deployment of airbags, or any
* other applications that could lead to death, personal
* injury, or severe property or environmental damage
* (individually and collectively, "Critical
* Applications"). Customer assumes the sole risk and
* liability of any use of Xilinx products in Critical
* Applications, subject only to applicable laws and
* regulations governing limitations on product liability.
*
* THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
* PART OF THIS FILE AT ALL TIMES.
*
* All rights reserved.
*
******************************************************************************/
/*****************************************************************************/
/**
*
* @file xtimebase.h
*
* This is the main header file of Xilinx MVI TimeBase device driver. The
* TimeBase device detects timebase signals, independently overrides any one of
* them, re-generates timebase signals with +/- delay and with polarity
* inversion, and generates up to 16 one cycle Frame Sync outputs.
*
* The device has the following main features:
* - Detect timebase signals:
*	- horizontal sync
*	- horizontal blank
*	- vertical sync
*	- vertical blank
*	- active video
*	- field id
* - Independently override any one signal.
* - Re-generate timebase signals with +/- delay and with polarity inversion.
* - Generate up to 16 one cycle Frame Sync outputs.
*
* For a full description of TimeBase features, please see the hardware
* specification.
*
* <b>Interrupt Service </b>
*
* The interrupt types supported are:
* - Frame Sync Interrupts 0 - 15
* - Generator interrupt
*	- Generator Active Video Interrupt
*	- Generator VBLANK Interrupt
* - Detector interrupt:
*	- Detector Active Video Interrupt
*	- Detector VBLANK Interrupt
* - Signal Lock interrupt
*	- Active Chroma signal lock
*	- Active Video Signal Lock
*	- Field ID Signal Lock
*	- Vertical Blank Signal Lock
*	- Vertical Sync Signal Lock
*	- Horizontal Blank Signal Lock
*	- Horizontal Sync Signal Lock
*
* <b>Software Initialization </b>
*
* The application needs to do following steps in order for preparing the
* TimeBase to be ready to process timebase signal handling.
*
* - Call XTimeBase_LookupConfig() using a device ID to find the device
*   configuration.
* - Call XTimeBase_CfgInitialize() to initialize the device and the driver
*   instance associated with it.
* - Call XTimeBase_SetGenerator() to set up the timebase signals to generate,
*   if desired.
* - Call XTimeBase_SetPolarity() to set up the timebase signal polarity.
* - Call XTimeBase_SetSource() for source selection
* - Call XTimeBase_Enable() to enable/start the TimeBase device.
*
* <b> Examples </b>
*
* An example is provided with this driver to demonstrate the driver usage.
*
* <b>Cache Coherency</b>
*
* <b>Alignment</b>
*
* <b>Limitations</b>
*
* <b>BUS Interface</b>
*
* <pre>
* MODIFICATION HISTORY:
*
* Ver	Who	Date		Changes
* -----	----	--------	-----------------------------------------------
* 1.00a	xd	08/05/08	First release
* 1.01a	xd	07/23/10	Added GIER; Added more h/w generic info into
*				xparameters.h; Feed callbacks with pending
*				interrupt info. Added Doxygen & Version support
* </pre>
*
******************************************************************************/

#ifndef XTIMEBASE_H		  /* prevent circular inclusions */
#define XTIMEBASE_H		  /* by using protection macros */

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/

#include "xtimebase_hw.h"
#include "xstatus.h"

/************************** Constant Definitions *****************************/

/** @name Interrupt Types for setting up Callbacks
 *  @{
 */
#define XTB_HANDLER_FRAMESYNC	1 /**< A frame sync event interrupt type */
#define XTB_HANDLER_LOCK	2 /**< A signal lock event interrupt type */
#define XTB_HANDLER_DETECTOR	3 /**< A detector event interrupt type */
#define XTB_HANDLER_GENERATOR	4 /**< A generator event interrupt type */
#define XTB_HANDLER_ERROR	5 /**< An error condition interrupt type */
/*@}*/

/** @name Options for enabling TimeBase modules
 *  @{
 */
#define XTB_EN_GENERATOR	1	/**< To enable generator */
#define XTB_EN_DETECTOR		2	/**< To enable detector */
/*@}*/

/** @name Address gap between two register next to each other
 *  @{
 */
#define XTB_REG_ADDRGAP		4
/*@}*/

/**************************** Type Definitions *******************************/

/**
 * This typedef contains configuration information for a TimeBase device.
 * Each TimeBase device should have a configuration structure associated
 */
typedef struct {
	u16 DeviceId;	   /**< DeviceId is the unique ID  of the device */
	u32 BaseAddress;   /**< BaseAddress is the physical base address of the
			     *	device's registers */
} XTimeBase_Config;

/**
 * This typedef contains Polarity configuration information for a TimeBase
 * device.
 */
typedef struct {
	u8 ActiveChromaPol;	/**< Active Chroma Output Polarity */
	u8 ActiveVideoPol;	/**< Active Video Output Polarity */
	u8 FieldIdPol;		/**< Field ID Output Polarity */
	u8 VBlankPol;		/**< Vertical Blank Output Polarity */
	u8 VSyncPol;		/**< Vertical Sync Output Polarity */
	u8 HBlankPol;		/**< Horizontal Blank Output Polarity */
	u8 HSyncPol;		/**< Horizontal Sync Output Polarity */
} XTimeBase_Polarity;

/**
 * This typedef contains Source Selection configuration information for a
 * TimeBase device.
 */
typedef struct {

	u8 VChromaSrc;		/**< Start of Active Chroma Register Source
				  *  Select */

	u8 VActiveSrc;		/**< Vertical Active Video Start Register
				  *  Source Select */
	u8 VBackPorchSrc;	/**< Vertical Back Porch Start Register Source
				  *  Select */
	u8 VSyncSrc;		/**< Vertical Sync Start Register Source Select
				  */
	u8 VFrontPorchSrc;	/**< Vertical Front Porch Start Register Source
				  *  Select */
	u8 VTotalSrc;		/**< Vertical Total Register Source Select */

	u8 HActiveSrc;		/**< Horizontal Active Video Start Register
				  *  Source Select */
	u8 HBackPorchSrc;	/**< Horizontal Back Porch Start Register
				  *  Source Select */
	u8 HSyncSrc;		/**< Horizontal Sync Start Register Source
				  *  Select */
	u8 HFrontPorchSrc;	/**< Horizontal Front Porch Start Register
				  *  Source Select */
	u8 HTotalSrc;		/**< Horizontal Total Register Source Select */

} XTimeBase_SourceSelect;

/**
 * This typedef contains the TimeBase signal configuration used by the
 * Generator/Detector modules in a TimeBase device.
 */
typedef struct {

	u16 HFrontPorchStart;	/**< Horizontal Front Porch Start Cycle Count*/
	u16 HTotal;		/**< Horizontal total clock cycles per Line */
	u16 HBackPorchStart;	/**< Horizontal Back Porch Start Cycle Count */
	u16 HSyncStart;		/**< Horizontal Sync Start Cycle Count */
	u16 HActiveStart;	/**< Horizontal Active Video Start Cycle Count
				  */

	u16 V0FrontPorchStart;	/**< Vertical Front Porch Start Line Count
				  *  (Field 0) */
	u16 V0Total;		/**< Total lines per Frame (Field 0) */
	u16 V0BackPorchStart;	/**< Vertical Back Porch Start Line Count
				  *  (Field 0) */
	u16 V0SyncStart;	/**< Vertical Sync Start Line Count (Field 0)*/
	u16 V0ChromaStart;	/**< Active Chroma Start Line Count (Field 0)*/
	u16 V0ActiveStart;	/**< Vertical Active Video Start Line Count
				  *  (Field 0) */

	u16 V1FrontPorchStart;	/**< Vertical Front Porch Start Line Count
				  *  (Field 1) */
	u16 V1Total;		/**< Total lines per Frame (Field 1) */
	u16 V1BackPorchStart;	/**< Vertical Back Porch Start Line Count
				  *  (Field 1)  */
	u16 V1SyncStart;	/**< Vertical Sync Start Line Count (Field 1)*/
	u16 V1ChromaStart;	/**< Active Chroma Start Line Count (Field 1)*/
	u16 V1ActiveStart;	/**< Vertical Active Video Start Line Count
				  * (Field 1) */

} XTimeBase_TimeBaseSignal;


/**
 * Callback type for all interrupts except error interrupt.
 *
 * @param CallBackRef is a callback reference passed in by the upper layer
 *	  when setting the callback functions, and passed back to the
 *	  upper layer when the callback is invoked.
 * @param Mask is a bit mask indicating the cause of the event. For
 *	  current device version, this parameter is "OR" of 0 or more XTB_IXR_*
 *	  constants defined in xtimebase_hw.h
 */
typedef void (*XTimeBase_CallBack) (void *CallBackRef, u32 Mask);

/**
 * Callback type for Error interrupt.
 *
 * @param CallBackRef is a callback reference passed in by the upper layer
 *	  when setting the callback functions, and passed back to the
 *	  upper layer when the callback is invoked.
 * @param ErrorMask is a bit mask indicating the cause of the error. For
 *	  current device version, this parameter always have value 0 and
 *	  could be ignored.
 */
typedef void (*XTimeBase_ErrorCallBack) (void *CallBackRef, u32 ErrorMask);

/**
 * The XTimeBase driver instance data. An instance must be allocated for each
 * TimeBase device in use.
 */
typedef struct {
	XTimeBase_Config Config;	/**< hardware configuration */
	u32 IsReady;			/**< Device and the driver instance are
					  *  initialized */

	XTimeBase_CallBack FrameSyncCallBack; /**< Call back for Frame Sync
						*  interrupt */
	void *FrameSyncRef;		      /**< To be passed to the Frame
						*  Sync interrupt callback */

	XTimeBase_CallBack LockCallBack;      /**< Call back for Signal Lock
						*  interrupt */
	void *LockRef;			      /**< To be passed to the Signal
						*  Lock interrupt callback */

	XTimeBase_CallBack DetectorCallBack;  /**< Call back for Detector
						*  interrupt */
	void *DetectorRef;		      /**< To be passed to the Detector
						*  interrupt callback */

	XTimeBase_CallBack GeneratorCallBack; /**< Call back for Generator
						*  interrupt */
	void *GeneratorRef;		      /**< To be passed to the
						*  Generator interrupt
						*  callback */

	XTimeBase_ErrorCallBack ErrCallBack;  /**< Call back for Error
						*  interrupt */
	void *ErrRef;			      /**< To be passed to the Error
						*  interrupt callback */

} XTimeBase;

/***************** Macros (Inline Functions) Definitions *********************/

/*****************************************************************************/
/**
*
* This macro resets a TimeBase device.
*
* @param  InstancePtr is a pointer to the TimeBase device instance to be worked
*	  on.
*
* @return None
*
* @note
* C-style signature:
*	 void XTimeBase_Reset(XTimeBase *InstancePtr)
*
******************************************************************************/
#define XTimeBase_Reset(InstancePtr) \
{ \
	XTimeBase_WriteReg((InstancePtr)->Config.BaseAddress, XTB_RESET, \
			   XTB_RESET_RESET_MASK); \
	XTimeBase_WriteReg((InstancePtr)->Config.BaseAddress, XTB_RESET, \
			   0); \
}

/*****************************************************************************/
/**
* This function gets the status of the Detector in a TimeBase device.
*
* @param  InstancePtr is a pointer to the TimeBase device instance to be
*	  worked on.
*
* @return The Detector Status. Use XTB_DS_* in xtimebase_hw.h to interpret
*	  the returned value.
*
* @note
* C-style signature:
*	  u32 XTimeBase_GetDetectionStatus(XTimeBase *InstancePtr)
*
******************************************************************************/
#define XTimeBase_GetDetectionStatus(InstancePtr) \
	XTimeBase_ReadReg((InstancePtr)->Config.BaseAddress, XTB_DS)

/*****************************************************************************/
/**
*
* This macro enables the global interrupt on a TimeBase device.
*
* @param InstancePtr is a pointer to the TimeBase device instance to be
*	 worked on.
*
* @return None.
*
* @note
* C-style signature:
*	  void XTimeBase_IntrEnableGlobal(XTimeBase *InstancePtr);
*
******************************************************************************/
#define XTimeBase_IntrEnableGlobal(InstancePtr) \
	XTimeBase_WriteReg((InstancePtr)->Config.BaseAddress, XTB_GIER,\
		XTB_GIER_GIE_MASK)

/*****************************************************************************/
/**
*
* This macro disables the global interrupt on a TimeBase device.
*
* @param InstancePtr is a pointer to the TimeBase device instance to be
*	 worked on.
*
* @return None.
*
* @note
* C-style signature:
*	  void XTimeBase_IntrDisableGlobal(XTimeBase *InstancePtr);
*
******************************************************************************/
#define XTimeBase_IntrDisableGlobal(InstancePtr) \
	XTimeBase_WriteReg((InstancePtr)->Config.BaseAddress, XTB_GIER, 0)

/*****************************************************************************/
/**
*
* This macro enables individual interrupts of a TimeBase device.
*
* @param  InstancePtr is a pointer to the TimeBase device instance to be worked
*	  on.
*
* @param  IntrType is the type of the interrupts to enable. Use OR'ing of
*	  XTB_IXR_* constants defined in xtimebase_hw.h to create this
*	  parameter value.
*
* @return None
*
* @note
*
* The existing enabled interrupt(s) will remain enabled.
*
* C-style signature:
*	 void XTimeBase_IntrEnable(XTimeBase *InstancePtr, u32 IntrType)
*
******************************************************************************/
#define XTimeBase_IntrEnable(InstancePtr, IntrType) \
	XTimeBase_WriteReg((InstancePtr)->Config.BaseAddress, XTB_IER, \
		((IntrType) & XTB_IXR_ALLINTR_MASK) | \
		 XTimeBase_ReadReg((InstancePtr)->Config.BaseAddress, XTB_IER))

/*****************************************************************************/
/**
*
* This macro disables individual interrupts of a TimeBase device.
*
* @param  InstancePtr is a pointer to the TimeBase device instance to be worked
*	  on.
*
* @param  IntrType is the type of the interrupts to disable. Use OR'ing of
*	  XTB_IXR_* constants defined in xtimebase_hw.h to create this
*	  parameter value.
*
* @return None
*
* @note
*
* Any other interrupt not covered by parameter IntrType, if enabled before
* this macro is called, will remain enabled.
*
* C-style signature:
*	 void XTimeBase_IntrDisable(XTimeBase *InstancePtr, u32 IntrType)
*
******************************************************************************/
#define XTimeBase_IntrDisable(InstancePtr, IntrType) \
	XTimeBase_WriteReg((InstancePtr)->Config.BaseAddress, XTB_IER, \
		XTimeBase_ReadReg((InstancePtr)->Config.BaseAddress, XTB_IER) \
		& ((~(IntrType)) & XTB_IXR_ALLINTR_MASK))

/*****************************************************************************/
/**
*
* This macro returns the pending interrupts of a TimeBase device.
*
* @param  InstancePtr is a pointer to the TimeBase device instance to be worked
*	  on.
*
* @return The pending interrupts of the TimeBase. Use XTB_IXR_* constants
*	  defined in xtimebase_hw.h to interpret this value.
*
* @note
*
* C-style signature:
*	 u32 XTimeBase_IntrGetPending(XTimeBase *InstancePtr)
*
******************************************************************************/
#define XTimeBase_IntrGetPending(InstancePtr) \
	(XTimeBase_ReadReg((InstancePtr)->Config.BaseAddress, XTB_IER) & \
	 XTimeBase_ReadReg((InstancePtr)->Config.BaseAddress, XTB_ISR) & \
	 XTB_IXR_ALLINTR_MASK)

/*****************************************************************************/
/**
*
* This macro clears/acknowledges pending interrupts of a TimeBase device.
*
* @param  InstancePtr is a pointer to the TimeBase device instance to be worked
*	  on.
*
* @param  IntrType is the pending interrupts to clear/acknowledge. Use OR'ing
*	  of XTB_IXR_* constants defined in xtimebase_hw.h to create this
*	  parameter value.
*
* @return None
*
* @note
*
* C-style signature:
*	 void XTimeBase_IntrClear(XTimeBase *InstancePtr, u32 IntrType)
*
******************************************************************************/
#define XTimeBase_IntrClear(InstancePtr, IntrType) \
	XTimeBase_WriteReg((InstancePtr)->Config.BaseAddress, XTB_ISR, \
		(IntrType) & XTB_IXR_ALLINTR_MASK)

/*****************************************************************************/
/**
*
* This macro sets the edge at which the following interrupts trigger:
*	- XTB_IXR_ACL_MASK
*	- XTB_IXR_AVL_MASK
*	- XTB_IXR_FIL_MASK
*	- XTB_IXR_VBL_MASK
*	- XTB_IXR_VSL_MASK
*	- XTB_IXR_HBL_MASK
*	- XTB_IXR_HSL_MASK
*
* @param  InstancePtr is a pointer to the TimeBase device instance to be worked
*	  on.
*
* @param  LockPolarity indicates the edge at which the interrupts above
*	  trigger. Use any non-0 for triggering on rising edge of lock. Use 0
*	  for triggering on falling edge of lock.
*
* @return None
*
* @note
*
* C-style signature:
*	 void XTimeBase_IntrSetLockPolarity(XTimeBase *InstancePtr,
*						u32 LockPolarity)
*
******************************************************************************/
#define XTimeBase_IntrSetLockPolarity(InstancePtr, LockPolarity) \
{ \
	if (LockPolarity) { \
		XTimeBase_WriteReg((InstancePtr)->Config.BaseAddress, \
			XTB_CTL, \
			XTimeBase_ReadReg((InstancePtr)->Config.BaseAddress, \
				XTB_CTL) | XTB_CTL_LP_MASK); \
	} \
	else { \
		XTimeBase_WriteReg((InstancePtr)->Config.BaseAddress, \
			XTB_CTL, \
			XTimeBase_ReadReg((InstancePtr)->Config.BaseAddress, \
				XTB_CTL) & (~XTB_CTL_LP_MASK)); \
	} \
}

/************************** Function Prototypes ******************************/

/*
 * Initialization and control functions in xtimebase.c
 */

/* Initialization */
int XTimeBase_CfgInitialize(XTimeBase *InstancePtr, XTimeBase_Config *CfgPtr,
				u32 EffectiveAddr);

/* Enabling and Disabling */
void XTimeBase_Enable(XTimeBase *InstancePtr, u32 Type);
void XTimeBase_Disable(XTimeBase *InstancePtr, u32 Type);

/* Polarity setting */
void XTimeBase_SetPolarity(XTimeBase *InstancePtr,
			   XTimeBase_Polarity *PolarityPtr);
void XTimeBase_GetPolarity(XTimeBase *InstancePtr,
			   XTimeBase_Polarity *PolarityPtr);

/* Source selection */
void XTimeBase_SetSource(XTimeBase *InstancePtr,
			 XTimeBase_SourceSelect *SourcePtr);
void XTimeBase_GetSource(XTimeBase *InstancePtr,
			 XTimeBase_SourceSelect *SourcePtr);

/* Skipping setting */
void XTimeBase_SetSkip(XTimeBase *InstancePtr, int GeneratorChromaSkip);
void XTimeBase_GetSkip(XTimeBase *InstancePtr, int *GeneratorChromaSkipPtr);

/* Timebase generator/detector setting/fetching */
void XTimeBase_SetGenerator(XTimeBase *InstancePtr,
			    XTimeBase_TimeBaseSignal *SignalCfgPtr);
void XTimeBase_GetGenerator(XTimeBase *InstancePtr,
			   XTimeBase_TimeBaseSignal *SignalCfgPtr);
void XTimeBase_GetDetector(XTimeBase *InstancePtr,
			   XTimeBase_TimeBaseSignal *SignalCfgPtr);

/* Delay setting */
void XTimeBase_SetDelay(XTimeBase *InstancePtr, int VertDelay, int HoriDelay);
void XTimeBase_GetDelay(XTimeBase *InstancePtr, int *VertDelayPtr,
			int *HoriDelayPtr);

/* Frame Sync setting */
void XTimeBase_SetSync(XTimeBase *InstancePtr, u16 FrameSyncIndex,
			   u16 VertStart, u16 HoriStart);
void XTimeBase_GetSync(XTimeBase *InstancePtr, u16 FrameSyncIndex,
			   u16 *VertStartPtr, u16 *HoriStartPtr);

/* Version functions */
void XTimeBase_GetVersion(XTimeBase *InstancePtr, u16 *Major, u16 *Minor,
				u16 *Revision);

/*
 * Initialization function(s) in xtimebase_sinit.c
 */
XTimeBase_Config *XTimeBase_LookupConfig(u16 DeviceId);

/*
 * Interrupt related function(s) in xtimebase_intr.c
 */
void XTimeBase_IntrHandler(void *InstancePtr);
int XTimeBase_SetCallBack(XTimeBase *InstancePtr, u32 IntrType,
				  void *CallBackFunc, void *CallBackRef);


#ifdef __cplusplus
}
#endif

#endif /* end of protection macro */
