/* $Id: */
/******************************************************************************
* (c) Copyright 2009 Xilinx, Inc. All rights reserved.
*
* This file contains confidential and proprietary information
* of Xilinx, Inc. and is protected under U.S. and
* international copyright and other intellectual property
* laws.
*
* DISCLAIMER
* This disclaimer is not a license and does not grant any
* rights to the materials distributed herewith. Except as
* otherwise provided in a valid license issued to you by
* Xilinx, and to the maximum extent permitted by applicable
* law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
* WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
* AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
* BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
* INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
* (2) Xilinx shall not be liable (whether in contract or tort,
* including negligence, or under any other theory of
* liability) for any loss or damage of any kind or nature
* related to, arising under or in connection with these
* materials, including for any direct, or any indirect,
* special, incidental, or consequential loss or damage
* (including loss of data, profits, goodwill, or any type of
* loss or damage suffered as a result of any action brought
* by a third party) even if such damage or loss was
* reasonably foreseeable or Xilinx had been advised of the
* possibility of the same.
*
* CRITICAL APPLICATIONS
* Xilinx products are not designed or intended to be fail-
* safe, or for use in any application requiring fail-safe
* performance, such as life-support or safety devices or
* systems, Class III medical devices, nuclear facilities,
* applications related to the deployment of airbags, or any
* other applications that could lead to death, personal
* injury, or severe property or environmental damage
* (individually and collectively, "Critical
* Applications"). Customer assumes the sole risk and
* liability of any use of Xilinx products in Critical
* Applications, subject only to applicable laws and
* regulations governing limitations on product liability.
*
* THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
* PART OF THIS FILE AT ALL TIMES.
*
* All rights reserved.
*
******************************************************************************/

/*****************************************************************************/
/**
 *
 * @file example.c
 *
 * This file demonstrates how to use Xilinx TimeBase driver on Xilinx MVI Video
 * TimeBase core.
 *
 * This code makes the following assumptions:
 * - Caching is disabled. Flushing and Invalidation operations for data buffer
 *   need to be added to this code if it is not the case.
 *
 *
 * <pre>
 * MODIFICATION HISTORY:
 *
 * Ver   Who  Date     Changes
 * ----- ---- -------- -------------------------------------------------------
 * 1.00a xd   04/23/09 First release
 * </pre>
 *
 * ***************************************************************************
 */

#include "xtimebase.h"
#include "xparameters.h"

/*
 * Device related constants. Defined in xparameters.h.
 */
#define TIMEBASE_DEVICE_ID	XPAR_TB_0_DEVICE_ID

/*
 * TimeBase Device related data structures
 */
XTimeBase TimeBase;			/* Device driver instance */
XTimeBase_TimeBaseSignal Signal;	/* TimeBase signal configuration */
XTimeBase_Polarity Polarity;		/* Polarity configuration */
XTimeBase_SourceSelect SourceSelect;	/* Source Selection configuration */

/*
 * Function prototypes
 */
static void SignalSetup(XTimeBase_TimeBaseSignal *SignalCfgPtr);
static int TimeBaseExample(u16 TimeBaseDeviceID);

/*****************************************************************************/
/**
*
* This is the main function for the TimeBase example.
*
* @param	None.
*
* @return	0 to indicate success, otherwise 1.
*
* @note	None.
*
****************************************************************************/
int main(void)
{
	int Status;

	/*
	 * Call the TimeBase example , specify the Device ID generated in
	 * xparameters.h
	 */
	Status = TimeBaseExample(TIMEBASE_DEVICE_ID);
	if (Status != 0) {
		return 1;
	}

	return 0;
}

/*****************************************************************************/
/**
*
* This function sets up the TimeBase Signal configuration.
*
* @param	None.
*
* @return	None.
*
* @note		None.
*
****************************************************************************/
static void SignalSetup(XTimeBase_TimeBaseSignal *SignalCfgPtr)
{
	int HFrontPorch;
	int HSyncWidth;
	int HBackPorch;
	int VFrontPorch;
	int VSyncWidth;
	int VBackPorch;
	int LineWidth;
	int FrameHeight;

	/* Choose the configuration for 720P60 */

	HFrontPorch = 110;
	HSyncWidth = 40;
	HBackPorch = 220;
	VFrontPorch = 5;
	VSyncWidth = 5;
	VBackPorch = 20;
	LineWidth = 1280;
	FrameHeight = 720;

	/* Clear the Signal config structure */

	memset((void *)SignalCfgPtr, 0, sizeof(XTimeBase_TimeBaseSignal));

	/* Populate the Signal config structure. Ignore the Field 1 */

	SignalCfgPtr->HFrontPorchStart = 0;
	SignalCfgPtr->HTotal = HFrontPorch + HSyncWidth + HBackPorch
				+ LineWidth - 1;
	SignalCfgPtr->HBackPorchStart = HFrontPorch + HSyncWidth;
	SignalCfgPtr->HSyncStart = HFrontPorch;
	SignalCfgPtr->HActiveStart = HFrontPorch + HSyncWidth + HBackPorch;

	SignalCfgPtr->V0FrontPorchStart = 0;
	SignalCfgPtr->V0Total = VFrontPorch + VSyncWidth + VBackPorch
				+ FrameHeight - 1;
	SignalCfgPtr->V0BackPorchStart = VFrontPorch + VSyncWidth;
	SignalCfgPtr->V0SyncStart = VFrontPorch;
	SignalCfgPtr->V0ChromaStart = VFrontPorch + VSyncWidth + VBackPorch;
	SignalCfgPtr->V0ActiveStart = VFrontPorch + VSyncWidth + VBackPorch;

	 return;
}

/*****************************************************************************/
/**
*
* This function is the entry of the feature demonstrations on MVI Video TimeBase
* core. It initializes the TimeBase device, then sets up the timebase signal
* for the generator module, polarities of the output, selects source, and last
* start the TimeBase device.
*
* @param	TimeBaseDeviceID is the device ID of the TimeBase core.
*
* @return	0 if all tests pass, 1 otherwise.
*
* @note		None.
*
******************************************************************************/
static int TimeBaseExample(u16 TimeBaseDeviceID)
{
	int Status;
	XTimeBase_Config *TimeBaseCfgPtr;

	/* Look for the device configuration info for the TimeBase. */

	TimeBaseCfgPtr = XTimeBase_LookupConfig(TIMEBASE_DEVICE_ID);
	if (TimeBaseCfgPtr == NULL) {
		return 1;
	}

	/* Initialize the TimeBase instance */

	Status = XTimeBase_CfgInitialize(&TimeBase, TimeBaseCfgPtr,
		TimeBaseCfgPtr->BaseAddress);
	if (Status != XST_SUCCESS) {
		return 1;
	}

	/* Set up Generator */

	SignalSetup(&Signal);
	XTimeBase_SetGenerator(&TimeBase, &Signal);

	/* Set up Polarity of all outputs */

	memset((void *)&Polarity, 0, sizeof(Polarity));
	Polarity.ActiveChromaPol = 1;
	Polarity.ActiveVideoPol = 1;
	Polarity.FieldIdPol = 0;
	Polarity.VBlankPol = 1;
	Polarity.VSyncPol = 1;
	Polarity.HBlankPol = 1;
	Polarity.HSyncPol = 1;

	XTimeBase_SetPolarity(&TimeBase, &Polarity);

	/* Set up source select */

	memset((void *)&SourceSelect, 0, sizeof(SourceSelect));
	SourceSelect.VChromaSrc = 1;
	SourceSelect.VActiveSrc = 1;
	SourceSelect.VBackPorchSrc = 1;
	SourceSelect.VSyncSrc = 1;
	SourceSelect.VFrontPorchSrc = 1;
	SourceSelect.VTotalSrc = 1;
	SourceSelect.HActiveSrc = 1;
	SourceSelect.HBackPorchSrc = 1;
	SourceSelect.HSyncSrc = 1;
	SourceSelect.HFrontPorchSrc = 1;
	SourceSelect.HTotalSrc = 1;

	XTimeBase_SetSource(&TimeBase, &SourceSelect);

	/* Enable both generator and detector modules */

	XTimeBase_Enable(&TimeBase, XTB_EN_GENERATOR | XTB_EN_DETECTOR);

	/* Return success */

	return 0;
}
