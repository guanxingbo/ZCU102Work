/*
 * axipmon.h
 *
 *  Created on: Aug 6, 2012
 *      Author: ckohn
 */

#ifndef AXIPMON_H_
#define AXIPMON_H_


#include "xaxipmon.h"


XAxiPmon *XAxiPmon_Initialize(u16 DeviceId);


#endif /* AXIPMON_H_ */
