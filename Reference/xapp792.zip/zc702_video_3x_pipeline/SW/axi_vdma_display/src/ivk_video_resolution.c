//----------------------------------------------------------------
//      _____
//     /     \
//    /____   \____
//   / \===\   \==/
//  /___\===\___\/  AVNET
//       \======/
//        \====/
//---------------------------------------------------------------
//
// This design is the property of Avnet.  Publication of this
// design is not authorized without written consent from Avnet.
//
// Please direct any questions to:  technical.support@avnet.com
//
// Disclaimer:
//    Avnet, Inc. makes no warranty for the use of this code or design.
//    This code is provided  "As Is". Avnet, Inc assumes no responsibility for
//    any errors, which may appear in this code, nor does it make a commitment
//    to update the information contained herein. Avnet, Inc specifically
//    disclaims any implied warranties of fitness for a particular purpose.
//                     Copyright(c) 2010 Avnet, Inc.
//                             All rights reserved.
//
//----------------------------------------------------------------
//
// Create Date:         Mar 05, 2010
// Design Name:         IVK Video Resolution
// Module Name:         ivk_video_resolution.c
// Project Name:        IVK
// Target Devices:      Spartan-6
// Avnet Boards:        IVK
//
// Tool versions:       ISE 11.4
//
// Description:         IVK Video Resolution
//                      - video timing definitions
//                      - video resolution detection (using ivk_video_det pcore)
//                      - video timing generation (using ivk_video_gen pcore)
//
// Dependencies:
//
// Revision:            Mar 05, 2010: 1.00 Initial version
//
//----------------------------------------------------------------

#include <stdio.h>
#include "ivk_video_resolution.h"

// Located in: microblaze_0/include/
#include "xbasic_types.h"
#include "xutil.h"
//#include "xintc.h"
#include "xscugic.h"

#include "xparameters.h"
#include "xstatus.h"

#if defined(XPAR_IVK_VIDEO_DET_NUM_INSTANCES)
#include "ivk_video_det.h"
#endif
#if defined(XPAR_IVK_VIDEO_GEN_NUM_INSTANCES)
#include "ivk_video_gen.h"
#endif
#if defined(XPAR_VTC_0_DEVICE_ID)
#include "xvtc.h"
XVtc TimeBaseDet;
XVtc_VtcSignal SignalDet;
#define TIMEBASE_DET_ID XPAR_VTC_0_DEVICE_ID
#endif
#if defined(XPAR_VTC_1_DEVICE_ID)
#include "xvtc.h"
XVtc TimeBaseGen;
XVtc_VtcSignal SignalGen;
XVtc_Polarity PolarityGen;
XVtc_SourceSelect SourceSelectGen;
#define TIMEBASE_GEN_ID XPAR_VTC_1_DEVICE_ID
#endif

#define NUM_VIDEO_TIMING_PARAMS 10
static Xint8 *pVideoTimingParamNames[NUM_VIDEO_TIMING_PARAMS] = {
	"vav", // Vertical Active Video
   "vfp", // Vertical Front Porch
   "vsw", // Vertical Sync Width
   "vbp", // Vertical Back Porch
   "vsp", // Vertical Sync Polarity
	"hav", // Horizontal Active Video
   "hfp", // Horizontal Front Porch
   "hsw", // Horizontal Sync Width
   "hbp", // Horizontal Back Porch
   "hsp"  // Horizontal Sync Polarity
};

static Xuint16 pVideoTimingParamValues[NUM_VIDEO_RESOLUTIONS][NUM_VIDEO_TIMING_PARAMS] = {
   // vav,  vfp,  vsw,  vbp,  vsp,  hav,  hfp,  hsw,  hbp,  hsp
   {  480,   10,    2,   33,    0,  640,   16,   96,   48,    0 }, // VIDEO_RESOLUTION_VGA
   {  480,    9,    6,   30,    1,  720,   16,   62,   60,    1 }, // VIDEO_RESOLUTION_NTSC
   {  600,    1,    4,   23,    1,  800,   40,  128,   88,    1 }, // VIDEO_RESOLUTION_SVGA
   {  768,    3,    6,   29,    0, 1024,   24,  136,  160,    0 }, // VIDEO_RESOLUTION_XGA
   {  720,    5,    5,   20,    1, 1280,  110,   40,  220,    1 }, // VIDEO_RESOLUTION_720P
   { 1024,    1,    3,   26,    0, 1280,   48,  184,  200,    0 }, // VIDEO_RESOLUTION_SXGA
   { 1080,    4,    5,   36,    1, 1920,   88,   44,  148,    1 }, // VIDEO_RESOLUTION_1080P
   { 1200,    1,    3,   46,    0, 1600,   64,  192,  304,    0 }  // VIDEO_RESOLUTION_UXGA
};

static char *pVideoTimingNames[NUM_VIDEO_RESOLUTIONS] = {
   "VGA",   // VIDEO_RESOLUTION_VGA
   "NTSC",  // VIDEO_RESOLUTION_NTSC
   "SVGA",  // VIDEO_RESOLUTION_SVGA
   "XGA",   // VIDEO_RESOLUTION_XGA
   "720P",  // VIDEO_RESOLUTION_720P
   "SXGA",  // VIDEO_RESOLUTION_SXGA
   "1080P", // VIDEO_RESOLUTION_1080P
   "UXGA"   // VIDEO_RESOLUTION_UXGA
};


char *ivk_vres_get_name(Xuint32 resolutionId)
{
   if ( resolutionId < NUM_VIDEO_RESOLUTIONS )
   {
      return pVideoTimingNames[resolutionId];
   }
   else
   {
      return "{UNKNOWN}";
   }
}

Xuint32 ivk_vres_get_width(Xuint32 resolutionId)
{
   return pVideoTimingParamValues[resolutionId][5]; // horizontal active
}

Xuint32 ivk_vres_get_height(Xuint32 resolutionId)
{
   return pVideoTimingParamValues[resolutionId][0]; // vertical active
}

/////////////////////////////////////////////////////////////////////////
//XIntc sys_intc;
volatile int timebase_all_lock_cnt = 0;
int timebase_all_lock_cnt_last = 0;

void timebase_lock_handler(void *ref)
{
	timebase_all_lock_cnt++;
}

/////////////////////////////////////////////////////////////////////////
Xint32 ivk_vres_detect( void )
{
#if defined(XPAR_IVK_VIDEO_DET_NUM_INSTANCES)
  Xuint32 hsize;
  Xuint32 vsize;
  Xint32 resolution = -1;
  int i;

  read_IVK_VIDEO_DET_video_dimensions( XPAR_IVK_VIDEO_DET_0_BASEADDR, &hsize, &vsize );
  xil_printf( "Detected Video Dimensions = %d x %d\r\n", hsize, vsize );

   // MASSIVE XACTI 480P TIMEBASE KLUDGE!
   hsize=720;
   vsize=480;

  for ( i = 0; i < NUM_VIDEO_RESOLUTIONS; i++ )
  {
     if ( hsize == ivk_vres_get_width(i) && vsize == ivk_vres_get_height(i) )
     {
        xil_printf( "Detected Video Resolution = %s\r\n", ivk_vres_get_name(i) );
        resolution = i;
        break;
     }
  }

  if ( resolution == -1 )
  {
     xil_printf( "Unknown Video Resolution !\r\n" );
  }
#if !defined(TIMEBASE_DET_ID)
  return resolution;
#endif
#endif
#if defined(TIMEBASE_DET_ID)
	#if !defined(XPAR_IVK_VIDEO_DET_NUM_INSTANCES)
  Xuint32 hsize;
  Xuint32 vsize;
  Xint32 resolution = -1;
  int i;
	#endif
  u16 DeviceId = XPAR_PS7_SCUGIC_0_DEVICE_ID;
  int intr_id = XPAR_FABRIC_AXI_VTC_0_IP2INTC_IRPT_INTR;
  int status;
  XVtc_Polarity Polarity;

  XVtc_Config *TimeBaseCfgPtr;

  TimeBaseCfgPtr = XVtc_LookupConfig(TIMEBASE_DET_ID);
  if (TimeBaseCfgPtr == NULL) {
	  return 1;
  }

  /* Initialize the TimeBaseGen instance */

  status = XVtc_CfgInitialize(&TimeBaseDet, TimeBaseCfgPtr,
		  TimeBaseCfgPtr->BaseAddress);
  if (status != XST_SUCCESS) {
	  return 1;
  } // TimeBaseGen
  /////////////////////////////////////////////////////////////////////////////
#if 0


		/*
		 * Initialize the interrupt controller driver so that it is ready to
		 * use.
		 */
		IntcConfig = XScuGic_LookupConfig(INTC_DEVICE_ID);
		if (NULL == IntcConfig) {
			return XST_FAILURE;
		}

		Status = XScuGic_CfgInitialize(&sys_intc, IntcConfig,
						IntcConfig->CpuBaseAddress);
		if (Status != XST_SUCCESS) {
			return XST_FAILURE;
		}

	XVtc_SetCallBack(&TimeBaseDet, XVTC_HANDLER_LOCK, timebase_lock_handler, &TimeBaseDet);

	#define XScuGic_INT_CFG_OFFSET_CALC(InterruptID) \
	    (XSCUGIC_INT_CFG_OFFSET + ((InterruptID/16) * 4))

	#define XScuGic_INT_CFG_VALUE(InterruptID) \
	    (3UL << ((InterruptID % 16) * 2))

	   	XScuGic_DistWriteReg(IntcInstancePtr,
				XScuGic_INT_CFG_OFFSET_CALC(intr_id), XScuGic_INT_CFG_VALUE(intr_id));





		/*
		 * Connect the device driver handler that will be called when an
		 * interrupt for the device occurs, the handler defined above performs
		 * the specific interrupt processing for the device.
		 */
		Status = XScuGic_Connect(&sys_intc, intr_id,
					(Xil_InterruptHandler)XVtc_IntrHandler, &TimeBaseDet);
		if (Status != XST_SUCCESS) {
			return Status;
		}



		/*
		 * Enable the interrupt for the CAN device.
		 */
		XScuGic_Enable(&sys_intc, intr_id);

		Xil_ExceptionInit();

		/*
		 * Connect the interrupt controller interrupt handler to the hardware
		 * interrupt handling logic in the processor.
		 */
		Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_IRQ_INT,
					(Xil_ExceptionHandler)XScuGic_InterruptHandler,
					&sys_intc);


		/*
		 * Enable interrupts in the Processor.
		 */
		Xil_ExceptionEnable();


/*
	status = XIntc_Initialize(&sys_intc , DeviceId);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

//	XTimeBase_SetCallBack(&TimeBaseDet, XTB_HANDLER_DETECTOR, timebase_det_vblank_handler, &TimeBaseDet);
//	XTimeBase_SetCallBack(&TimeBaseDet, XTB_HANDLER_GENERATOR, timebase_gen_vblank_handler, &TimeBaseDet);
//	XTimeBase_SetCallBack(&TimeBaseDet, XTB_HANDLER_FRAMESYNC, timebase_fsync_handler, &TimeBaseDet);
	XTimeBase_SetCallBack(&TimeBaseDet, XTB_HANDLER_LOCK, timebase_lock_handler, &TimeBaseDet);

	XIntc_Connect (&sys_intc, intr_id, (XInterruptHandler)XTimeBase_IntrHandler, &TimeBaseDet);
	XIntc_Enable (&sys_intc, intr_id);
        microblaze_register_handler(XIntc_InterruptHandler, &sys_intc);
        XIntc_Start(&sys_intc, XIN_REAL_MODE);
        microblaze_enable_interrupts();
        */
#endif
  /////////////////////////////////////////////////////////////////////////////

  // Set the Sync enable bit
  XVtc_WriteReg(TimeBaseDet.Config.BaseAddress, XVTC_CTL, 0x04);

  XVtc_Disable(&TimeBaseDet, XVTC_EN_DETECTOR|XVTC_EN_GENERATOR);

  XVtc_IntrSetLockPolarity(&TimeBaseDet, 1);
  XVtc_IntrClear(&TimeBaseDet, XVtc_ReadReg(TimeBaseDet.Config.BaseAddress, XVTC_ISR));
  timebase_all_lock_cnt_last = timebase_all_lock_cnt;
  XVtc_IntrEnableGlobal(&TimeBaseDet);
  XVtc_IntrEnableGlobal(&TimeBaseDet);


  // Set polarity of generated output to High
  memset((void *)&Polarity, 0, sizeof(Polarity));
  Polarity.ActiveChromaPol    = 1;
  Polarity.ActiveVideoPol     = 1;
  Polarity.FieldIdPol         = 1;
  Polarity.VBlankPol          = 1;
  Polarity.VSyncPol           = 1;
  Polarity.HBlankPol          = 1;
  Polarity.HSyncPol           = 1;
  XVtc_IntrSetLockPolarity(&TimeBaseDet, &Polarity);


  XVtc_Enable(&TimeBaseDet, XVTC_EN_DETECTOR|XVTC_EN_GENERATOR);

	print("Waiting for detector lock...");
	i= 0;
	//while((timebase_all_lock_cnt == timebase_all_lock_cnt_last) && (i < 10000))
	while((  ((XVtc_IntrGetPending(&TimeBaseDet) & 0x00000080) != 0x00000080)
              || (SignalDet.HFrontPorchStart == 0)
              || (SignalDet.V0FrontPorchStart == 0)
              || (SignalDet.HActiveStart == 0)
              || (SignalDet.V0ActiveStart == 0))
                        && (i < 1000))
	{
			  print(".");
			  usec_wait(5000);
                          XVtc_GetDetector(&TimeBaseDet, &SignalDet);
			  i++;
	}
	print("Done.\n\r");
	if(i == 1000)
	{
			  xil_printf("ERROR: Lock not found %08x.\n\r", XVtc_IntrGetPending(&TimeBaseDet));
	}

  //XTimeBase_GetDetector(&TimeBaseDet, &SignalDet);

  xil_printf( "HTotal = %d\r\n", SignalDet.HTotal);
  xil_printf("HActiveStart = %d\r\n", SignalDet.HActiveStart);
  xil_printf("HFrontPorchStart %d\r\n", SignalDet.HFrontPorchStart);
  xil_printf("HBackPorchStart %d\r\n", SignalDet.HBackPorchStart);
  xil_printf("HSyncStart %d\r\n", SignalDet.HSyncStart);
  xil_printf("V0FrontPorchStart %d\r\n", SignalDet.V0FrontPorchStart);
  xil_printf("V0Total %d\r\n", SignalDet.V0Total);
  xil_printf("V0BackPorchStart %d\r\n", SignalDet.V0BackPorchStart);
  xil_printf("V0SyncStart %d\r\n", SignalDet.V0SyncStart);
  xil_printf("V0ChromaStart %d\r\n", SignalDet.V0ChromaStart);
  xil_printf("V0ActiveStart %d\r\n", SignalDet.V0ActiveStart);

  hsize = SignalDet.HFrontPorchStart - SignalDet.HActiveStart;
  vsize = SignalDet.V0FrontPorchStart - SignalDet.V0ActiveStart;

  xil_printf( "Detected Video Dimensions = %d x %d\r\n", hsize, vsize );
#if 0
   // MASSIVE XACTI 480P TIMEBASE KLUDGE!
   if (hsize<1000)
   {
      hsize=720;
      vsize=480;
      xil_printf( "MASSIVE XACTI 480P TIMEBASE KLUDGE:\r\n     Forcing hsize=%d, vsize= %d!\r\n", hsize, vsize );
   }
#endif

  for ( i = 0; i < NUM_VIDEO_RESOLUTIONS; i++ )
  {
     if ( hsize == ivk_vres_get_width(i) && vsize == ivk_vres_get_height(i) )
     {
        xil_printf( "Detected Video Resolution = %s\r\n", ivk_vres_get_name(i) );
        resolution = i;
        break;
     }
  }

  return resolution;
#endif
}

Xuint32 ivk_vres_generate( Xuint32 resolutionId )
{
#if defined(XPAR_IVK_VIDEO_GEN_NUM_INSTANCES)
   video_timing_t config;
   config.h_active    = pVideoTimingParamValues[resolutionId][5]; // horizontal active
   config.h_fporch    = pVideoTimingParamValues[resolutionId][6]; // horizontal front porch
   config.h_syncpol   = pVideoTimingParamValues[resolutionId][9]; // horizontal sync polarity
   config.h_syncwidth = pVideoTimingParamValues[resolutionId][7]; // horizontal sync width
   config.h_bporch    = pVideoTimingParamValues[resolutionId][8]; // horizontal back porch
   config.v_active    = pVideoTimingParamValues[resolutionId][0]; // vertical active
   config.v_fporch    = pVideoTimingParamValues[resolutionId][1]; // vertical front porch
   config.v_syncpol   = pVideoTimingParamValues[resolutionId][4]; // vertical sync polarity
   config.v_syncwidth = pVideoTimingParamValues[resolutionId][2]; // vertical sync width
   config.v_bporch    = pVideoTimingParamValues[resolutionId][3]; // vertical back porch
   write_IVK_VIDEO_GEN_video_timing( XPAR_IVK_VIDEO_GEN_0_BASEADDR, &config );
   //xil_printf("Inside IVK\r\n");
#endif
#if defined(TIMEBASE_GEN_ID)
	int HFrontPorch;
	int HSyncWidth;
	int HBackPorch;
	int VFrontPorch;
	int VSyncWidth;
	int VBackPorch;
	int LineWidth;
	int FrameHeight;
	int status;
    XScuGic_Config *IntcConfig; /* Instance of the interrupt controller */
	XVtc_Config *TimeBaseCfgPtr;

   //xil_printf("Inside setup of Timebase\r\n");

	TimeBaseCfgPtr = XVtc_LookupConfig(TIMEBASE_GEN_ID);
	if (TimeBaseCfgPtr == NULL) {
		return 1;
	}

	/* Initialize the TimeBaseGen instance */

   //xil_printf("lookup\r\n");

	status = XVtc_CfgInitialize(&TimeBaseGen, TimeBaseCfgPtr,
									TimeBaseCfgPtr->BaseAddress);
	if (status != XST_SUCCESS) {
	   return 1;
	}   // TimeBaseGen

   //xil_printf("config\r\n");

	HFrontPorch = pVideoTimingParamValues[resolutionId][6];
	HSyncWidth = pVideoTimingParamValues[resolutionId][7];
	HBackPorch = pVideoTimingParamValues[resolutionId][8];
	VFrontPorch = pVideoTimingParamValues[resolutionId][1];
	VSyncWidth = pVideoTimingParamValues[resolutionId][2];
	VBackPorch = pVideoTimingParamValues[resolutionId][3];
	LineWidth = pVideoTimingParamValues[resolutionId][5];
	FrameHeight = pVideoTimingParamValues[resolutionId][0];

	SignalGen.HFrontPorchStart = 0;
	SignalGen.HTotal = HFrontPorch + HSyncWidth + HBackPorch + LineWidth - 1;
	SignalGen.HBackPorchStart = HFrontPorch + HSyncWidth;
	SignalGen.HSyncStart = HFrontPorch;
	SignalGen.HActiveStart = HFrontPorch + HSyncWidth + HBackPorch;
	SignalGen.V0FrontPorchStart = 0;
	SignalGen.V0Total = VFrontPorch + VSyncWidth + VBackPorch + FrameHeight - 1;
	SignalGen.V0BackPorchStart = VFrontPorch + VSyncWidth;
	SignalGen.V0SyncStart = VFrontPorch;
	SignalGen.V0ChromaStart = VFrontPorch + VSyncWidth + VBackPorch;
	SignalGen.V0ActiveStart = VFrontPorch + VSyncWidth + VBackPorch;

	XVtc_SetGenerator(&TimeBaseGen, &SignalGen);
   //xil_printf("generator\r\n");

    PolarityGen.ActiveChromaPol = 1;
    PolarityGen.ActiveVideoPol = 1;
    PolarityGen.FieldIdPol = 0;
    PolarityGen.VBlankPol = pVideoTimingParamValues[resolutionId][4];
    PolarityGen.VSyncPol = pVideoTimingParamValues[resolutionId][4];
    PolarityGen.HBlankPol = pVideoTimingParamValues[resolutionId][9];
    PolarityGen.HSyncPol = pVideoTimingParamValues[resolutionId][9];

    XVtc_SetPolarity(&TimeBaseGen, &PolarityGen);
   //xil_printf("polarity\r\n");

    SourceSelectGen.VChromaSrc = 1;
    SourceSelectGen.VActiveSrc = 1;
    SourceSelectGen.VBackPorchSrc = 1;
    SourceSelectGen.VSyncSrc = 1;
    SourceSelectGen.VFrontPorchSrc = 1;
    SourceSelectGen.VTotalSrc = 1;
    SourceSelectGen.HActiveSrc = 1;
    SourceSelectGen.HBackPorchSrc = 1;
    SourceSelectGen.HSyncSrc = 1;
    SourceSelectGen.HFrontPorchSrc = 1;
    SourceSelectGen.HTotalSrc = 1;

    XVtc_SetSource(&TimeBaseGen, &SourceSelectGen);
   //xil_printf("source\r\n");

    XVtc_Enable(&TimeBaseGen, XVTC_EN_GENERATOR);
       //xil_printf("enable\r\n");


#endif
}

