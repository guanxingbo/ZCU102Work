/*
 * ivk_video_resolution.h
 *
 *  Created on: Oct 26, 2010
 *      Author: rslous
 */

#ifndef IVK_VIDEO_RESOLUTION_H_
#define IVK_VIDEO_RESOLUTION_H_

#include "xbasic_types.h"
#include "xutil.h"
#include "xparameters.h"
#include "xstatus.h"

// Video Pattern Generator - Video Resolution values^M
#define VIDEO_RESOLUTION_VGA       0
#define VIDEO_RESOLUTION_NTSC      1
#define VIDEO_RESOLUTION_SVGA      2
#define VIDEO_RESOLUTION_XGA       3
#define VIDEO_RESOLUTION_720P      4
#define VIDEO_RESOLUTION_SXGA      5
#define VIDEO_RESOLUTION_1080P     6
#define VIDEO_RESOLUTION_UXGA      7
#define NUM_VIDEO_RESOLUTIONS      8

char *  ivk_vres_get_name(Xuint32 resolutionId);
Xuint32 ivk_vres_get_width(Xuint32 resolutionId);
Xuint32 ivk_vres_get_height(Xuint32 resolutionId);

Xint32 ivk_vres_detect( void );
Xuint32 ivk_vres_generate(Xuint32 resolutionId);

#endif /* IVK_VIDEO_RESOLUTION_H_ */
