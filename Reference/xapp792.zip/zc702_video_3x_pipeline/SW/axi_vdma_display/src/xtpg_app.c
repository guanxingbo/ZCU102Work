//////////////////////////////////////////////////////////////////////////////
// Filename:          D:\SVN_Projects\trunk\VideoAnalytics\dev\MotionDetect\implementation\VSK\vsk_base_platform/drivers/xTPG_v1_00_a/src/xTPG_app.c
// Version:           1.00.a
// Description:       xTPG Driver Source File
// Date:              Mon May 05 14:07:48 2008 (by Create and Import Peripheral Wizard)
//////////////////////////////////////////////////////////////////////////////



/***************************** Include Files *******************************/

#include <stdio.h>

// Located in: microblaze_0/include/xparameters.h
#include "xutil.h"
#include "xil_io.h"
#include "xparameters.h"
#include "xtpg_app.h"
#include "xaxipmon.h"
#include "xil_testmem.h"

#define SinTableDepth 2048
#define ENABLE_ZONEPLATE_AND_SWEEPS 1
#ifdef XPAR_AXI_TPG_0_BASEADDR


#define XPAR_AXI_PERF_MON_0_ENABLE_EVENT_COUNT 1

void xTPG_help(void);
void xTPG_config(int FrameSize);
XAxiPmon *XAxiPmon_Initialize(u16 DeviceId);
void DisplayPerfNumbers(XAxiPmon *Instance, u8 AgentNum);

static XAxiPmon AxiPmonInst;      /* System Monitor driver instance */

double VDMA_0_READ_VAL;
double VDMA_0_WRITE_VAL;

double VDMA_1_READ_VAL;
double VDMA_1_WRITE_VAL;

double VDMA_2_READ_VAL;
double VDMA_2_WRITE_VAL;


void xTPG_main (int width, int height)
{
   unsigned char inchar;
   Xuint32 Reg32Value, NewXHairHCoord, NewXHairVCoord, CompMaskValue, CrCbPolarity, NewBoxComponentVal, NewBoxSize, CurrentPattern, CurrentBoxColourPreset, CurrentSpeed;
//   int width = 1280;
//   int height = 720;
	int n;
	int Status;
	double total_bandwidth;
	double total_mem_bandwidth;
	double percent_of_bandwidth;

   Xuint32 FrameSize = height<<16 | width;

   CurrentBoxColourPreset =0;

  XAxiPmon *AxiPmon_0 = XAxiPmon_Initialize(XPAR_AXI_PERF_MON_0_DEVICE_ID);

   total_mem_bandwidth = ((533.3333333*32)/8)*2;
   xTPG_config(FrameSize);
   xTPG_help();

            Reg32Value = XTPG_mReadSlaveReg0(XPAR_AXI_TPG_0_BASEADDR, 0);
            XTPG_mWriteSlaveReg0(XPAR_AXI_TPG_0_BASEADDR, 0, ((Reg32Value & 0xFFFFFFD0)|0x00000009));


            if (ENABLE_ZONEPLATE_AND_SWEEPS == 1)
            {
               Reg32Value = XTPG_mReadSlaveReg0(XPAR_AXI_TPG_1_BASEADDR, 0);
               XTPG_mWriteSlaveReg0(XPAR_AXI_TPG_1_BASEADDR, 0, (Reg32Value & 0xFFFFFFF0) | 10);
               XTPG_mWriteSlaveReg4(XPAR_AXI_TPG_1_BASEADDR, 0, ((1<<5)*SinTableDepth)*2/width);
               XTPG_mWriteSlaveReg5(XPAR_AXI_TPG_1_BASEADDR, 0, ((1<<5)*SinTableDepth)*2/height);
               //Enable Motion
               Reg32Value = XTPG_mReadSlaveReg1(XPAR_AXI_TPG_1_BASEADDR, 0);
                if ((Reg32Value & 0x00000001)==0)
                 XTPG_mWriteSlaveReg1(XPAR_AXI_TPG_1_BASEADDR, 0, (Reg32Value | 0x00000001));
                else
                 XTPG_mWriteSlaveReg1(XPAR_AXI_TPG_1_BASEADDR, 0, (Reg32Value & 0xFFFFFFFE));
            }

            if (ENABLE_ZONEPLATE_AND_SWEEPS == 1)
            {
               Reg32Value = XTPG_mReadSlaveReg0(XPAR_AXI_TPG_2_BASEADDR, 0);
               XTPG_mWriteSlaveReg0(XPAR_AXI_TPG_2_BASEADDR, 0, (Reg32Value & 0xFFFFFFF0) | 10);
               XTPG_mWriteSlaveReg4(XPAR_AXI_TPG_2_BASEADDR, 0, 1);
               XTPG_mWriteSlaveReg5(XPAR_AXI_TPG_2_BASEADDR, 0, 0); // Zoneplate with 0 vertical component
            }



   while (1)
   {
      print(">");
      inchar = inbyte();
      xil_printf("%c\n\r",inchar);
      switch (inchar)
      {
         case 0x1b :
         case 'q' :
            xil_printf("- exit menu -\n\n\r"); return; break;
         case '?' :
         {
            xTPG_help();
            break;
         }
         case 'R' :
         {


            break;
         }
         case 'r' :
         {

            break;
         }
         case '0':  // First layer only
         {

			Xil_Out32(XPAR_OSD_0_BASEADDR+0x20,0x00FF0003);

			Xil_Out32(XPAR_OSD_0_BASEADDR+0x40,0x00000203);

			Xil_Out32(XPAR_OSD_0_BASEADDR+0x30,0x00000103);



			//Xil_Out32(0x73A00030,0x00FF0101);
            break;
         }
         case '1': // Second layer only
         {

			Xil_Out32(XPAR_OSD_0_BASEADDR+0x20,0x00000003);

			Xil_Out32(XPAR_OSD_0_BASEADDR+0x40,0x00000203);

			Xil_Out32(XPAR_OSD_0_BASEADDR+0x30,0x00FF0103);

			//Xil_Out32(0x73A00030,0x00FF0103);
            break;
         }
         case '2': // Third layer only
         {



 			Xil_Out32(XPAR_OSD_0_BASEADDR+0x20,0x00FF0003);


 			Xil_Out32(XPAR_OSD_0_BASEADDR+0x30,0x00000103);

  			Xil_Out32(XPAR_OSD_0_BASEADDR+0x40,0x00FF0203);


            break;
         }
         case '3': // Fourth layer only
         {
	    	    //Xil_Out32(XPAR_OSD_0_BASEADDR+0x50,0x007F0303);

	     	    Xil_Out32(XPAR_OSD_0_BASEADDR+0x40,0x001F0203);

	    	    Xil_Out32(XPAR_OSD_0_BASEADDR+0x30,0x00100103);

	    	    Xil_Out32(XPAR_OSD_0_BASEADDR+0x20,0x00100003);

   			    //Xil_Out32(XPAR_OSD_0_BASEADDR+0x60,0x003F0403);


            break;
         }

         case '4': // Fifth layer only
         {


     Status = Xil_TestMem32((u32*)0x21000000, 0x400000, 0xAAAA5555, XIL_TESTMEM_ALLMEMTESTS);
     xil_printf("32-bit test: "); xil_printf(Status == XST_SUCCESS? "PASSED!":"FAILED!"); xil_printf("\n\r");


            break;
         }

         case '5': //Split up layers and show at same time
         {

				//Init global vars to 0
				VDMA_0_READ_VAL = 0;
				VDMA_0_WRITE_VAL = 0;

				VDMA_1_READ_VAL = 0;
				VDMA_1_WRITE_VAL = 0;

				VDMA_2_READ_VAL = 0;
				VDMA_2_WRITE_VAL = 0;

				DisplayPerfNumbers(AxiPmon_0, 0);
				xil_printf("\r\n");
				DisplayPerfNumbers(AxiPmon_0, 1);
				xil_printf("\r\n");
				DisplayPerfNumbers(AxiPmon_0, 2);
				xil_printf("\r\n");

            total_bandwidth = VDMA_0_READ_VAL + VDMA_0_WRITE_VAL + VDMA_1_READ_VAL + VDMA_1_WRITE_VAL + VDMA_2_READ_VAL + VDMA_2_WRITE_VAL;
            total_bandwidth = total_bandwidth * .000001;

            percent_of_bandwidth = (total_bandwidth/total_mem_bandwidth) * 100;

            printf("System Total Bandwidth = %f MB/s\r\n",total_bandwidth);
            printf("DDR3 Theoretical Bandwidth = %f MB/s\r\n",total_mem_bandwidth);
            printf("Percent of DDR3 Theoretical Bandwidth = %f%%\r\n",percent_of_bandwidth);

            break;
         }


         case '6':
         {

            break;
         }

         case '7':
         {

            break;
         }


         case 'h': // Horizontal Sweep
         {

            break;
         }

         case 'j': // Horizontal Sweep increase delta2
         {

            break;
         }
         case 'g': // Horizontal Sweep decrease delta2
         {

            break;
         }

         case 'v': // Vertical Sweep
         {

            break;
         }

         case 'b': // Horizontal Sweep increase delta2
         {

            break;
         }
         case 'c': // Horizontal Sweep decrease delta2
         {

            break;
         }

         case 'z': // Zone-Plate
         {

            break;
         }

         case 'x': // Crosshairs
         {

            break;
         }
         case 'p': // Horizontal Crosshair - decrease V coordinate
         {

            break;
         }
         case 'l': // Horizontal Crosshair - increase V coordinate
         {

            break;
         }
         case 'a': // Vertical Crosshair - decrease H coordinate
         {

            break;
         }
         case 's': // Vertical Crosshair - increase H coordinate
         {

            break;
         }
      }
   }
}

/************************** Function Definitions ***************************/

/**
 * Enable all possible interrupts from XTPG device.
 * @param   baseaddr_p is the base address of the XTPG device.
 * @return  None.
 * @note    None.
 */
//void XTPG_EnableInterrupt(void * baseaddr_p)
//{
//  Xuint32 baseaddr;
//  baseaddr = (Xuint32) baseaddr_p;
//
//  /*
//   * Enable all interrupt source from user logic.
//   */
//  XTPG_mWriteReg(baseaddr, XTPG_INTR_IPIER_OFFSET, 0x0000000F);
//
//  /*
//   * Enable all possible interrupt sources from device.
//   */
//  XTPG_mWriteReg(baseaddr, XTPG_INTR_DIER_OFFSET,
//    INTR_TERR_MASK
//    | INTR_DPTO_MASK
//    | INTR_IPIR_MASK
//    );
//
//  /*
//   * Set global interrupt enable.
//   */
//  XTPG_mWriteReg(baseaddr, XTPG_INTR_DGIER_OFFSET, INTR_GIE_MASK);
//}


void xTPG_help(void)
{
  print("\n\r");
  print("-----------------------------------------------------\n\r");
  print("-- Layer Switcher/Performance Menu                 --\n\r");
  print("-----------------------------------------------------\n\r");
  print("\n\r");
  print(" Select option\n\r");
  print(" 0 = Layer 0 Only - Colorbars\n\r");
  print(" 1 = Layer 1 Only - Zoneplates\n\r");
  print(" 2 = Layer 2 Only - Vertical Sweep\n\r");
  print(" 3 = Alpha blend (All Layers)\n\r");
  print(" 4 = Memory Test DDR3 (32-bit 16 MB Test)\n\r");
  print(" 5 = Benchmark Design (Average)\n\r");
  print("\n\r");
  print(" q = exit \n\r");
  print(" ?  = help \n\r");
  print("-----------------------------------------------------\n\r");
}


void xTPG_config(int FrameSize)
{
   Xuint32 Reg32Value;

   // Read current test-pattern setting.
   Reg32Value = XTPG_mReadSlaveReg0(XPAR_AXI_TPG_0_BASEADDR, 0);
   XTPG_mWriteSlaveReg0(XPAR_AXI_TPG_0_BASEADDR, 0, (Reg32Value & 0x0000000F));

   XTPG_mWriteSlaveReg0(XPAR_AXI_TPG_0_BASEADDR, 0, 0x00);   // PatternSel = 0 (passthru);
                                                      // Box off (bit 9)
                                                      // XHairs Off (bit 4)
                                                      // CrCb Polarity = 0 (bit 5)
   XTPG_mWriteSlaveReg1(XPAR_AXI_TPG_0_BASEADDR, 0, 2);   // Motion Off (bit 0)
                                                      // Motion speed set to 1 (bits 8:1)
   XTPG_mWriteSlaveReg2(XPAR_AXI_TPG_0_BASEADDR, 0, (573<<16) | 360); // XHairs set at (573H, 360V)
   XTPG_mWriteSlaveReg3(XPAR_AXI_TPG_0_BASEADDR, 0, FrameSize); // Frame size set according to parameter
   XTPG_mWriteSlaveReg4(XPAR_AXI_TPG_0_BASEADDR, 0, 1);   // Set zone plate HDalta2 to 1 (bits 11:0)
                                                      // Set zone plate H sin-table address offset to 0 (bits 27:16)
   XTPG_mWriteSlaveReg5(XPAR_AXI_TPG_0_BASEADDR, 0, 1);   // Set zone plate VDalta2 to 1 (bits 11:0)
                                                      // Set zone plate V sin-table address offset to 0 (bits 27:16)
   XTPG_mWriteSlaveReg6(XPAR_AXI_TPG_0_BASEADDR, 0, 64);  // Set box size to 64
//   XTPG_mWriteSlaveReg7(XPAR_AXI_TPG_0_BASEADDR, 0, 0x00F06E29);  // Set box colour to mid blue
   XTPG_mWriteSlaveReg7(XPAR_AXI_TPG_0_BASEADDR, 0, 0x005AF051);  // Set box colour to mid blue

//Second one
   // Read current test-pattern setting.
   Reg32Value = XTPG_mReadSlaveReg0(XPAR_AXI_TPG_0_BASEADDR, 0);
   XTPG_mWriteSlaveReg0(XPAR_AXI_TPG_1_BASEADDR, 0, (Reg32Value & 0x0000000F));

   XTPG_mWriteSlaveReg0(XPAR_AXI_TPG_1_BASEADDR, 0, 0x00);   // PatternSel = 0 (passthru);
                                                      // Box off (bit 9)
                                                      // XHairs Off (bit 4)
                                                      // CrCb Polarity = 0 (bit 5)
   XTPG_mWriteSlaveReg1(XPAR_AXI_TPG_1_BASEADDR, 0, 2);   // Motion Off (bit 0)
                                                      // Motion speed set to 1 (bits 8:1)
   XTPG_mWriteSlaveReg2(XPAR_AXI_TPG_1_BASEADDR, 0, (573<<16) | 360); // XHairs set at (573H, 360V)
   XTPG_mWriteSlaveReg3(XPAR_AXI_TPG_1_BASEADDR, 0, FrameSize); // Frame size set according to parameter
   XTPG_mWriteSlaveReg4(XPAR_AXI_TPG_1_BASEADDR, 0, 1);   // Set zone plate HDalta2 to 1 (bits 11:0)
                                                      // Set zone plate H sin-table address offset to 0 (bits 27:16)
   XTPG_mWriteSlaveReg5(XPAR_AXI_TPG_1_BASEADDR, 0, 1);   // Set zone plate VDalta2 to 1 (bits 11:0)
                                                      // Set zone plate V sin-table address offset to 0 (bits 27:16)
   XTPG_mWriteSlaveReg6(XPAR_AXI_TPG_1_BASEADDR, 0, 64);  // Set box size to 64
//   XTPG_mWriteSlaveReg7(XPAR_AXI_TPG_0_BASEADDR, 0, 0x00F06E29);  // Set box colour to mid blue
   XTPG_mWriteSlaveReg7(XPAR_AXI_TPG_1_BASEADDR, 0, 0x005AF051);  // Set box colour to mid blue

//Third one
   // Read current test-pattern setting.
   Reg32Value = XTPG_mReadSlaveReg0(XPAR_AXI_TPG_2_BASEADDR, 0);
   XTPG_mWriteSlaveReg0(XPAR_AXI_TPG_2_BASEADDR, 0, (Reg32Value & 0x0000000F));

   XTPG_mWriteSlaveReg0(XPAR_AXI_TPG_2_BASEADDR, 0, 0x00);   // PatternSel = 0 (passthru);
                                                      // Box off (bit 9)
                                                      // XHairs Off (bit 4)
                                                      // CrCb Polarity = 0 (bit 5)
   XTPG_mWriteSlaveReg1(XPAR_AXI_TPG_2_BASEADDR, 0, 2);   // Motion Off (bit 0)
                                                      // Motion speed set to 1 (bits 8:1)
   XTPG_mWriteSlaveReg2(XPAR_AXI_TPG_2_BASEADDR, 0, (573<<16) | 360); // XHairs set at (573H, 360V)
   XTPG_mWriteSlaveReg3(XPAR_AXI_TPG_2_BASEADDR, 0, FrameSize); // Frame size set according to parameter
   XTPG_mWriteSlaveReg4(XPAR_AXI_TPG_2_BASEADDR, 0, 1);   // Set zone plate HDalta2 to 1 (bits 11:0)
                                                      // Set zone plate H sin-table address offset to 0 (bits 27:16)
   XTPG_mWriteSlaveReg5(XPAR_AXI_TPG_2_BASEADDR, 0, 1);   // Set zone plate VDalta2 to 1 (bits 11:0)
                                                      // Set zone plate V sin-table address offset to 0 (bits 27:16)
   XTPG_mWriteSlaveReg6(XPAR_AXI_TPG_2_BASEADDR, 0, 64);  // Set box size to 64
//   XTPG_mWriteSlaveReg7(XPAR_AXI_TPG_0_BASEADDR, 0, 0x00F06E29);  // Set box colour to mid blue
   XTPG_mWriteSlaveReg7(XPAR_AXI_TPG_2_BASEADDR, 0, 0x005AF051);  // Set box colour to mid blue


}


#else
void xTPG_main(int width, int height)
{

        print("XTPG Not Implemented in this Design!\r\n\r\n");
}

#endif

void DisplayPerfNumbers(XAxiPmon *Instance, u8 AgentNum)
{
	double ReadByteCount;
	double WriteByteCount;
	double ReadByteCount_Arith;
    double WriteByteCount_Arith;

	u32 Intr;

	// Reset Metric Counters
	XAxiPmon_ResetMetricCounter(Instance);

    // Select Agent
    XAxiPmon_SetAgent(Instance, AgentNum);

	// Load Sample Interval Counter and start Countdown
	XAxiPmon_LoadSampleIntervalCounter(Instance);

    XAxiPmon_EnableMetricsCounter(Instance);

	XAxiPmon_EnableSampleIntervalCounter(Instance);

	// Poll Sample Interval Counter Overflow Interrupt Bit
	while ((Intr & XAPM_IXR_SIC_OVERFLOW_MASK) == 0)
		Intr = XAxiPmon_IntrGetStatus(Instance);


	XAxiPmon_DisableMetricsCounter(Instance);

	// Clear Sample Interval Counter Overflow Interrupt Bit
	XAxiPmon_IntrClear(Instance, XAPM_IXR_SIC_OVERFLOW_MASK);

	// Read out Metric Counters
	ReadByteCount  = XAxiPmon_GetMetricCounter(Instance, XAPM_METRIC_COUNTER_0);
	WriteByteCount = XAxiPmon_GetMetricCounter(Instance, XAPM_METRIC_COUNTER_1);

    ReadByteCount_Arith = (ReadByteCount/2) * .000001;
    WriteByteCount_Arith = (WriteByteCount/2) * .000001;

	// Display Performance Numbers
	printf("AXI_VDMA%d Tx = %f MB/s\r\n", AgentNum, ReadByteCount_Arith);
	printf("AXI_VDMA%d Rx = %f MB/s\r\n", AgentNum, WriteByteCount_Arith);

	if(AgentNum == 0)
	{
	VDMA_0_READ_VAL = ReadByteCount/2;
	VDMA_0_WRITE_VAL = WriteByteCount/2;
	}


	if(AgentNum == 1)
	{
	VDMA_1_READ_VAL = ReadByteCount/2;
	VDMA_1_WRITE_VAL = WriteByteCount/2;
	}

	if(AgentNum == 2)
	{
	VDMA_2_READ_VAL = ReadByteCount/2;
	VDMA_2_WRITE_VAL = WriteByteCount/2;
	}


}