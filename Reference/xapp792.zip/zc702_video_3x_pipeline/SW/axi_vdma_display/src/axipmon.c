/*
 * axipmon.c
 *
 *  Created on: Aug 6, 2012
 *      Author: ckohn
 */

#include <stdlib.h>
#include "xparameters.h"
#include "xstatus.h"
#include "axipmon.h"


XAxiPmon *XAxiPmon_Initialize(u16 DeviceId)
{
	XAxiPmon *Instance = malloc(sizeof *Instance);
	XAxiPmon_Config *Config = XAxiPmon_LookupConfig(DeviceId);
	XAxiPmon_CfgInitialize(Instance, Config, Config->BaseAddress);

    // Set Metrics
    XAxiPmon_SetMetrics(Instance, XAPM_METRIC_SET_2, XAPM_METRIC_COUNTER_0); // Read  Byte Count
    XAxiPmon_SetMetrics(Instance, XAPM_METRIC_SET_3, XAPM_METRIC_COUNTER_1); // Write Byte Count

    // Enable Metric Counters
    XAxiPmon_EnableMetricsCounter(Instance);

    // Set Sample Interval
	XAxiPmon_SetSampleInterval(Instance, 0, 300000000); // Equals 1 second

	return Instance;
}
