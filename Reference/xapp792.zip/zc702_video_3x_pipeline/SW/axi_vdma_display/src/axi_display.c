/* $Id: */
/******************************************************************************
*
*       XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"
*       AS A COURTESY TO YOU, SOLELY FOR USE IN DEVELOPING PROGRAMS AND
*       SOLUTIONS FOR XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE,
*       OR INFORMATION AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE,
*       APPLICATION OR STANDARD, XILINX IS MAKING NO REPRESENTATION
*       THAT THIS IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,
*       AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE
*       FOR YOUR IMPLEMENTATION.  XILINX EXPRESSLY DISCLAIMS ANY
*       WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE
*       IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR
*       REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF
*       INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
*       FOR A PARTICULAR PURPOSE.
*
*       (c) Copyright 2011-2012 Xilinx Inc.
*       All rights reserved.
*
******************************************************************************/
/*****************************************************************************/
/**
 *
 * @file axi_display.c
 *
 *This software application starts up the video pipelines and allows for the
 *user to examine bandwidth real time and to display separate layers or alpha
 *blend all layers on the LCD screen.  The software application is being run
 *from OCM in the Zynq processing subsystem.
 *
 *Application level software for Xilinx Video IP is written in the C-language
 *using the provided drivers for each IP.
 *
 * <pre>
 * MODIFICATION HISTORY:
 *
 * Ver   Who  Date     Changes
 * ----- ---- -------- -------------------------------------------------------
 * 1.00a jel  08/10/12 First release with Zynq Design
 * </pre>
 *
 * ***************************************************************************
 */

#include <stdio.h>
#include <stdlib.h>
#include <xil_printf.h>

#include <xil_cache.h>
#include "platform.h"
#include "xparameters.h"
#include "xscugic.h"
#include "xosd.h"
#include "ivk_osd.h"
#include "xuartps.h"
#include "ivk_video_resolution.h"
#include "xtpg_app.h"
#include "sleep.h"
#include "zc702_i2c_utils.h"


#include "xvtc.h"
#include "xaxivdma.h"

#define UART_BAUD 115200
#define UART_DEVICE_ID 0

#define DDR_BASE_ADDR      0x00000000
#define DDR_HIGH_ADDR      0x3FFFFFFF


/* Memory space for the frame buffers
 *
 * This example only needs one set of frame buffers, because one video IP is
 * to write to the frame buffers, and one video IP is to read from the frame
 * buffers.
 *
 * For 16 frames of 1080p, it needs 0x07E90000 memory for frame buffers
 */
#define MEM_BASE_ADDR       (DDR_BASE_ADDR + 0x00100000)
#define MEM_HIGH_ADDR       DDR_HIGH_ADDR
#define MEM_SPACE           (MEM_HIGH_ADDR - MEM_BASE_ADDR)

#define READ_ADDRESS_BASE      MEM_BASE_ADDR
#define WRITE_ADDRESS_BASE     MEM_BASE_ADDR

#define FRAME_HORIZONTAL_LEN  0x2000   /* 1280 pixels, each pixel 4 bytes */
#define FRAME_VERTICAL_LEN    0x800    /* 1080 pixels */

#define SUBFRAME_START_OFFSET    0//(FRAME_HORIZONTAL_LEN * 5 + 32)
#define SUBFRAME_HORIZONTAL_SIZE 0x1E00
#define SUBFRAME_VERTICAL_SIZE   0x438

#define NUMBER_OF_READ_FRAMES    XPAR_AXIVDMA_0_NUM_FSTORES
#define NUMBER_OF_WRITE_FRAMES   XPAR_AXIVDMA_0_NUM_FSTORES

extern XOSD Osd;
#define OSD_OUTPUT_RESOLUTION_720P 4
#define XOSD_INS_ENTRY_NUMBER   48
#define OSD_GC_LAYER 0

#define NUMBER_OF_DMAS 3


/*
 * Device instance definitions
 */
/* Struct instance for DMA block(s) */
struct dma_chan_parms {

	u32 Dma_Base_Addr;
	u32 Perf_Dma_Base_Addr;
	u32 AXIVDMA_DEVICE_ID;
	u32 Tx_Intr;
	u32 Rx_Intr;
    u32 RD_ADDR_BASE;
    u32 WR_ADDR_BASE;
    u32 TX_BD_ADDR_BASE;
    u32 RX_BD_ADDR_BASE;
	u8 *ReadFrameAddr;
	u8 *WriteFrameAddr;
	u32 BlockStartOffset;
	u32 BlockHoriz;
	u32 BlockVert;
	u32 FRAME_BUF0;
	u32 FRAME_BUF1;
	u32 FRAME_BUF2;
	u32 GEN_LOCK;
	XAxiVdma AxiVdma;
	XAxiVdma_DmaSetup ReadCfg;
	XAxiVdma_DmaSetup WriteCfg;
	XAxiVdma_Config *Config;
	XAxiVdma_FrameCounter FrameCfg;
};

struct dma_chan_parms dma_struct[NUMBER_OF_DMAS];



/* Transfer statics
 */

XScuGic sys_intc; // in ivk_video_resolution.c
extern XVtc TimeBaseGen;
u16 DeviceId = XPAR_PS7_SCUGIC_0_DEVICE_ID;
int intr_id = XPAR_FABRIC_AXI_VTC_0_IP2INTC_IRPT_INTR;

void usec_wait(Xint32 delay);
int tbgen_fsync_cnt = 0;

static int WriteSetup(struct dma_chan_parms define_function[NUMBER_OF_DMAS])
{
        int Status;
		int n;
		for (n = 0; n < NUMBER_OF_DMAS; n++) {
        define_function[n].WriteCfg.VertSizeInput = define_function[n].BlockVert;
        define_function[n].WriteCfg.HoriSizeInput = define_function[n].BlockHoriz;

        define_function[n].WriteCfg.Stride = FRAME_HORIZONTAL_LEN;
        define_function[n].WriteCfg.FrameDelay = 0;  /* This example does not test frame delay */

        define_function[n].WriteCfg.EnableCircularBuf = 1;
//        WriteCfg.EnableSync = 0;  /* No Gen-Lock */
        define_function[n].WriteCfg.EnableSync = dma_struct[n].GEN_LOCK;  /* Gen-Lock */

//        WriteCfg.PointNum = 0;    /* No Gen-Lock */
        define_function[n].WriteCfg.PointNum = 0;    /* No Gen-Lock */
        define_function[n].WriteCfg.EnableFrameCounter = 0; /* Endless transfers */

        define_function[n].WriteCfg.FixedFrameStoreAddr = 0; /* We are not doing parking */

        Status = XAxiVdma_DmaConfig(&define_function[n].AxiVdma, XAXIVDMA_WRITE, &define_function[n].WriteCfg);
        if (Status != XST_SUCCESS) {
                xdbg_printf(XDBG_DEBUG_ERROR,
                    "Write channel config failed %d\r\n", Status);

                return XST_FAILURE;
        }

        /* Initialize buffer addresses
         *
         * Use physical addresses
         */

                define_function[n].WriteCfg.FrameStoreStartAddr[0] = define_function[n].FRAME_BUF0;
                define_function[n].WriteCfg.FrameStoreStartAddr[1] = define_function[n].FRAME_BUF1;
                define_function[n].WriteCfg.FrameStoreStartAddr[2] = define_function[n].FRAME_BUF2;



        /* Set the buffer addresses for transfer in the DMA engine
         */
        Status = XAxiVdma_DmaSetBufferAddr(&define_function[n].AxiVdma, XAXIVDMA_WRITE,
                define_function[n].WriteCfg.FrameStoreStartAddr);
        if (Status != XST_SUCCESS) {
                xdbg_printf(XDBG_DEBUG_ERROR,
                    "Write channel set buffer address failed %d\r\n", Status);

                return XST_FAILURE;
        }



}
        return XST_SUCCESS;
}

static int ReadSetup(struct dma_chan_parms define_function[NUMBER_OF_DMAS])
{
        int Status;
        int n;

	for (n = 0; n < NUMBER_OF_DMAS; n++) {

        define_function[n].ReadCfg.VertSizeInput = define_function[n].BlockVert;
        define_function[n].ReadCfg.HoriSizeInput = define_function[n].BlockHoriz;

        define_function[n].ReadCfg.Stride = FRAME_HORIZONTAL_LEN;
        define_function[n].ReadCfg.FrameDelay = 1;  /* This example does not test frame delay */

        define_function[n].ReadCfg.EnableCircularBuf = 1;
//        ReadCfg.EnableSync = 0;  /* No Gen-Lock */
        define_function[n].ReadCfg.EnableSync = dma_struct[n].GEN_LOCK;  /* Gen-Lock */

//        ReadCfg.PointNum = 0;    /* No Gen-Lock */
        define_function[n].ReadCfg.PointNum = 0;    /* No Gen-Lock */
        define_function[n].ReadCfg.EnableFrameCounter = 0; /* Endless transfers */

        define_function[n].ReadCfg.FixedFrameStoreAddr = 0; /* We are not doing parking */

        Status = XAxiVdma_DmaConfig(&define_function[n].AxiVdma, XAXIVDMA_READ, &define_function[n].ReadCfg);
        if (Status != XST_SUCCESS) {
                xdbg_printf(XDBG_DEBUG_ERROR,
                    "Read channel config failed %d\n\r", Status);

                return XST_FAILURE;
        }

        /* Initialize buffer addresses
         *
         * These addresses are physical addresses
         */

                define_function[n].ReadCfg.FrameStoreStartAddr[0] = define_function[n].FRAME_BUF0;
                define_function[n].ReadCfg.FrameStoreStartAddr[1] = define_function[n].FRAME_BUF1;
                define_function[n].ReadCfg.FrameStoreStartAddr[2] = define_function[n].FRAME_BUF2;


        /* Set the buffer addresses for transfer in the DMA engine
         * The buffer addresses are physical addresses
         */
        Status = XAxiVdma_DmaSetBufferAddr(&define_function[n].AxiVdma, XAXIVDMA_READ,
                define_function[n].ReadCfg.FrameStoreStartAddr);
        if (Status != XST_SUCCESS) {
                xdbg_printf(XDBG_DEBUG_ERROR,
                    "Read channel set buffer address failed %d\n\r", Status);

                return XST_FAILURE;
        }
}
        return XST_SUCCESS;
}

static int StartTransfer(XAxiVdma * InstancePtr)
{
        int Status;

        Status = XAxiVdma_DmaStart(InstancePtr, XAXIVDMA_WRITE);
        if (Status != XST_SUCCESS) {
                xdbg_printf(XDBG_DEBUG_ERROR,
                    "Start Write transfer failed %d\r\n", Status);

                return XST_FAILURE;
        }

        Status = XAxiVdma_DmaStart(InstancePtr, XAXIVDMA_READ);
        if (Status != XST_SUCCESS) {
                xdbg_printf(XDBG_DEBUG_ERROR,
                    "Start read transfer failed %d\n\r", Status);

                return XST_FAILURE;
        }

        return XST_SUCCESS;
}

void timebase_fsync_handler(void)
{
        tbgen_fsync_cnt++;
}

int osd_ilist1[] =
{
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0x80000000, 0, 0, 0,
0xa04f8000, 0, 0x042cc004, 9,
0xe0220220, 1, 0x102c02c0, 4,
0xe01e01e0, 0, 0x202b02b0, 2,
0, 0, 0, 0
};

int osd_write_ilist(int * osd_ilist, int osd_ilength)
{
				xil_printf("Writing instructions\r\n");
                unsigned int osd_instruction_num = osd_ilength / XOSD_INS_SIZE;

                /* ensure we don't overflow the osd with too many instructions */
                if (osd_instruction_num > XOSD_INS_ENTRY_NUMBER) osd_instruction_num = XOSD_INS_ENTRY_NUMBER;

                /* load instructions into both bank 0 and 1 */
                XOSD_LoadInstructionList(&Osd, OSD_GC_LAYER, 0, (u32 *)osd_ilist, osd_instruction_num);
                XOSD_LoadInstructionList(&Osd, OSD_GC_LAYER, 1, (u32 *)osd_ilist, osd_instruction_num);
                //XOSD_LoadInstructionList(&Osd, OSD_GC_LAYER, 2, (u32 *)osd_ilist, osd_instruction_num);

                return 0;
}

int main()
{
    int frame_width, frame_height;
    int Status;
    int Reg32Value;
    int n;

    Xil_DCacheDisable();

    XUartPs Uart_Ps_0;
    XUartPs_Config *Config_0 = XUartPs_LookupConfig(UART_DEVICE_ID);
    XUartPs_CfgInitialize(&Uart_Ps_0, Config_0, Config_0->BaseAddress);
    XUartPs_SetBaudRate(&Uart_Ps_0, UART_BAUD);


    xil_printf("\r\n--- Entering main() --- \n\r");

    XIicPs zc702_IicPs;
    iic_init(&zc702_IicPs, ZC702_IIC_DEVICE_ID, ZC702_IIC_SCLK_RATE);
	zc702_usrclk_init(&zc702_IicPs);
	zc702_usrclk_set(&zc702_IicPs, freq_HD1080P);
	Status = zc702_hdmi_init(&zc702_IicPs);
	if(Status != XST_SUCCESS) {
	}

   xil_printf("HDMI Setup Complete!\r\n");

#if (NUMBER_OF_DMAS == 1 || NUMBER_OF_DMAS == 2 || NUMBER_OF_DMAS == 3)

	/* User Must Set Values For Each Struct */
	dma_struct[0].Dma_Base_Addr = XPAR_AXI_VDMA_0_BASEADDR;
	/* Device ID */
	dma_struct[0].AXIVDMA_DEVICE_ID = XPAR_AXI_VDMA_0_DEVICE_ID;
	/* Frame Buffer Addresses */
	dma_struct[0].FRAME_BUF0 = 0x08000000;
	dma_struct[0].FRAME_BUF1 = 0x09000000;
	dma_struct[0].FRAME_BUF2 = 0x0A000000;
	dma_struct[0].GEN_LOCK = 1;
	dma_struct[0].RX_BD_ADDR_BASE = 0xA0000800;
	dma_struct[0].ReadFrameAddr = (u8 *)dma_struct[0].RD_ADDR_BASE;
	dma_struct[0].WriteFrameAddr = (u8 *)dma_struct[0].WR_ADDR_BASE;
	dma_struct[0].BlockStartOffset = SUBFRAME_START_OFFSET;
	dma_struct[0].BlockHoriz = SUBFRAME_HORIZONTAL_SIZE;
	dma_struct[0].BlockVert = SUBFRAME_VERTICAL_SIZE;
#endif

#if (NUMBER_OF_DMAS == 2 || NUMBER_OF_DMAS == 3)

	/* User Must Set Values For Each Struct */
	dma_struct[1].Dma_Base_Addr = XPAR_AXI_VDMA_1_BASEADDR;
	/* Device ID */
	dma_struct[1].AXIVDMA_DEVICE_ID = XPAR_AXI_VDMA_1_DEVICE_ID;
	/* Frame Buffer Addresses */
	dma_struct[1].FRAME_BUF0 = 0x0B000000;
	dma_struct[1].FRAME_BUF1 = 0x0C000000;
	dma_struct[1].FRAME_BUF2 = 0x0D000000;
	dma_struct[1].GEN_LOCK = 1;
	dma_struct[1].ReadFrameAddr = (u8 *)dma_struct[1].RD_ADDR_BASE;
	dma_struct[1].WriteFrameAddr = (u8 *)dma_struct[1].WR_ADDR_BASE;
	dma_struct[1].BlockStartOffset = SUBFRAME_START_OFFSET;
	dma_struct[1].BlockHoriz = SUBFRAME_HORIZONTAL_SIZE;
	dma_struct[1].BlockVert = SUBFRAME_VERTICAL_SIZE;
#endif

#if (NUMBER_OF_DMAS == 3)

	/* User Must Set Values For Each Struct */
	dma_struct[2].Dma_Base_Addr = XPAR_AXI_VDMA_2_BASEADDR;
	/* Device ID */
	dma_struct[2].AXIVDMA_DEVICE_ID = XPAR_AXI_VDMA_2_DEVICE_ID;
	/* Frame Buffer Addresses */
	dma_struct[2].FRAME_BUF0 = 0x1D000000;
	dma_struct[2].FRAME_BUF1 = 0x1E000000;
	dma_struct[2].FRAME_BUF2 = 0x1F000000;
	dma_struct[2].TX_BD_ADDR_BASE = 0xA0002000;
	dma_struct[2].RX_BD_ADDR_BASE = 0xA0002800;
	dma_struct[2].GEN_LOCK = 1;
	dma_struct[2].ReadFrameAddr = (u8 *)dma_struct[2].RD_ADDR_BASE;
	dma_struct[2].WriteFrameAddr = (u8 *)dma_struct[2].WR_ADDR_BASE;
	dma_struct[2].BlockStartOffset = SUBFRAME_START_OFFSET;
	dma_struct[2].BlockHoriz = SUBFRAME_HORIZONTAL_SIZE;
	dma_struct[2].BlockVert = SUBFRAME_VERTICAL_SIZE;
#endif



        frame_width       = 1920;
        frame_height      = 1080;

        //First TPG
        Reg32Value = XTPG_mReadSlaveReg0(XPAR_AXI_TPG_0_BASEADDR, 0);
        XTPG_mWriteSlaveReg0(XPAR_AXI_TPG_0_BASEADDR, 0, (Reg32Value & 0xFFFFFFF0) | 10);
        XTPG_mWriteSlaveReg4(XPAR_AXI_TPG_0_BASEADDR, 0, 102);
        XTPG_mWriteSlaveReg5(XPAR_AXI_TPG_0_BASEADDR, 0, 182);

        Reg32Value = XTPG_mReadSlaveReg1(XPAR_AXI_TPG_0_BASEADDR, 0);
        if ((Reg32Value & 0x00000001)==0)
           XTPG_mWriteSlaveReg1(XPAR_AXI_TPG_0_BASEADDR, 0, (Reg32Value | 0x00000009));
        else
           XTPG_mWriteSlaveReg1(XPAR_AXI_TPG_0_BASEADDR, 0, (Reg32Value & 0xFFFFFFFE));

           //Second TPG
        Reg32Value = XTPG_mReadSlaveReg0(XPAR_AXI_TPG_1_BASEADDR, 0);
        XTPG_mWriteSlaveReg0(XPAR_AXI_TPG_1_BASEADDR, 0, (Reg32Value & 0xFFFFFFF0) | 10);
        XTPG_mWriteSlaveReg4(XPAR_AXI_TPG_1_BASEADDR, 0, 102);
        XTPG_mWriteSlaveReg5(XPAR_AXI_TPG_1_BASEADDR, 0, 182);

        Reg32Value = XTPG_mReadSlaveReg1(XPAR_AXI_TPG_1_BASEADDR, 0);
        if ((Reg32Value & 0x00000001)==0)
           XTPG_mWriteSlaveReg1(XPAR_AXI_TPG_1_BASEADDR, 0, (Reg32Value | 0x00000009));
        else
           XTPG_mWriteSlaveReg1(XPAR_AXI_TPG_1_BASEADDR, 0, (Reg32Value & 0xFFFFFFFE));

           //Third TPG
        Reg32Value = XTPG_mReadSlaveReg0(XPAR_AXI_TPG_2_BASEADDR, 0);
        XTPG_mWriteSlaveReg0(XPAR_AXI_TPG_2_BASEADDR, 0, (Reg32Value & 0xFFFFFFF0) | 10);
        XTPG_mWriteSlaveReg4(XPAR_AXI_TPG_2_BASEADDR, 0, 102);
        XTPG_mWriteSlaveReg5(XPAR_AXI_TPG_2_BASEADDR, 0, 182);

        Reg32Value = XTPG_mReadSlaveReg1(XPAR_AXI_TPG_2_BASEADDR, 0);
        if ((Reg32Value & 0x00000001)==0)
           XTPG_mWriteSlaveReg1(XPAR_AXI_TPG_2_BASEADDR, 0, (Reg32Value | 0x00000009));
        else
           XTPG_mWriteSlaveReg1(XPAR_AXI_TPG_2_BASEADDR, 0, (Reg32Value & 0xFFFFFFFE));


	for (n = 0; n < NUMBER_OF_DMAS; n++) {

         dma_struct[n].Config = XAxiVdma_LookupConfig(dma_struct[n].AXIVDMA_DEVICE_ID);
         if (!dma_struct[n].Config) {
                 xdbg_printf(XDBG_DEBUG_ERROR,
                     "No video DMA found for ID %d\n\r", dma_struct[n].AXIVDMA_DEVICE_ID);

                 return 1;
         }


         /* Initialize DMA engine */
         Status = XAxiVdma_CfgInitialize(&dma_struct[n].AxiVdma, dma_struct[n].Config, dma_struct[n].Dma_Base_Addr);
         if (Status != XST_SUCCESS) {

                 xdbg_printf(XDBG_DEBUG_ERROR,
                     "Initialization failed %d\n\r", Status);

                 return 1;
         }

}

         /* Setup the write channel
         */
        Status = WriteSetup(dma_struct);
        if (Status != XST_SUCCESS) {
                xdbg_printf(XDBG_DEBUG_ERROR,
                    "Write channel setup failed %d\r\n", Status);

                return 1;
        }


           /* Setup the read channel
             */
            Status = ReadSetup(dma_struct);
            if (Status != XST_SUCCESS) {
                    xdbg_printf(XDBG_DEBUG_ERROR,
                        "Read channel setup failed %d\n\r", Status);

                    return 1;
            }


	for (n = 0; n < NUMBER_OF_DMAS; n++) {


                 /* Start the DMA engine to transfer
                  */
                 Status = StartTransfer(&dma_struct[n].AxiVdma);
                 if (Status != XST_SUCCESS) {
                         return 1;
                 }

}

             XVtc_WriteReg(0x53800000, 4, 0x08400897);
             XVtc_WriteReg(0x53800000, 8, 0x002C0000);
             XVtc_WriteReg(0x53800000, 12, 0x000000C0);
             XVtc_WriteReg(0x53800000, 16, 0x04610464);
             XVtc_WriteReg(0x53800000, 20, 0x00050000);
             XVtc_WriteReg(0x53800000, 24, 0x00000029);

             XVtc_WriteReg(0x53800000, XVTC_CTL, 0x07ffff01);



             ivk_osd_init( VIDEO_RESOLUTION_1080P );

             xil_printf("frame_width = %d;\r\nframe_height = %d.\r\n", frame_width, frame_height);



#if defined(XPAR_AXI_TPG_0_BASEADDR)
            xTPG_main(frame_width, frame_width);
#endif

            print("cleanup platform\r\n");
            cleanup_platform();

    return 0;
}

/***********************************************************************
* Wait the specified number of microseconds
*
* @param    None.
*
* @return   None.
*
* @note     Calibrated at 100MHz CPU clock using scope,
*            should work for any CPU speed
*
***********************************************************************/
void usec_wait(Xint32 delay) {
        Xint32 val = delay * (Xint32)( (XPAR_CPU_CORTEXA9_0_CPU_CLK_FREQ_HZ * 17) / 100000000 );
        while(val--)
                asm("nop");
}
